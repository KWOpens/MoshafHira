﻿unit UGoPage;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes,
  Vcl.Graphics, Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.StdCtrls, Vcl.ExtCtrls,
  Vcl.Imaging.pngimage, Vcl.Imaging.jpeg, XiPanel, Vcl.Buttons;

type
  TFormGoPage = class(TForm)
    BtnAffichePage: TButton;
    eNumPage: TEdit;
    LabelNumPage: TLabel;
    XiPanel1: TXiPanel;
    Image1: TImage;
    procedure BtnAffichePageClick(Sender: TObject);
    procedure FormActivate(Sender: TObject);
    procedure FormPaint(Sender: TObject);
    procedure FormKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
    procedure FormClose(Sender: TObject);
    procedure SpeedButton1Click(Sender: TObject);
  private
    { Déclarations privées }
  public
    { Déclarations publiques }
  end;

var
  FormGoPage: TFormGoPage;

implementation

{$R *.dfm}

Uses UCoranMoshaf, MyFuncUtils;


procedure TFormGoPage.BtnAffichePageClick(Sender: TObject);
Var
  RepPages, aPath, nPage, NbreAyat, nOrdre, NameSora : String;
  NumPage, numPageSora, MaPage : Integer;
begin
  // Recherche de la Page à afficher
  aPath := ExtractFilePath(Application.ExeName);
  NumPage := StrToInt(eNumPage.Text);
  FormMoshaf.eNumPage.Text := eNumPage.Text;
  FormMoshaf.lbNumPage.Caption := eNumPage.Text;
  nPage := Format('%.*d', [3, NumPage]) + '.jpg';
  RepPages := aPath + 'Data\Pages\' + FormMoshaf.TypeMoshaf + '\' + nPage;
  // Affichage de la page recherchée
  FormMoshaf.ImageMoshaf.Picture.LoadFromFile(RepPages);
  //
  // Mise à jour des infos de la page à afficher
  //
  MaPage := StrToInt(eNumPage.Text);
  MajEntetePageMoshaf(MaPage,NbreAyat, nOrdre, NameSora);
  //
  FormMoshaf.PanelPiedPageMoshaf.Visible := True;
end;




// Indexation du Fichier des Sorate sur le N° de page du Moshaf
procedure TFormGoPage.FormActivate(Sender: TObject);
Var
  x:integer ;
  rgn : hrgn;
begin
  FormMoshaf.SoraCDS.IndexFieldNames := 'PageMushaf' ;
  eNumPage.SetFocus;
  //
  with FormGoPage do
  begin
    rgn:=CreateRoundRectRgn(0,0,width,height,30,30);
    SetWindowRgn(handle, rgn, true);
  End ;
End;



procedure TFormGoPage.FormClose(Sender: TObject);
begin
  Close;
end;



// Définition des touches de raccourcis
procedure TFormGoPage.FormKeyDown(Sender: TObject; var Key: Word;
  Shift: TShiftState);
begin
   case key of
      VK_ESCAPE : FormClose(Sender);
      VK_RETURN : BtnAffichePageClick(Sender);
   end;
end;



// dessin de la Form  + Titre
procedure TFormGoPage.FormPaint(Sender: TObject);
Var
  x : Integer ;
begin
  x:=120 ;                          // Début du texte
  With Canvas do
    Begin
     font.Name := 'Tahoma' ;
     font.Style:=[fsBold, fsItalic] ;
     font.Size:=14 ;

     font.Color:=clWhite ;
     Canvas.TextOut(x,8,'مصحف حراء');

    End ;
end;


// Fermer la fenetre
procedure TFormGoPage.SpeedButton1Click(Sender: TObject);
begin
  Close;
end;

end.
