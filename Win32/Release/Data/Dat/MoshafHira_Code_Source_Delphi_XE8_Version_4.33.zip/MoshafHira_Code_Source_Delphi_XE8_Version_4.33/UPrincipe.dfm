object fprincipe: Tfprincipe
  Left = 305
  Top = 100
  BorderIcons = [biSystemMenu]
  BorderStyle = bsSingle
  Caption = 'Rechantillonneur d'#39'image'
  ClientHeight = 436
  ClientWidth = 687
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  Position = poDesktopCenter
  OnActivate = FormActivate
  PixelsPerInch = 96
  TextHeight = 13
  object Imagesource: TImage
    Left = 8
    Top = 56
    Width = 113
    Height = 73
  end
  object Imagedest: TImage
    Left = 8
    Top = 144
    Width = 113
    Height = 73
  end
  object GroupBox1: TGroupBox
    Left = 8
    Top = 8
    Width = 153
    Height = 49
    Caption = 'Affichage'
    TabOrder = 0
    object optsource: TRadioButton
      Left = 8
      Top = 16
      Width = 57
      Height = 17
      Caption = 'Source'
      Checked = True
      TabOrder = 0
      TabStop = True
      OnClick = selectsource
    end
    object optdest: TRadioButton
      Left = 72
      Top = 16
      Width = 73
      Height = 17
      Caption = 'Destination'
      Enabled = False
      TabOrder = 1
      OnClick = selectsource
    end
  end
  object GroupBox2: TGroupBox
    Left = 168
    Top = 8
    Width = 249
    Height = 49
    Caption = 'Rechantillonage'
    TabOrder = 1
    object Label1: TLabel
      Left = 8
      Top = 24
      Width = 10
      Height = 13
      Caption = 'X:'
    end
    object Label2: TLabel
      Left = 96
      Top = 24
      Width = 10
      Height = 13
      Caption = 'Y:'
    end
    object spin_x: TSpinEdit
      Left = 24
      Top = 16
      Width = 57
      Height = 22
      MaxValue = 1024
      MinValue = 8
      TabOrder = 0
      Value = 8
    end
    object spin_y: TSpinEdit
      Left = 112
      Top = 16
      Width = 57
      Height = 22
      MaxValue = 1024
      MinValue = 8
      TabOrder = 1
      Value = 8
    end
    object boperation: TButton
      Left = 176
      Top = 16
      Width = 65
      Height = 25
      Caption = 'Op'#233'ration'
      TabOrder = 2
      OnClick = boperationClick
    end
  end
  object OpenPictureDialog1: TOpenPictureDialog
    Filter = 
      'Fichier image JPEG (*.jpg)|*.jpg|Fichier image JPEG (*.jpeg)|*.j' +
      'peg'
    Left = 480
    Top = 24
  end
end
