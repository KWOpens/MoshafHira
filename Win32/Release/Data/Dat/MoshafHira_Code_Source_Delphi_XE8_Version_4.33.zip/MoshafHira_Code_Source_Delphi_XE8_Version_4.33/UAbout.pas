unit UAbout;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, ComCtrls, Vcl.Imaging.pngimage, Vcl.ExtCtrls,
  ShellAPI;

type
  TFormAbout = class(TForm)
    Image1: TImage;
    Panel1: TPanel;
    Link: TLabel;
    Image2: TImage;
    procedure Image2Click(Sender: TObject);
  private
    { D�clarations priv�es }
  public
    { D�clarations publiques }
  end;

var
  FormAbout: TFormAbout;

implementation

{$R *.dfm}

procedure TFormAbout.Image2Click(Sender: TObject);
begin
  Close;
end;


end.
