unit TPlayerFilters;

// ----------------------------------------------------------------------------

interface

// ----------------------------------------------------------------------------

uses
  Windows,
  ActiveX;

// ----------------------------------------------------------------------------

const
  IID_ICreateDevEnum    : TGUID = '{29840822-5B84-11D0-BD3B-00A0C911CE86}';
  IID_IMediaSeeking     : TGUID = '{36B73880-C2C8-11CF-8B46-00805F6CEF60}';
  IID_IBaseFilter       : TGUID = '{56A86895-0AD4-11CE-B03A-0020AF0BA770}';
  IID_IReferenceClock   : TGUID = '{56A86897-0AD4-11CE-B03A-0020AF0BA770}';
  IID_IFilterGraph      : TGUID = '{56A8689F-0AD4-11CE-B03A-0020AF0BA770}';
  IID_IGraphBuilder     : TGUID = '{56A868A9-0AD4-11CE-B03A-0020AF0BA770}';

// ----------------------------------------------------------------------------

  IID_IMediaControl     : TGUID = (D1:$56A868B1;D2:$0AD4;D3:$11CE;D4:($B0,$3A,$00,$20,$AF,$0B,$A7,$70));
  IID_IBasicAudio       : TGUID = (D1:$56A868B3;D2:$0AD4;D3:$11CE;D4:($B0,$3A,$00,$20,$AF,$0B,$A7,$70));
  IID_IMediaEventEx     : TGUID = (D1:$56A868C0;D2:$0AD4;D3:$11CE;D4:($B0,$3A,$00,$20,$AF,$0B,$A7,$70));
  IID_IMediaEvent       : TGUID = (D1:$56A868B6;D2:$0AD4;D3:$11CE;D4:($B0,$3A,$00,$20,$AF,$0B,$A7,$70));

// ----------------------------------------------------------------------------

  // pnp objects and categories
  CLSID_SystemDeviceEnum     : TGUID = (D1:$62BE5D10;D2:$60EB;D3:$11D0;D4:($BD,$3B,$00,$A0,$C9,$11,$CE,$86));
  CLSID_AudioRendererCategory: TGUID = (D1:$E0F158E1;D2:$CB04;D3:$11D0;D4:($BD,$4E,$00,$A0,$C9,$11,$CE,$86));
  // end cut list stuff
  CLSID_FilterGraph          : TGUID = (D1:$E436EBB3;D2:$524F;D3:$11CE;D4:($9F,$53,$00,$20,$AF,$0B,$A7,$70));
  // major types
  MEDIATYPE_Audio            : TGUID = (D1:$73647561;D2:$0000;D3:$0010;D4:($80,$00,$00,$AA,$00,$38,$9B,$71));
  CLSID_NullRenderer         : TGUID = '{C1F400A4-3F08-11D3-9F0B-006008039E37}';

// ----------------------------------------------------------------------------

  // Flags for IMediaSeeking
  AM_SEEKING_NoPositioning          = 0;
  AM_SEEKING_AbsolutePositioning    = $1;
{
  AM_SEEKING_RelativePositioning    = $2;
  AM_SEEKING_IncrementalPositioning = $3;
  AM_SEEKING_PositioningBitsMask    = $3;
  AM_SEEKING_SeekToKeyFrame         = $4;
  AM_SEEKING_ReturnTime             = $8;
  AM_SEEKING_Segment                = $10;
  AM_SEEKING_NoFlush                = $20;

  AM_SEEKING_CanSeekAbsolute        = $1;
  AM_SEEKING_CanSeekForwards        = $2;
  AM_SEEKING_CanSeekBackwards       = $4;
  AM_SEEKING_CanGetCurrentPos       = $8;
  AM_SEEKING_CanGetStopPos          = $10;
  AM_SEEKING_CanGetDuration         = $20;
  AM_SEEKING_CanPlayBackwards       = $40;
  AM_SEEKING_CanDoSegments          = $80;
  AM_SEEKING_Source                 = $100;
}
type
  OAEVENT = Longint;
  OAHWND = Longint;
  OAFilterState = Longint;

// ----------------------------------------------------------------------------

type
  TAM_Media_Type = record
    majortype: TGUID;
    subtype: TGUID;
    bFixedSizeSamples: BOOL;
    bTemporalCompression: BOOL;
    lSampleSize: ULONG;
    formattype: TGUID;
    pUnk: IUnknown;
    cbFormat: ULONG;
    pbFormat: Pointer;
  end;
  PAM_Media_Type = ^TAM_Media_Type;

// ----------------------------------------------------------------------------

  TPin_Direction = (
    PINDIR_INPUT,
    PINDIR_OUTPUT
  );

// ----------------------------------------------------------------------------

  TReference_Time = int64;
  PReference_Time = ^TReference_Time;

  TRefTime = double;

  HSEMAPHORE = Longint;

// ----------------------------------------------------------------------------

  TAllocator_Properties = record
    cBuffers: Longint;
    cbBuffer: Longint;
    cbAlign: Longint;
    cbPrefix: Longint;
  end;

// ----------------------------------------------------------------------------

  IBaseFilter = interface;

  TPin_Info = record
    pFilter: IBaseFilter;
    dir: TPin_Direction;
    achName: array[0..127] of WCHAR;
  end;

  IEnumMediaTypes = interface;

  IPin = interface(IUnknown)
    ['{56A86891-0AD4-11CE-B03A-0020AF0BA770}']
    function Connect(pReceivePin: IPin; pmt: PAM_Media_Type): HRESULT; stdcall;
    function ReceiveConnection(pConnector: IPin; const pmt: TAM_Media_Type): HRESULT; stdcall;
    function Disconnect: HRESULT; stdcall;
    function ConnectedTo(out pPin: IPin): HRESULT; stdcall;
    function ConnectionMediaType(out pmt: TAM_Media_Type): HRESULT; stdcall;
    function QueryPinInfo(out pInfo: TPin_Info): HRESULT; stdcall;
    function QueryDirection(out pPinDir: TPin_Direction): HRESULT; stdcall;
    function QueryId(out Id: LPWSTR): HRESULT; stdcall;
    function QueryAccept(const pmt: PAM_Media_Type): HRESULT; stdcall;
    function EnumMediaTypes(out ppEnum: IEnumMediaTypes): HRESULT; stdcall;
    function QueryInternalConnections(out apPin: IPin; var nPin: ULONG): HRESULT; stdcall;
    function EndOfStream: HRESULT; stdcall;
    function BeginFlush: HRESULT; stdcall;
    function EndFlush: HRESULT; stdcall;
    function NewSegment(tStart, tStop: TReference_Time; dRate: double): HRESULT; stdcall;
  end;

// ----------------------------------------------------------------------------

  IEnumPins = interface(IUnknown)
    ['{56A86892-0AD4-11CE-B03A-0020AF0BA770}']
    function Next(cPins: ULONG; out ppPins: IPin; pcFetched: PULONG): HRESULT; stdcall;
    function Skip(cPins: ULONG): HRESULT; stdcall;
    function Reset: HRESULT; stdcall;
    function Clone(out ppEnum: IEnumPins): HRESULT; stdcall;
  end;

// ----------------------------------------------------------------------------

  IEnumMediaTypes = interface(IUnknown)
    ['{89C31040-846B-11CE-97D3-00AA0055595A}']
    function Next(cMediaTypes: ULONG; var ppMediaTypes: PAM_Media_Type;
        out pcFetched: ULONG): HRESULT; stdcall;
    function Skip(cMediaTypes: ULONG): HRESULT; stdcall;
    function Reset: HRESULT; stdcall;
    function Clone(out ppEnum: IEnumMediaTypes): HRESULT; stdcall;
  end;

// ----------------------------------------------------------------------------

  IEnumFilters = interface;

  IFilterGraph = interface(IUnknown)
    ['{56A8689F-0AD4-11CE-B03A-0020AF0BA770}']
    function AddFilter(pFilter: IBaseFilter; pName: PWideChar): HRESULT; stdcall;
    function RemoveFilter(pFilter: IBaseFilter): HRESULT; stdcall;
    function EnumFilters(out ppEnum: IEnumFilters): HRESULT; stdcall;
    function FindFilterByName(pName: PWideChar; out ppFilter: IBaseFilter): HRESULT; stdcall;
    function ConnectDirect(ppinOut, ppinIn: IPin; pmt: PAM_Media_Type): HRESULT; stdcall;
    function Reconnect(ppin: IPin): HRESULT; stdcall;
    function Disconnect(ppin: IPin): HRESULT; stdcall;
    function SetDefaultSyncSource: HRESULT; stdcall;
  end;

  IEnumFilters = interface(IUnknown)
    ['{56A86893-0AD4-11CE-B03A-0020AF0BA770}']
    function Next(cFilters: ULONG; out ppFilter: IBaseFilter;
      pcFetched: PULONG): HRESULT; stdcall;
    function Skip(cFilters: ULONG): HRESULT; stdcall;
    function Reset: HRESULT; stdcall;
    function Clone(out ppEnum: IEnumFilters): HRESULT; stdcall;
  end;

// ----------------------------------------------------------------------------

  IReferenceClock = interface;

  TFilter_State = (
    State_Stopped,
    State_Paused,
    State_Running
  );

  IMediaFilter = interface(IPersist)
    ['{56A86899-0AD4-11CE-B03A-0020AF0BA770}']
    function Stop: HRESULT; stdcall;
    function Pause: HRESULT; stdcall;
    function Run(tStart: TReference_Time): HRESULT; stdcall;
    function GetState(dwMilliSecsTimeout: DWORD; out State: TFILTER_STATE): HRESULT; stdcall;
    function SetSyncSource(pClock: IReferenceClock): HRESULT; stdcall;
    function GetSyncSource(out pClock: IReferenceClock): HRESULT; stdcall;
  end;

// ----------------------------------------------------------------------------

  TFilterInfo = record
    achName: array[0..127] of WCHAR;
    pGraph: IFilterGraph;
  end;

  IBaseFilter = interface(IMediaFilter)
    ['{56A86895-0AD4-11CE-B03A-0020AF0BA770}']
    function EnumPins(out ppEnum: IEnumPins): HRESULT; stdcall;
    function FindPin(Id: PWideChar; out ppPin: IPin): HRESULT; stdcall;
    function QueryFilterInfo(out pInfo: TFilterInfo): HRESULT; stdcall;
    function JoinFilterGraph(pGraph: IFilterGraph; pName: PWideChar): HRESULT; stdcall;
    function QueryVendorInfo(out pVendorInfo: PWideChar): HRESULT; stdcall;
  end;

// ----------------------------------------------------------------------------

  IReferenceClock = interface(IUnknown)
    ['{56A86897-0AD4-11CE-B03A-0020AF0BA770}']
    function GetTime(out pTime: TReference_Time): HRESULT; stdcall;
    function AdviseTime(baseTime, streamTime: TReference_Time;
        hEvent: THandle; out pdwAdviseCookie: DWORD): HRESULT; stdcall;
    function AdvisePeriodic(startTime, periodTime: TReference_Time;
        hSemaphore: HSEMAPHORE; out pdwAdviseCookie: DWORD): HRESULT; stdcall;
    function Unadvise(dwAdviseCookie: DWORD): HRESULT; stdcall;
  end;

// ----------------------------------------------------------------------------

  IGraphBuilder = interface(IFilterGraph)
    ['{56A868A9-0AD4-11CE-B03A-0020AF0BA770}']
    function Connect(ppinOut, ppinIn: IPin): HRESULT; stdcall;
    function Render(ppinOut: IPin): HRESULT; stdcall;
    function RenderFile(lpcwstrFile, lpcwstrPlayList: PWideChar): HRESULT; stdcall;
    function AddSourceFilter(lpcwstrFileName, lpcwstrFilterName: LPCWSTR;
        out ppFilter: IBaseFilter): HRESULT; stdcall;
    function SetLogFile(hFile: PHandle): HRESULT; stdcall;
    function Abort: HRESULT; stdcall;
    function ShouldOperationContinue: HRESULT; stdcall;
  end;

// ----------------------------------------------------------------------------

  ICreateDevEnum = interface(IUnknown)
    ['{29840822-5B84-11D0-BD3B-00A0C911CE86}']
    function CreateClassEnumerator(const clsidDeviceClass: TGUID;
        out ppEnumMoniker: IEnumMoniker; dwFlags: DWORD): HRESULT; stdcall;
  end;
{
const
  MS_S_PENDING                = $80040401;
  MS_S_NOUPDATE               = $80040402;
  MS_S_ENDOFSTREAM            = $80040403;
  MS_E_SAMPLEALLOC            = $00040001;
  MS_E_PURPOSEID              = $00040002;
  MS_E_NOSTREAM               = $00040003;
  MS_E_NOSEEKING              = $00040004;
  MS_E_INCOMPATIBLE           = $00040005;
  MS_E_BUSY                   = $00040006;
  MS_E_NOTINIT                = $00040007;
  MS_E_SOURCEALREADYDEFINED   = $00040008;
  MS_E_INVALIDSTREAMTYPE      = $00040009;
  MS_E_NOTRUNNING             = $0004000A;
}
type
  IMediaSeeking = interface(IUnknown)
    ['{36B73880-C2C8-11CF-8B46-00805F6CEF60}']
    function GetCapabilities(out pCapabilities: DWORD): HRESULT; stdcall;
    function CheckCapabilities(var pCapabilities: DWORD): HRESULT; stdcall;
    function IsFormatSupported(const pFormat: TGUID): HRESULT; stdcall;
    function QueryPreferredFormat(out pFormat: TGUID): HRESULT; stdcall;
    function GetTimeFormat(out pFormat: TGUID): HRESULT; stdcall;
    function IsUsingTimeFormat(const pFormat: TGUID): HRESULT; stdcall;
    function SetTimeFormat(const pFormat: TGUID): HRESULT; stdcall;
    function GetDuration(out pDuration: int64): HRESULT; stdcall;
    function GetStopPosition(out pStop: int64): HRESULT; stdcall;
    function GetCurrentPosition(out pCurrent: int64): HRESULT; stdcall;
    function ConvertTimeFormat(out pTarget: int64; pTargetFormat: PGUID;
        Source: int64; pSourceFormat: PGUID): HRESULT; stdcall;
    function SetPositions(pCurrent: Pint64; dwCurrentFlags: DWORD;
        pStop: Pint64; dwStopFlags: DWORD): HRESULT; stdcall;
    function GetPositions(out pCurrent, pStop: int64): HRESULT; stdcall;
    function GetAvailable(out pEarliest, pLatest: int64): HRESULT; stdcall;
    function SetRate(dRate: double): HRESULT; stdcall;
    function GetRate(out pdRate: double): HRESULT; stdcall;
    function GetPreroll(out pllPreroll: int64): HRESULT; stdcall;

    function put_CurrentPosition(llTime: TRefTime): HResult; stdcall;
  end;

// ----------------------------------------------------------------------------

(* Definition of interface: IMediaControl *)
  IMediaControl = interface(IDispatch)
    ['{56A868B1-0AD4-11CE-B03A-0020AF0BA770}']
    (* IMediaControl methods *)
    function Run: HResult; stdcall;
    function Pause: HResult; stdcall;
    function Stop: HResult; stdcall;
    function GetState(msTimeout: Longint; out pfs: OAFilterState): HResult; stdcall;
    function RenderFile(strFilename: WideString): HResult; stdcall;
    function AddSourceFilter(strFilename: WideString; out ppUnk: IDispatch): HResult; stdcall;
    function get_FilterCollection(out ppUnk: IDispatch): HResult; stdcall;
    function get_RegFilterCollection(out ppUnk: IDispatch): HResult; stdcall;
    function StopWhenReady: HResult; stdcall;
  end;

// ----------------------------------------------------------------------------

(* Definition of interface: IBasicAudio *)
  IBasicAudio = interface(IDispatch)
    ['{56A868B3-0AD4-11CE-B03A-0020AF0BA770}']
    (* IBasicAudio methods *)
    function put_Volume(lVolume: Longint): HResult; stdcall;
    function get_Volume(out plVolume: Longint): HResult; stdcall;
    function put_Balance(lBalance: Longint): HResult; stdcall;
    function get_Balance(out plBalance: Longint): HResult; stdcall;
  end;

// ----------------------------------------------------------------------------

(* Definition of interface: IMediaEvent *)
  IMediaEvent = interface(IDispatch)
    ['{56A868B6-0AD4-11CE-B03A-0020AF0BA770}']
    (* IMediaEvent methods *)
    function GetEventHandle(out hEvent: OAEVENT): HRESULT; stdcall;
    function GetEvent(out lEventCode: Longint; out lParam1, lParam2: Longint;
        msTimeout: DWORD): HRESULT; stdcall;
    function WaitForCompletion(msTimeout: DWORD; out pEvCode: Longint):
        HRESULT; stdcall;
    function CancelDefaultHandling(lEvCode: Longint): HRESULT; stdcall;
    function RestoreDefaultHandling(lEvCode: Longint): HRESULT; stdcall;
    function FreeEventParams(lEvCode: Longint; lParam1, lParam2: Longint):
        HRESULT; stdcall;
  end;
(* Definition of interface: IMediaEventEx *)
  IMediaEventEx = interface(IMediaEvent)
    ['{56A868C0-0AD4-11CE-B03A-0020AF0BA770}']
    (* IMediaEventEx methods *)
    function SetNotifyWindow(hwnd: OAHWND; lMsg: Longint;
        lInstanceData: Longint): HRESULT; stdcall;
    function SetNotifyFlags(lNoNotifyFlags: Longint): HRESULT; stdcall;
    function GetNotifyFlags(out lplNoNotifyFlags): HRESULT; stdcall; //longint
  end;

// ----------------------------------------------------------------------------

type
  CoNullRenderer = class
    class function Create: IBaseFilter;
    class function CreateRemote(const MachineName: string): IBaseFilter;
  end;

// ----------------------------------------------------------------------------

type
  AMGetErrorTextProcA = function(hr: HRESULT; pbuffer: PChar; MaxLen: DWORD): BOOL; stdcall;
  AMGetErrorTextProcW = function(hr: HRESULT; pbuffer: PWideChar; MaxLen: DWORD): BOOL; stdcall;

  {$IFDEF UNICODE}
  AMGetErrorTextProc  = AMGetErrorTextProcW;
  {$ELSE}
  AMGetErrorTextProc  = AMGetErrorTextProcA;
  {$ENDIF}

  function AMGetErrorTextA(hr: HRESULT; pbuffer: PChar; MaxLen: DWORD): DWORD; stdcall;
  function AMGetErrorTextW(hr: HRESULT; pbuffer: PWideChar; MaxLen: DWORD): DWORD; stdcall;
  function AMGetErrorText(hr: HRESULT; pbuffer: PChar; MaxLen: DWORD): DWORD; stdcall;

// ----------------------------------------------------------------------------

implementation

// ----------------------------------------------------------------------------

uses
  ComObj;

// ----------------------------------------------------------------------------

const
  quartz = 'quartz.dll';

// ----------------------------------------------------------------------------

class function CoNullRenderer.Create: IBaseFilter;
begin
  Result := CreateComObject(CLSID_NullRenderer) as IBaseFilter;
end;

// ----------------------------------------------------------------------------

class function CoNullRenderer.CreateRemote(const MachineName: string): IBaseFilter;
begin
  Result := CreateRemoteComObject(MachineName, CLSID_NullRenderer) as IBaseFilter;
end;

// ----------------------------------------------------------------------------

function AMGetErrorTextA; external quartz;
function AMGetErrorTextW; external quartz;
{$IFDEF UNICODE}
function AMGetErrorText; external quartz name 'AMGetErrorTextW';
{$ELSE}
function AMGetErrorText; external quartz name 'AMGetErrorTextA';
{$ENDIF}

// ----------------------------------------------------------------------------

end.
