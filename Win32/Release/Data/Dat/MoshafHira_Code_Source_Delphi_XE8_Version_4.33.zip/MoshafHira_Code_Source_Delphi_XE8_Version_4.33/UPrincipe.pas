unit UPrincipe;

interface

uses
  //Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  //StdCtrls,  ExtCtrls;
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.StdCtrls, Vcl.ComCtrls, Vcl.ExtCtrls,
  Vcl.Imaging.pngimage, Spin, Math, Jpeg, ExtDlgs;

type
  Tfprincipe = class(TForm)
    Imagesource: TImage;
    Imagedest: TImage;
    GroupBox1: TGroupBox;
    optsource: TRadioButton;
    optdest: TRadioButton;
    GroupBox2: TGroupBox;
    Label1: TLabel;
    Label2: TLabel;
    spin_x: TSpinEdit;
    spin_y: TSpinEdit;
    boperation: TButton;
    OpenPictureDialog1: TOpenPictureDialog;
    procedure selectsource(Sender: TObject);
    procedure FormActivate(Sender: TObject);
    procedure boperationClick(Sender: TObject);
  private
    { D�clarations priv�es }
  public
    { D�clarations publiques }
  end;

var
  fprincipe: Tfprincipe;

implementation

{$R *.DFM}

uses  UCoranMoshaf;

procedure quad2rgb(a : longword;var r,g,b : byte);
var ac : array[0..3] of byte;
begin
     move(a,ac,4);
     r:=ac[0];g:=ac[1];b:=ac[2];
end;

function rgb2quad(r,g,b : byte) : longword;
var ac : array[0..3] of byte;
    l : longword;
begin
     ac[0] := r; ac[1] := g; ac[2] := b; ac[3] := 0;
     move(ac,l,4);
     rgb2quad := l;
end;


Procedure setpixel_i(x,y : word;r,g,b : byte);   stdcall;
var lp : longword;
begin

       fprincipe.imagedest.canvas.Pixels[x,y] := rgb2quad(r,g,b);;

end;

procedure getpixel_i(x,y : word;var r,g,b : byte);  stdcall;

begin
  quad2rgb(fprincipe.imagesource.canvas.pixels[x,y],r,g,b);
end;


function min(a,b : word) : word;
begin
  if b < a then min := a
  else min := b;
end;



procedure Tfprincipe.selectsource(Sender: TObject);
begin
   if optsource.checked then
     begin
        imagesource.show;
        imagedest.hide;
        fprincipe.width := min(512,imagesource.width+64);
        fprincipe.height := min(128,imagesource.height+100);

     end;
   if optdest.checked then
     begin
        imagesource.hide;
        imagedest.show;
        fprincipe.width := min(512,imagedest.width+64);
        fprincipe.height := min(128,imagedest.height+100);
     end;
end;

procedure Tfprincipe.FormActivate(Sender: TObject);
var
  jpg : Tjpegimage;
begin
   //if openpicturedialog1.Execute then
   //  begin
        jpg := Tjpegimage.create;

        jpg.Assign(FormMoshaf.BMPWork);

        imagesource.width := jpg.width;
        imagesource.height := jpg.height;
        imagesource.canvas.pixels[jpg.width, jpg.height] := clred;
        imagesource.canvas.draw(0,0,jpg);
        selectsource(sender);
        spin_x.value := imagesource.width;
        spin_y.Value := imagesource.height;
        jpg.destroy;
   //  end
   //else
   //  application.terminate;
end;

procedure  _resize(rp,wp : pointer;source_resx,source_resy : word;dest_resx,dest_resy : word);
begin
  //gegonda_resize(rp,wp,source_resx,source_resy,dest_resx,dest_resy,1); //1= Rechantillonner en mode interpolation
end;



procedure Tfprincipe.boperationClick(Sender: TObject);
var
  resx,resy : word;
begin
     resx := spin_x.value;
     resy := spin_y.value;
     imagedest.picture := nil;
     imagedest.width := resx;
     imagedest.height := resy;
     imagedest.canvas.pixels[resx, resy] := clred;
     //_resize(@getpixel_i,@setpixel_i,imagesource.Width,imagesource.height,resx,resy);
     optdest.checked := true;
     optdest.enabled := true;
     selectsource(sender);
end;

end.
