﻿unit UConst;

interface

const
  Filtre = 'Fichiers quelconques (*.*)|*.*;'
    + '|Fichiers texte (*.txt)|*.txt;'
    + '|Fichiers texte enrichi (*.rtf)|*.rtf';
  crlf = #13#10;

  SorateFr : array[1..114] of string = ('AlFatiha', 'AlBaqara', 'AlImran', 'AnNissa', 'AlMaidah',
   'AlAnam', 'AlAraf', 'AlAnfal', 'AtTawbah', 'Younas', 'Houd', 'Yousuf', 'ArRa3d', 'Ibrahim', 'AlHijr',
   'AnNahl', 'AlIsra', 'AlKahf', 'Maryam', 'TaHa', 'AlAnbiya', 'AlHajj', 'AlMouminoun', 'AnNour',
   'AlFourqan', 'AShouara', 'AnNaml', 'AlQassas', 'Al3Ankabout', 'ArRom', 'Louqman', 'AsSajda',
   'AlAhzab', 'Saba', 'Fatir', 'YaSin', 'AsSaffat', 'Sad', 'AZoumar', 'AlGhafir', 'Foussilat',
   'AShoura', 'AZoukhrouf', 'AdDoukhan', 'AlJathiya', 'lAhqaf', 'Mouhammad', 'AlFath', 'AlHoujourat',
   'Qaf', 'AdDariyat', 'AtTour', 'AnNajm', 'AlQamar', 'ArRahman', 'AlWaqia', 'AlHadid', 'AlMoujadala',
   'AlHashr', 'AlMoumtahana', 'AsSaff', 'AlJumou3a', 'AlMounafiqoun', 'AtTaghaboun', 'AtTalaq',
   'AtTahrim', 'AlMoulk', 'AlQalam', 'AlHaqah', 'AlMa3arij', 'Nouh', 'AlJinn', 'AlMouzamil',
   'AlMoudathir', 'AlQiyama', 'AlInsan', 'AlMoursalat', 'AnNabaa', 'AnNaziat', 'Abassa', 'AtTakwir',
   'AlInfitar', 'AlMoutafifin', 'AlInshiqaq', 'AlBourouj', 'AtTariq', 'AlAla', 'AlGhashiya', 'AlFajr',
   'AlBalad', 'AShams', 'AlLayl', 'AdDouha', 'ASharh', 'AtTin', 'AlAlaq', 'AlQadr', 'AlBayinah',
   'AzZalzalah', 'AlAdiyat', 'AlQaria', 'AtTakathour', 'AlAsr', 'AlHoumazah', 'AlFil', 'Qouraysh', 'AlMa3oun',
   'AlKawthar', 'AlKafiroune', 'AnNasr', 'AlMasad', 'AlIkhlas', 'AlFalaq', 'AnNas');

  SorateAr : array[1..114] of string = ('الفاتحة', 'البقرة', 'آل عمران', 'النساء', 'المائدة',
   'الأنعام', 'الأعراف', 'الأنفال', 'التوبة', 'يونس', 'هود', 'يوسف', 'الرعد', 'إبراهيم', 'الحجر',
   'النحل', 'الإسراء', 'الكهف', 'مريم', 'طه', 'الأنبياء', 'الحج', 'المومنون', 'النور',
   'الفرقان', 'الشعراء', 'النمل', 'القصص', 'العنكبوت', 'الروم', 'لقمان', 'السجدة',
   'الأحزاب', 'سبأ', 'فاطر', 'يس', 'الصافات', 'ص', 'الزمر', 'غافر', 'فصلت',
   'الشورى', 'الزخرف', 'الدخان', 'الجاثية', 'الأحقاف', 'محمد', 'الفتح', 'الحجرات',
   'ق', 'الذاريات', 'الطور', 'النجم', 'القمر', 'الرحمن', 'الواقعة', 'الحديد', 'المجادلة',
   'الحشر', 'الممتحنة', 'الصف', 'الجمعة', 'المنافقون', 'التغابن', 'الطلاق',
   'التحريم', 'الملك', 'القلم', 'الحاقة', 'المعارج', 'نوح', 'الجن', 'المزمل',
   'المدثر', 'القيامة', 'الإنسان', 'المرسلات', 'النبأ', 'النازعات', 'عبس', 'التكوير',
   'الإنفطار', 'المطففين', 'الإنشقاق', 'البروج', 'الطارق', 'الأغلى', 'الغاشية', 'الفجر',
   'البلد', 'الشمس', 'الليل', 'الضحى', 'الشرح', 'التين', 'العلق', 'القدر', 'البينة',
   'الزلزلة', 'العاديات', 'القارعة', 'التكاثر', 'العصر', 'الهمزة', 'الفيل', 'قريش', 'الماعون',
   'الكوثر', 'الكافرون', 'النصر', 'المسد', 'الإخلاص', 'الفلق', 'الناس');

  LL : array [1..30] of Integer = (0,44,45,91,92,146,147,194,195,242,243,298,299,339,340,390,391         // Les Y des Points des rectangles
   ,437,438,487,488,541,542,590,591,642,643,692,693,728);


resourcestring
  sInfo = 'Fichiers  : ' + #13#10;

implementation

end.

