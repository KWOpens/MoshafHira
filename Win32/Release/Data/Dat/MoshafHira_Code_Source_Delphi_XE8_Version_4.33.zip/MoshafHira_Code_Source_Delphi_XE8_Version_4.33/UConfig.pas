﻿unit UConfig;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.StdCtrls, Vcl.ExtCtrls, Vcl.Buttons,
  IniFiles,             // Pour utiliser TIniFile
  Registry, Vcl.Menus, Vcl.Samples.Spin, Vcl.Imaging.jpeg;             // Pour utiliser TRegistry

type
  TFormConfig = class(TForm)
    Panel1: TPanel;
    Bevel3: TBevel;
    Bevel4: TBevel;
    Bevel5: TBevel;
    ChkWindows: TCheckBox;
    eMoshaf1: TEdit;
    eNoPage1: TEdit;
    eNoSora1: TEdit;
    Label11: TLabel;
    Label5: TLabel;
    Label7: TLabel;
    SpeedButton1: TSpeedButton;
    BtnSaveObs: TButton;
    eMoshaf2: TEdit;
    EditX1: TEdit;
    eNoSora2: TEdit;
    Label9: TLabel;
    Label10: TLabel;
    Label12: TLabel;
    Label17: TLabel;
    MemObs: TMemo;
    eNoPage2: TEdit;
    Label14: TLabel;
    EditX2: TEdit;
    Label15: TLabel;
    EditY1: TEdit;
    EditY2: TEdit;
    DefaultValue: TButton;
    PopupMenu1: TPopupMenu;
    N1: TMenuItem;
    N2: TMenuItem;
    BtnLecture: TButton;
    BtnApprendre: TButton;
    BtnSaveApprendre: TButton;
    BtnSaveLecture: TButton;
    Label3: TLabel;
    Jour: TSpinEdit;
    Image1: TImage;
    Label1: TLabel;
    procedure SpeedButton1Click(Sender: TObject);
    procedure BtnSaveObsClick(Sender: TObject);
    procedure FormActivate(Sender: TObject);
    procedure DefaultValueClick(Sender: TObject);
    procedure LoadSetting(Sender: TObject);
    procedure N1Click(Sender: TObject);
    procedure N2Click(Sender: TObject);
    procedure BtnLectureClick(Sender: TObject);
    procedure BtnApprendreClick(Sender: TObject);
    procedure FormCloseQuery(Sender: TObject; var CanClose: Boolean);
    procedure FormClose(Sender: TObject);
    procedure Image1Click(Sender: TObject);
  private
    { Déclarations privées }
  public
    { Déclarations publiques }
  end;

var
  FormConfig: TFormConfig;
  INI: TMemIniFile;
  CustomParametres: Boolean;
  //
  eMoshaf, eNOSora, eNoPage, eDitX, eDitY : String;

implementation

{$R *.dfm}

Uses UCoranMoshaf, MyFuncUtils;


procedure SetAutoStart(bRegister: Boolean);
Var
  Regkey : TRegistry;
begin
  try
    Regkey := TRegistry.Create(KEY_ALL_ACCESS);
    try
      Regkey.RootKey:=HKEY_LOCAL_MACHINE;
      Regkey.OpenKey('SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run\\',true);
      // create the entry in autorun registry key
      if bRegister then
            // if Autorun On
            Regkey.WriteString('MoshafHira', Application.ExeName)
      else
            // else Autorun Off
            Regkey.DeleteValue('MoshafHira');
      Regkey.CloseKey;
    except on E: Exception do
      ShowMessage(e.Message);
    end;
  except on E: Exception do
    ShowMessage(e.Message);
  end;
end;




procedure TFormConfig.DefaultValueClick(Sender: TObject);
begin
  // Charge l'état du lancement au démarrage de Windows
  ChkWindows.Checked := True;
  // Charger les valeurs par défaut
  eMoshaf1.Text     := 'Warsh';
  eNOSora1.Text     := '1';
  eNoPage1.Text     := '1';
  eDitX1.Text       := '20';
  eDitY2.Text       := '20';
  //
  eMoshaf2.Text     := 'Warsh';
  eNOSora2.Text     := '1';
  eNoPage2.Text     := '1';
  eDitX2.Text       := '20';
  eDitY2.Text       := '20';
  //
  Jour.Text         := '0';
  //
  CustomParametres := True;
end;



// عرض موقع القراءة المحفوظة
procedure TFormConfig.BtnLectureClick(Sender: TObject);
begin
  if eMoshaf1.Text = 'Warsh' then
     begin
       FormMoshaf.CheckBoxWarsh.Checked := True;
       FormMoshaf.TypeMoshaf := 'warshtajwid' ;
       FormMoshaf.CheckBoxHafs.Checked := False;
     end
  else
    if eMoshaf1.Text = 'Hafs' then
       begin
         FormMoshaf.CheckBoxHafs.Checked := True;
         FormMoshaf.TypeMoshaf := 'hafstajwid' ;
         FormMoshaf.CheckBoxWarsh.Checked := False;
       end;
  //
  FormMoshaf.eNumPage.Text := eNoPage1.Text;
  FormMoshaf.BtnAffichePageClick(Sender);
end;



// عرض موقع الحفظ المحفوظ
procedure TFormConfig.BtnApprendreClick(Sender: TObject);
begin
  if eMoshaf2.Text = 'Warsh' then
     begin
       FormMoshaf.CheckBoxWarsh.Checked := True;
       FormMoshaf.TypeMoshaf := 'warshtajwid' ;
       FormMoshaf.CheckBoxHafs.Checked := False;
     end
  else
    if eMoshaf2.Text = 'Hafs' then
       begin
         FormMoshaf.CheckBoxHafs.Checked := True;
         FormMoshaf.TypeMoshaf := 'hafstajwid' ;
         FormMoshaf.CheckBoxWarsh.Checked := False;
       end;
  //
  FormMoshaf.eNumPage.Text := eNoPage2.Text;
  FormMoshaf.BtnAffichePageClick(Sender);
end;



// حفظ الملاحظات
procedure TFormConfig.BtnSaveObsClick(Sender: TObject);
Var
  sPath : String;
  myEncoding : TEncoding;
  LinesCount, i : Integer;
begin
   sPath := ExtractFilePath(Application.ExeName);
   sPath := sPath + 'Config.ini';
   myEncoding := TEncoding.UTF8;
   // On créé le fichier Ini dans le répertoire courant s'il n'existe pas
   INI := TMemIniFile.Create(sPath, myEncoding);
   // Boomarker Observation
   LinesCount := MemObs.Lines.Count;
   INI.WriteInteger('Observation', 'Lines Count', LinesCount);
   for I := 0 to LinesCount-1 do
   INI.WriteString('Observation', 'Memo' + IntToStr(I), MemObs.Lines[i]);
   //
   INI.WriteInteger('Adhanday','Jour', Jour.Value);
   //
   INI.UpdateFile;
   // On libère le fichier .ini
   INI.Destroy;
end;




// تفعيل الدخول إلى البرنامج
procedure TFormConfig.FormActivate(Sender: TObject);
Var
  x:integer ;
  rgn : hrgn;
begin
  with FormConfig do
  begin
    // Form Arrondie
    rgn:=CreateRoundRectRgn(0,0,width,height,30,30);
    SetWindowRgn(handle, rgn, true);
  End ;

  // Sauvegarde des valeurs de la page courante du Moshaf
  eMoshaf  := FormMoshaf.TypeMoshaf;
  eNOSora  := FormMoshaf.lbOrdreSora.Caption;
  eNoPage  := FormMoshaf.eNumPage.Text;
  eDitX    := FormMoshaf.edPosX.Text;
  eDitY    := FormMoshaf.edPosY.Text;

  try
    // Chargement des valeurs
    CustomParametres:= false;
    MemObs.Clear;
    LoadSetting(Sender);
  except
    if MyDialog('متصفح القرآن الكريم','خطأ في تحميل قيم الإعدادات. هل تريد الخروج الآن؟', ['نعم', 'لا'],
            mtWarning, [mbYes, mbNo], bdLeftToRight, mbNo).ShowModal = mrYes then
        begin
          Application.Terminate;
        end;
  end;
end;




// الخروج من البرنامج
procedure TFormConfig.FormCloseQuery(Sender: TObject; var CanClose: Boolean);
begin
  FormClose(Sender);
end;




procedure TFormConfig.Image1Click(Sender: TObject);
begin
  Close;
end;

// Une autre façon de personnaliser le message
procedure TFormConfig.FormClose(Sender: TObject);
begin
 if MyDialog('متصفح القرآن الكريم', 'هل تريد الخروج    الآن؟', ['نعم', 'لا'],
                mtWarning, [mbYes, mbNo], bdLeftToRight, mbYes).ShowModal = mrNo then
    begin
       try
        BtnSaveObsClick(Sender);                // حفظ الملاحظات
       finally
        Close;
       end;
    end;
end;




// تحميل الإعدادات
procedure TFormConfig.LoadSetting(Sender: TObject);
Var
  sPath : String;
  LinesCount, i : Integer;
begin
   sPath := ExtractFilePath(Application.ExeName);
   sPath := sPath + 'Config.ini';
   //
   Try
     // Spécifie le nom du fichier .ini à utiliser
     INI := TMemIniFile.Create(sPath);

     // Charge l'état du lancement au démarrage de Windows
     ChkWindows.Checked := INI.ReadBool('Options','Windows', ChkWindows.Checked);

     // Charger les coordonnées de Lecture
     eMoshaf1.Text     := INI.ReadString('Coran1','TypeMohaf', '');
     eNOSora1.Text     := INI.ReadString('Coran1','Sora', '');
     eNoPage1.Text     := INI.ReadString('Coran1','Page', '');
     eDitX1.Text       := INI.ReadString('Coran1','X', '');
     eDitY1.Text       := INI.ReadString('Coran1','Y', '');

     // Charger les coordonnées d'apprentissage
     eMoshaf2.Text     := INI.ReadString('Coran2','TypeMohaf', '');
     eNOSora2.Text     := INI.ReadString('Coran2','Sora', '');
     eNoPage2.Text     := INI.ReadString('Coran2','Page', '');
     eDitX2.Text       := INI.ReadString('Coran2','X', '');
     eDitY2.Text       := INI.ReadString('Coran2','Y', '');

     // Charger le texte Memo
     LinesCount := INI.ReadInteger('Observation', 'Lines Count', 0);
     for I := 0 to LinesCount-1 do
     MemObs.Lines.Insert(I, INI.ReadString('Observation', 'Memo'+IntToStr(I), ''));
     //
     Jour.Value        := INI.ReadInteger('Adhanday','Jour',Jour.Value);
     // On libère le fichier .ini
     INI.Destroy;
   except
     ShowMessage('خطأ في تحميل قيم الإعدادات');
   end;
end;





// حفظ علامة مرجعية القراءة
procedure TFormConfig.N1Click(Sender: TObject);
Var
  sPath : String;
  myEncoding : TEncoding;
  LinesCount, i : Integer;
begin
  sPath := ExtractFilePath(Application.ExeName);
  sPath := sPath + 'Config.ini';
  myEncoding := TEncoding.UTF8;
  //
  // The application automatically when Windows starts
        SetAutoStart(ChkWindows.Checked);
  // On créé le fichier Ini dans le répertoire courant s'il n'existe pas
  INI := TMemIniFile.Create(sPath, myEncoding);
  // Sauvegarde l'état du lancement au démarrage de Windows
  INI.WriteBool('Options','Windows', ChkWindows.Checked);
  INI.WriteString('Coran1','TypeMohaf', eMoshaf);
  INI.WriteString('Coran1','Sora', eNOSora);
  INI.WriteString('Coran1','Page', eNoPage);
  INI.WriteString('Coran1','X', eDitX);
  INI.WriteString('Coran1','Y', eDitY);
  //
  INI.WriteInteger('Adhanday','Jour', Jour.Value);
  //
  INI.UpdateFile;
  // On libère le fichier .ini
  INI.Destroy;

  // Recharger les coordonnées de Lecture
  eMoshaf1.Text     := eMoshaf;
  eNOSora1.Text     := eNOSora;
  eNoPage1.Text     := eNoPage;
  eDitX1.Text       := eDitX;
  eDitY1.Text       := eDitY;
end;


// حفظ علامة مرجعية الحفظ
procedure TFormConfig.N2Click(Sender: TObject);
Var
  sPath : String;
  myEncoding : TEncoding;
  LinesCount, i : Integer;
begin
  sPath := ExtractFilePath(Application.ExeName);
  sPath := sPath + 'Config.ini';
  myEncoding := TEncoding.UTF8;
  //
  // The application automatically when Windows starts
        SetAutoStart(ChkWindows.Checked);
  // On créé le fichier Ini dans le répertoire courant s'il n'existe pas
  INI := TMemIniFile.Create(sPath, myEncoding);
  // Sauvegarde l'état du lancement au démarrage de Windows
  INI.WriteBool('Options','Windows', ChkWindows.Checked);
  INI.WriteString('Coran2','TypeMohaf', eMoshaf);
  INI.WriteString('Coran2','Sora', eNOSora);
  INI.WriteString('Coran2','Page', eNoPage);
  INI.WriteString('Coran2','X', eDitX);
  INI.WriteString('Coran2','Y', eDitY);
  //
  INI.WriteInteger('Adhanday','Jour', Jour.Value);
  //
  INI.UpdateFile;
  // On libère le fichier .ini
  INI.Destroy;

  // Recharger les coordonnées d'Apprentissage
  eMoshaf2.Text     := eMoshaf;
  eNOSora2.Text     := eNOSora;
  eNoPage2.Text     := eNoPage;
  eDitX2.Text       := eDitX;
  eDitY2.Text       := eDitY;
end;


procedure TFormConfig.SpeedButton1Click(Sender: TObject);
begin
  Close;
end;

end.
