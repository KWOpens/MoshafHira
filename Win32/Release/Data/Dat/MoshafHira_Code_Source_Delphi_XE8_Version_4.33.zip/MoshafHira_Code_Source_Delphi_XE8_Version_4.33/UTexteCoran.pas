unit UTexteCoran;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Data.DB, Vcl.Grids, Vcl.DBGrids,
  Vcl.StdCtrls, Vcl.ExtCtrls, Vcl.DBCtrls;

type
  TFormTexteCoran = class(TForm)
    DBGrid3: TDBGrid;
    DBMemoTexteAya: TDBMemo;
    Panel1: TPanel;
    Panel2: TPanel;
    Label2: TLabel;
  private
    { D�clarations priv�es }
  public
    { D�clarations publiques }
  end;

var
  FormTexteCoran: TFormTexteCoran;

implementation

{$R *.dfm}

end.
