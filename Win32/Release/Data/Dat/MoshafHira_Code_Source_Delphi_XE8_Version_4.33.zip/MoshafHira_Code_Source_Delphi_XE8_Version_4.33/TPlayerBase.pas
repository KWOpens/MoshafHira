unit TPlayerBase;

// ----------------------------------------------------------------------------
// TPlayer v.1.3
// Ronald Tilcen, 2001
//
// It is constructed of peaces I collected during surfing the Internet :)
// Big thanx to Carlos Barbosa, Yaron Gur, and others for their support...
//
// This version is adopted for use within Player v.5.0 application development
// and many additional features were removed.
//
// TPLayer suports two playback types: DirectSound and WaveOut.
// The idea was to develop Player applicatin that would try to playback using
// DirectSound Renderer and if it fails then use default WaveOut Renderer.
// The difference is that with WaveOut you can't mix channels (playback more
// than one stream simultanously).
//
// TPlayer v.1.0 is notifying about certain events: EP_BEFORE_OPEN, EP_OPEN,
// EP_COMPLETE (actualy EC_COMPLETE) and some other described below - which
// basicaly are used to update a user interface (control buttons, position-bar,
// ...)
//
// During initialization TPlayer creates a list of available audio output
// devices, so the list can be handly used to choose from that choice. Note
// that the list of audio output devices is of type TStringList, so that it
// can be simply copied in a TComboBox by: TComboBox.Items := TStringList;
// ----------------------------------------------------------------------------

interface

// ----------------------------------------------------------------------------

uses
  windows,
  dialogs,
  sysutils,
  classes,
  mmsystem,
  TPlayerRenderers,
  TPlayerFilters,
  Messages,
  Forms;

// ----------------------------------------------------------------------------

const

// ----------------------------------------------------------------------------
//
// TPLayer Windows Message used to notify event handler window
//
// ----------------------------------------------------------------------------

  WM_PLAYER                                          = WM_APP + 1;

// ----------------------------------------------------------------------------
//
// standard Quartz event codes for user and error defined events:
//
// ----------------------------------------------------------------------------

  EC_USER                                            = $8000;
  EC_SND_DEVICE_ERROR_BASE                           = $0200;

// ----------------------------------------------------------------------------
//
// TPlayerBase primitive event codes (notified only if an operation succeeded):
//
// ----------------------------------------------------------------------------

  // after opening a new file stream
  EP_OPEN                                            = EC_USER + 11;

  // after cleaning graph and freeing used filters
  EP_CLOSE                                           = EC_USER + 12;

  // after started playback of a stream
  EP_PLAY                                            = EC_USER + 13;

  // after stopping playback of a stream
  EP_STOP                                            = EC_USER + 14;

  // after reset of position within a stream (to begining)
  EP_REWIND                                          = EC_USER + 15;

  // after changing device (actualy this informs that a device have been added
  // to the graph and it's up to an aplication to verify if it is the same as
  // selected one - FDeviceIndex is changed to index of device taht is
  // currently added to the graph)
  EP_DEVICECHANGE                                    = EC_USER + 16;

// ----------------------------------------------------------------------------
//
// TPlayerBase primitive event codes (notified if an operation failed):
//
// ----------------------------------------------------------------------------

  // failed opening a new file stream
  EP_ERROR_OPEN                                      = EC_USER + 41;

  // failed playback of a stream
  EP_ERROR_PLAY                                      = EC_USER + 42;

  // failed stopping playback of a stream
  EP_ERROR_STOP                                      = EC_USER + 43;

  // failed rewinding a stream
  EP_ERROR_REWIND                                    = EC_USER + 44;

  // failed to retrieve current volume
  EP_ERROR_GETVOLUME                                 = EC_USER + 45;

  // failed to retrieve current position
  EP_ERROR_GETPOSITION                               = EC_USER + 46;

// ----------------------------------------------------------------------------
//
// TPlayer additional event codes (the process do not return to TPlayer object
// until the message is processed by the event handling window procedure)
//
// ----------------------------------------------------------------------------

  // before opening a new file stream
  EP_BEFORE_OPEN                                     = EC_USER + 31;

  // before stopped playback of a stream
  EP_BEFORE_STOP                                     = EC_USER + 32;

// ----------------------------------------------------------------------------
//
// TPlayerBase additional event codes (notified by IMediaEventEx interface):
//
// Some bla, bla about these messages... When an event handler receives
// WM_PLAYER message, it does not have to worry about freeing the message
// resources, becouse the main "passing a message" process is held in
// TPlayer.GetMediaEvent() which is called by TPlayer.MediaEvent property
// (In general it calls IMediaEventEx.GetEvent() and then after passing a
// message it calls IMediaEventEx.FreeEventParams() on the same message)
//
// ----------------------------------------------------------------------------

  // notifies about an event reported by DirectShow.
  EP_MEDIAEVENT                                      = EC_USER + 20;

  // When an event handling window receives EP_MEDIAEVENT message it means
  // that DirectShow has a new event waiting to be taken from a queue.
  // In this version of TPlayer, an application that have access to TPlayer
  // object can only learn what was the event, by calling TPlayer.MediaEvent.
  // The value returned will be one of the following DirectShow's event:
  //
{
  //                                 A video window is being activated or deactivated.
     EC_ACTIVATE                     = $13;
  //                                 The graph is buffering data, or has stopped buffering data.
     EC_BUFFERING_DATA               = $11;
  //                                 The reference clock has changed.
     EC_CLOCK_CHANGED                = $0D;
  //                                 The clock provider was disconnected.
     EC_CLOCK_UNSET                  = $51;
}
  //                                 All data from a particular stream has been rendered.
     EC_COMPLETE                     = $01;
{
  //                                 A Plug and Play device was removed or has become available again.
     EC_DEVICE_LOST                  = $1f;
  //                                 The display mode has changed.
     EC_DISPLAY_CHANGED              = $16;
  //                                 The end of a segment has been reached.
     EC_END_OF_SEGMENT               = $1C;
  //                                 An asynchronous command to run the graph has failed.
     EC_ERROR_STILLPLAYING           = $08;
  //                                 An operation was aborted because of an error.
     EC_ERRORABORT                   = $03;
  //                                 Not supported.
     EC_EXTDEVICE_MODE_CHANGE	       = $31;
  //                                 The video renderer is switching out of full-screen mode.
     EC_FULLSCREEN_LOST              = $12;
  //                                 The filter graph has changed.
     EC_GRAPH_CHANGED                = $50;
  //                                 The length of a source has changed.
     EC_LENGTH_CHANGED               = $1E;
  //                                 A filter is requesting that the graph be restarted.
     EC_NEED_RESTART                 = $14;
  //                                 Notifies a filter of the video renderer's window.
     EC_NOTIFY_WINDOW                = $19;
  //                                 A filter is passing a text string to the application.
     EC_OLE_EVENT                    = $18;
  //                                 The graph is opening a file, or has finished opening a file.
     EC_OPENING_FILE                 = $10;
  //                                 The video palette has changed.
     EC_PALETTE_CHANGED              = $09;
  //                                 A pause request has completed.
     EC_PAUSED                       = $0E;
  //                                 The graph is dropping samples, for quality control.
     EC_QUALITY_CHANGE               = $0B;
  //                                 A video renderer requires a repaint.
     EC_REPAINT                      = $05;
  //                                 A new segment has started.
     EC_SEGMENT_STARTED              = $1D;
  //                                 The filter graph is shutting down, prior to being destroyed.
     EC_SHUTTING_DOWN                = $0C;
  //                                 An audio device error has occurred on an input pin.
     EC_SNDDEV_IN_ERROR              = EC_SND_DEVICE_ERROR_BASE + $00;
  //                                 An audio device error has occurred on an output pin.
     EC_SNDDEV_OUT_ERROR             = EC_SND_DEVICE_ERROR_BASE + $01;
  //                                 A filter is not receiving enough data.
     EC_STARVATION                   = $17;
  //                                 The filter graph has changed state.
     EC_STATE_CHANGE                 = $32;
  //                                 A filter performing frame stepping has stepped the specified number of frames.
     EC_STEP_COMPLETE                = $24;
  //                                 A stream-control start command has taken effect.
     EC_STREAM_CONTROL_STARTED       = $1B;
  //                                 A stream-control start command has taken effect.
     EC_STREAM_CONTROL_STOPPED       = $1A;
  //                                 An error has occurred in a stream. The stream is still playing.
     EC_STREAM_ERROR_STILLPLAYING    = $07;
  //                                 A stream has stopped because of an error.
     EC_STREAM_ERROR_STOPPED         = $06;
  //                                 Not supported.
     EC_TIMECODE_AVAILABLE		       = $30;
  //                                 The user has terminated playback.
     EC_USERABORT                    = $02;
  //                                 The native video size has changed.
     EC_VIDEO_SIZE_CHANGED           = $0A;
  //                                 The video renderer was destroyed or removed from the graph.
     EC_WINDOW_DESTROYED             = $15;
}
  // I havn't assorted those particular events which refer to the audio devices.
  // Indeed I copied these all from DirectShow.pas, just in case :)

// ----------------------------------------------------------------------------
//
// Volume controllers ranges
//
// ----------------------------------------------------------------------------

  TP_MAX_VOLUME1 = 65535;  // WaveOut volume controller
  TP_MIN_VOLUME1 = 0;

  TP_MAX_VOLUME2 = -10000; // specific device volume controller
  TP_MIN_VOLUME2 = 0;

// ----------------------------------------------------------------------------
//
// Known time format GUIDs (Uuids.h)
//
// ----------------------------------------------------------------------------
                            // No format
  TIME_FORMAT_NONE          : TGUID = (D1:$00000000;D2:$0000;D3:$0000;D4:($00,$00,$00,$00,$00,$00,$00,$00));
                            // Video frames
  TIME_FORMAT_FRAME         : TGUID = (D1:$7B785570;D2:$8C82;D3:$11CF;D4:($BC,$0C,$00,$AA,$00,$AC,$74,$F6));
                            // Byte offset within the stream
  TIME_FORMAT_BYTE          : TGUID = (D1:$7B785571;D2:$8C82;D3:$11CF;D4:($BC,$0C,$00,$AA,$00,$AC,$74,$F6));
                            // Samples in the stream
  TIME_FORMAT_SAMPLE        : TGUID = (D1:$7B785572;D2:$8C82;D3:$11CF;D4:($BC,$0C,$00,$AA,$00,$AC,$74,$F6));
                            // Interlaced video fields
  TIME_FORMAT_FIELD         : TGUID = (D1:$7B785573;D2:$8C82;D3:$11CF;D4:($BC,$0C,$00,$AA,$00,$AC,$74,$F6));
                            // Media time, in 100-nanosecond units
  TIME_FORMAT_MEDIA_TIME    : TGUID = (D1:$7B785574;D2:$8C82;D3:$11CF;D4:($BC,$0C,$00,$AA,$00,$AC,$74,$F6));

// ----------------------------------------------------------------------------

type

// ----------------------------------------------------------------------------
//
// TPLayer state controllers:
//
// ----------------------------------------------------------------------------

  TPlayer_State = (
    fsStopped,
    fsPaused,
    fsPlaying
  );

// ----------------------------------------------------------------------------
//
// TPlayer
//
// ----------------------------------------------------------------------------
  TPlayer = class
  private
    FHandle        : HWND;          // window to notify about TPlayer events
    FFileName      : string;        // currently loaded stream in the graph
    FDuration      : int64;         // stream duration (length) (saved on Open)
    FState         : TPlayer_State; // current state of player
    FDeviceIndex   : Integer;       // currently selected device (default is 0)
    FCurDevIndex   : Integer;       // currently used device (when loaded a stream)
    FAutoPlay      : Boolean;       // start playing immediately after loading a file
    FRewind        : Boolean;       // wheather to reset position after playback
    FForceDevice   : Boolean;       // forces to use user selected device Renderer
    FDeviceVolume  : Boolean;       // use selected device volume (True) or
                                    // default WaveOut volume (False)
    // DirectShow's interfaces
    FMC            : IMediaControl; // (controls basic stream operations)
    FMS            : IMediaSeeking; // (controls positioning in a stream)
    FBA            : IBasicAudio;   // (controls volume and balance (Left/Right))
    FME            : IMediaEventEx; // (gives ability to handle DirectShow's events)

    Filter         : IBaseFilter;   // (current audio renderer when FForceDevice)
    // private members used by propetrties:
    function  GetPosition     : int64;
    function  GetTimeFormat   : TGUID;
    function  GetVolume       : Longint;
    function  GetMediaEvent   : Integer;
    procedure CleanUpGraph;
    procedure LoadFile        (Reload   : Boolean);
    procedure SetPosition     (Position : Int64);
    procedure SetTimeFormat   (Format   : TGUID);
    procedure SetVolume       (Value    : Longint);
    procedure SetWaveOutVolume(Value    : Longint);
    procedure SetDeviceVolume (Value    : Longint);
    procedure WaitForState    (State    : TPlayer_State);
    procedure StopFMC; // only stops the graph and not pauses it after

  protected
    FGraph:   IGraphBuilder;        // IGraphBuilder interface

  public
    constructor Create(Handle : HWND); // with handle of an event handler window
    destructor  Destroy; override;
    // basic commands
    procedure Open(FileName : string); // open a file to stream
    procedure Close;                   // close the opened file and free resources
    procedure Play;                    // playback an opened file-stream
    procedure Pause;                   // pause / resume playback
    procedure Stop;                    // stop playing (and rewind if FRewind is True)
    procedure Rewind;                  // stop playback and set Position to begining
    // additional commands
    property  AutoPlay    : Boolean       read FAutoPlay write FAutoPlay;
    property  Duration    : int64         read FDuration;
    property  DeviceIndex : Integer       read FDeviceIndex  write FDeviceIndex;
    property  DeviceVolume: Boolean       read FDeviceVolume  write FDeviceVolume;
    property  FileName    : string        read FFileName;
    property  ForceDevice : Boolean       read FForceDevice  write FForceDevice;
    property  MediaEvent  : Integer       read GetMediaEvent;
    property  Position    : int64         read GetPosition   write SetPosition;
    property  State       : TPlayer_State read FState;
    property  TimeFormat  : TGUID         read GetTimeFormat write SetTimeFormat;
    property  Volume      : Longint       read GetVolume     write SetVolume;
    // additional stuff
    procedure ChangeDevice;  // if DeviceIndex points  to  another  device than
                             // have the currently loaded stream, then it loads
                             // selected and if FMC is currently running it  is
                             // restarted from the same position (causes hickup)
    function  IsUsingTimeFormat     (Format: TGUID): Boolean;
    function  IsTimeFormatSupported (Format: TGUID): Boolean;
    function  CompareCurTimeFormat  (Format: PGUID): Boolean;
    function  GetRelativeVolume     (Max, SliderSize, Margin : Integer): Integer;
    function  SetRelativeVolume     (Max, SliderSize, MouseOffset, Margin, Value : Integer) : Integer;
    function  GetRelativePosition   (Max : Integer; Margin : Integer) : int64;
    procedure SetRelativePosition   (Max : Integer; Value : Integer; Margin : Integer);
  end;

// ----------------------------------------------------------------------------

var
  // name and index list of all available audio output devices
  // created automaticaly, when this unit is initialized
  TPlayerDeviceList : TStringList;

// ----------------------------------------------------------------------------

var
  // guid list of all available audio output devices
  // for unit inner usage (program)
  TPlayerDeviceGUIDList : TStringList;

// ----------------------------------------------------------------------------

implementation

// ----------------------------------------------------------------------------

uses
  activex,
  TPlayerErrors,
  Math;

// ----------------------------------------------------------------------------
// Ctreate TPlayer; initialize streaming dependent interfaces
// ----------------------------------------------------------------------------
constructor TPlayer.Create(Handle : HWND);
begin
  // set member initial values:
  FHandle      := Handle;    // event handler window
  FState       := fsStopped;
  FCurDevIndex := -1;        // no device is currently loaded
  FForceDevice := false;     // default is to use DirectSound Renderer instead
                             // of WaveOut Renderer (to enable Graph inner-search)
  FDeviceVolume := true;     // by default use selected device volume control
  // reset pointers
  FMC    := nil;
  FMS    := nil;
  FBA    := nil;
  FME    := nil;
  Filter := nil;
  // Get the interface for DirectShow's GraphBuilder
  AssignGraphBuilder( FGraph );
  AssignMediaControl(FGraph, FMC);
  AssignMediaSeeking(FGraph, FMS);
  AssignBasicAudio  (FGraph, FBA);
  // Get the IMediaEventEx Interface
  SCheck( FGraph.QueryInterface(IID_IMediaEventEx, FME) );
  // Attach the IMediaEventEx interface to the main window
  SCheck( FME.SetNotifyWindow(Handle, WM_PLAYER, EP_MEDIAEVENT) );
  // Enable IMediaEventEx notifications
  SCheck( FME.SetNotifyFlags( 0 ) ); // 0=on | 1=off
end;

// ----------------------------------------------------------------------------
// Destroy TPlayer, free used resources
// ----------------------------------------------------------------------------
destructor TPlayer.Destroy;
begin
  FGraph.RemoveFilter( Filter );
  FBA    := nil;
  FMS    := nil;
  FMC    := nil;
  FGraph := nil;
  Filter := nil;
end;

// ----------------------------------------------------------------------------
// Remove all filters from Graph and free used resources. 
// NOTE: before calling this procedure Graph must be stopped, or it might not
//       be able to remove used filters.
// ----------------------------------------------------------------------------
procedure TPlayer.CleanUpGraph;
var
  I       : Integer;
  Enum    : IEnumFilters;
  Count   : Integer;
  Filters : array of IBaseFilter;
//  fi : TFilterInfo;
begin
  if FGraph.EnumFilters( Enum ) = S_OK then
  begin
      Count   := 0;
      // count the currently active filters
      While (Enum.Skip( 1 ) = S_OK) do Inc( Count );
      Enum.Reset;

      SetLength(Filters, Count);
      // load the filters into the array (Fetched can be nil if cFilters is 1)
      For I := 0 to Count - 1 do
        if Enum.Next(1, Filters[I], nil) <> S_OK then Break;
      Enum := nil;

{// Uncomment to see device name that is removed from the graph:
if Count > 0 then
  begin
    Filters[0].QueryFilterInfo( fi );
    ShowMessage('Previous device was: ' + fi.achName);
  end;
}
      // Remove the filters from the graph
      If Count > 0 then For I := 0 to Count-1 do
        begin
          FGraph.RemoveFilter( Filters[I] );
          Filters[I] := nil;
        end;
      { destroy Filters array }
      Filters := nil;
      { destroy reference to the forced filter }
      if Assigned( Filter ) then Filter := nil
    End;
end;

// ----------------------------------------------------------------------------
// Open file specified by TPlayer.FFileName.
//
// This sub-procedure is called from other procedures and must not handle
// any exceptions.
//
// The main idea of this sub-procedure is to not change the TPlayer.FState
// member, becouse it is required so by TPLayer.ChangeDevice().
//
// if parameter Reload is True then this procedure doesn't prepare
// the environment after reloading the same file (so it's a bit faster).
// ----------------------------------------------------------------------------
procedure TPlayer.LoadFile(Reload : Boolean);
  var wFileName : array[0..MAX_PATH] of WideChar;
      _dev_name : string;
begin
    { free filters from Graph }
    CleanUpGraph;
    if FForceDevice then
    { add filter with user specified device by force }
      AddAudioRenderer(FGraph, Filter, FDeviceIndex);
    Filter := nil;
    { Format filename to wide-char Unicode }
    StringToWideChar(FileName, wFileName, Integer(High(wFileName)));
    { Render the graph for the selected file-stream }
    SCheck( FGraph.RenderFile(@wFileName, nil) );
    { if we added a filter by force, we should also verify it's connection }
    if FForceDevice then
      begin
        // check if an apropriate renderer is present
        Filter := GetAudioRenderer( FGraph );
        if not Assigned( Filter ) then
          raise Exception.Create( ERSTR_NO_AUDIO_STREAM );
        // check if renderer is connected
        if not IsFilterConnected( Filter ) then
          raise Exception.Create( ERSTR_DEVICE_NOT_CONNECTED );
      end;
    { Get duration of the loaded file (save it for time economy as it won't
      change until the next file is loaded) }
    SCheck( FMS.GetDuration( FDuration ) );
    { if we are only reloading it doesn't requires to prepare all of
      the environment }
    if not Reload then
      begin
        SetPosition( 0 );
        // kind of strange, but the following will enable to adjust volume
        // before running IMediaControl, but only if not AutoPlay, becouse it
        // will start playing in no time and will not be stopped anyway:
        if not FAutoPlay then FMC.Pause;
      end;
    { save the currently used (selected) audio device }

    { if no matching device is found (?) then FDeviceIndex remains -1 }
    _dev_name := GetFirstAudioRendererName( FGraph );
    FDeviceIndex := TPlayerDeviceList.IndexOf( _dev_name );
    // when the graph makes device name unique it ads four digit number to
    // the end of it; to find original name we have to discard those numbers.
    // Device duplication issues when the same device as beeing added was not
    // removed before that. All in all in TPlayer it shouldn't happen, becouse
    // it stops all filters before removing them from the graph, but just in
    // case...
    if FDeviceIndex = -1 then
      FDeviceIndex := TPlayerDeviceList.IndexOf(
                        Copy(_dev_name, 1, Length(_dev_name) - 5)
                      );
    // notify about change of device completion and don't return immediately
    SendMessage(FHandle, WM_PLAYER, 0, EP_DEVICECHANGE);

{// Uncomment to see device name that is added to the graph:
    ShowMessage('Current device is: ' + _dev_name);
}
end;

// ----------------------------------------------------------------------------
// Open a file-stream, assign needed interfaces
// ----------------------------------------------------------------------------
procedure TPlayer.Open(FileName : string);
begin
  // notify about Open and don't return immediately
  SendMessage(FHandle, WM_PLAYER, 0, EP_BEFORE_OPEN);
  try
    if not FileExists(FileName) then Exception.Create( ERR_NOFILE );
    // set member values
    FFileName := FileName;
    // stop playback or it might cause an error while removing filters from
    // the graph; can't use TPlayer.Stop becouse, it would also pause
    // IMediaControl, but it must be stopped
    //
    // Even if FState = fsStopped it means that TPlayer was stopped by
    // TPlayer.Stop, which pauses FMC after, so it needs to be stopped
    // completely
    If FState <> fsStopped then StopFMC else SCheck( FMC.Stop );
    // load TPlayer.FFileName with selected TPlayer.FDeviceIndex
    LoadFile( false );
    // notify about Open completion and don't return immediately
    SendMessage(FHandle, WM_PLAYER, 0, EP_OPEN);
    // start playing if needed
    if FAutoPlay then Play;
  except
    // notify about failure of Open and don't return immediately
    SendMessage(FHandle, WM_PLAYER, 0, EP_ERROR_OPEN);
    if Assigned( Filter ) then CleanUpGraph;
    raise;
  end;
end;

// ----------------------------------------------------------------------------
// close the opened file-stream (and doesn't return until really closed)
// If no file-stream is open, it will try to free resources, but
// will not generate an error.
// ----------------------------------------------------------------------------
procedure TPlayer.Close;
begin
  // if file-stream is running then stop it and report the Stop message
  //
  // Even if FState = fsStopped it means that TPlayer was stopped by
  // TPlayer.Stop, which pauses FMC after, so it needs to be stopped
  // completely
  if FState = fsPlaying then StopFMC else SCheck( FMC.Stop );
  // reset member values
  FFileName := '';
  // free filters from Graph
  CleanUpGraph;
  // kind of strange, but the following will enable to adjust volume after
  // IMediaControl was stopped:
  SCheck( FMC.Pause );
  // notify about Close completion and don't return immediately
  SendMessage(FHandle, WM_PLAYER, 0, EP_CLOSE);
end;

// ----------------------------------------------------------------------------
// Start playback of the opened file-stream (and doesn't return until playing)
// ----------------------------------------------------------------------------
procedure TPlayer.Play;
begin
  try
    SCheck( FMC.Run ); WaitForState( fsPlaying ); FState := fsPlaying;
    // notify about Open completion and don't return immediately
    SendMessage(FHandle, WM_PLAYER, 0, EP_PLAY);
  except
    // notify about failure of Play and don't return immediately
    SendMessage(FHandle, WM_PLAYER, 0, EP_ERROR_PLAY);
    raise
  end;
end;

// ----------------------------------------------------------------------------
// Pause / Resume the filter graph (don't return until really pause)
// ----------------------------------------------------------------------------
procedure TPlayer.Pause;
begin
  if FState = fsPlaying then
    begin SCheck( FMC.Pause ); FState := fsPaused end
  else
    begin SCheck( FMC.Run ); FState := fsPlaying end;
  WaitForState( FState );
end;

// ----------------------------------------------------------------------------
// This is alike-procedure to TPlayer.Stop. The reason of implementing it is
// that Stop is calling FMC.Stop and then FMC.Pause to enable adjusting
// volume of loaded device (it is calling FMC.Pause before notifying an event
// handler window). While some inner TPlayer procedures need to call only
// FMC.Stop to stop the graph and not to pause it, becouse otherwise those
// procedures would fail (ie CleanUpGraph()).
//
// NOTE: this procedure is not a pablic member of TPlayer  
// ----------------------------------------------------------------------------
procedure TPlayer.StopFMC;
begin
  try
    // notify about Stop and don't return immediately
    SendMessage(FHandle, WM_PLAYER, 0, EP_BEFORE_STOP);
    // stop the stream and update the state marker
    SCheck( FMC.Stop ); WaitForState( fsStopped ); FState := fsStopped;
    // rewind if needed
    if FRewind then Rewind;
    // notify about Stop completion and don't return immediately
    SendMessage(FHandle, WM_PLAYER, 0, EP_STOP);
  except
    // notify about failure of Stop and don't return immediately
    SendMessage(FHandle, WM_PLAYER, 0, EP_ERROR_STOP);
    raise
  end;
end;

// ----------------------------------------------------------------------------
// Stops and pauses the filter graph (and don't return until really stop)
// NOTE: unlike StopFMC this is a public member of TPlayer
// ----------------------------------------------------------------------------
procedure TPlayer.Stop;
begin
  try
    // notify about Stop and don't return immediately
    SendMessage(FHandle, WM_PLAYER, 0, EP_BEFORE_STOP);
    // stop the stream and update the state marker
    SCheck( FMC.Stop ); WaitForState( fsStopped ); FState := fsStopped;
    // rewind if needed
    if FRewind then Rewind;
    // kind of strange, but the following will enable to adjust volume
    // after stopping IMediaControl:
     SCheck( FMC.Pause );
    // notify about Stop completion and don't return immediately
    SendMessage(FHandle, WM_PLAYER, 0, EP_STOP);
  except
    // notify about failure of Stop and don't return immediately
    SendMessage(FHandle, WM_PLAYER, 0, EP_ERROR_STOP);
    raise
  end;
end;

// ----------------------------------------------------------------------------
// set position to begining of the stream
// ----------------------------------------------------------------------------
procedure TPlayer.Rewind;
begin
    try
      SetPosition( 0 );
      // notify about Rewind completion and don't return immediately
      SendMessage(FHandle, WM_PLAYER, 0, EP_REWIND);
    except
      // notify about failure of Rewind and don't return immediately
      SendMessage(FHandle, WM_PLAYER, 0, EP_ERROR_REWIND);
      raise
    end;
end;

// ----------------------------------------------------------------------------
// Wait for the state to change to the given one (before that program is idle)
// ----------------------------------------------------------------------------
procedure TPlayer.WaitForState(State: TPlayer_State);
var
  olfs: OAFilterState;
begin
  repeat FMC.GetState(10, olfs) until (State = TPlayer_State(olfs))
end;

// ----------------------------------------------------------------------------
// Checks if the graph supports desired time format
// NOTE: it doesn't raise exception if one occure
// ----------------------------------------------------------------------------
function TPlayer.IsTimeFormatSupported(Format: TGUID): Boolean;
begin
  if FMS.IsFormatSupported( Format ) = S_OK then
    Result := True else Result := False;
end;

// ----------------------------------------------------------------------------
// Checks if player is currently using the specified time format
// NOTE: it doesn't raise exception if one occure
// ----------------------------------------------------------------------------
function TPlayer.IsUsingTimeFormat(Format: TGUID): Boolean;
begin
  if FMS.IsUsingTimeFormat( Format ) = S_OK then
    Result := True else Result := False;
end;

// ----------------------------------------------------------------------------
// return currently used time format
// ----------------------------------------------------------------------------
function TPlayer.GetTimeFormat : TGUID;
begin
  SCheck( FMS.GetTimeFormat( Result ) )
end;

// ----------------------------------------------------------------------------
// set desired time format
// ----------------------------------------------------------------------------
procedure TPlayer.SetTimeFormat(Format: TGUID);
begin
  SCheck( FMS.SetTimeFormat( Format ) )
end;

// ----------------------------------------------------------------------------
// Does comparesement of currently used and requested time formats and return
// True if they match. The idea:
// 1. check if time format is supported (IsTimeFormatSupported);
// 1. check for current time-format (IsUsingTimeFormat);
// 2. if not desired one then set it (SetTimeFormat);
// 3. again get current time-format and check it with CompareCurTimeFormat()
// ----------------------------------------------------------------------------

//      (D1:$7B785574;D2:$8C82;D3:$11CF;D4:($BC,$0C,$00,$AA,$00,$AC,$74,$F6))

function TPlayer.CompareCurTimeFormat(Format : PGUID) : Boolean;
  var CurFormat : TGUID;
begin
  SCheck( FMS.GetTimeFormat( CurFormat ) );
  if CompareMem(@CurFormat, Format, sizeof(TGUID)) then
    Result := True
  else
    Result := False;
end;

// ----------------------------------------------------------------------------
// return current volume. Returned value depends from FDeviceVolume, which
// specifies wheather the device specific or default WaveOut volume is used.
// NOTE: if set to use device volume, but no file is loaded, returns default
//       WaveOut volume
// ----------------------------------------------------------------------------
function TPlayer.GetVolume: Longint;
  var _volume : dWord;
begin
  try
    if (FDeviceVolume) and (FFileName <> '') then
      // get current device volume
      SCheck( FBA.get_Volume( Result ) )
    else
      begin
        // get current WaveOut volume
        SMCICheck( waveOutGetVolume(0, @_volume) );
        // convert value
        Result := ((_volume shr 16 and $FFFF) + (_volume and $FFFF)) shr 1;
      end;
  except
    // send notify event about this failure, so that application will not
    // try to use this function for a while. This function is usualy
    // used in Timer procedure, so if here is an exeption raised, application
    // must direct such timers not to use this procedure for a while, or
    // a pure user will not be able to fight with all the error dialog-boxes,
    // reporting the same exception!
    // After sending the message the process will don't return immediately:
    SendMessage(FHandle, WM_PLAYER, 0, EP_ERROR_GETVOLUME);
    raise
  end;
end;

// ----------------------------------------------------------------------------
// set volume of standart WaveOut device
// ----------------------------------------------------------------------------
procedure TPlayer.SetWaveOutVolume(Value: Longint);
begin
    SMCICheck( waveOutSetVolume(0, Value shl 16 + Value) );
end;

// ----------------------------------------------------------------------------
// set volume of selected device (TPLayer.FDeviceIndex)
// ----------------------------------------------------------------------------
procedure TPlayer.SetDeviceVolume(Value: Longint);
begin
    SCheck( FBA.put_Volume( Value ) );
end;

// ----------------------------------------------------------------------------
// This procedure is called by TPlayer class property 'Volume'
// NOTE: if set to use device volume, but no file is loaded, it will set default
//       WaveOut volume
// ----------------------------------------------------------------------------
procedure TPlayer.SetVolume(Value: Longint);
begin
  if (FDeviceVolume) and (FFileName <> '')  then
    SetDeviceVolume( Value )
  else
    SetWaveOutVolume( Value );
end;

// ----------------------------------------------------------------------------
// An algorithm to better set the volume. Needed only for device volume.
//
// The problem is that device volume is too loud from middle to top and
// to quiet from middle to bottom when setting with a sliderbar. This algorithm
// solves that like making key-frames in the top side more frequent and in
// the bottom side more rarer.
//
// The code in function is optimized with minimal calculations, but here is
// an expanded variant:
//
//  x := 8;
//  Volume / ((x * 2+1) - (Volume * x / 5000))
//
// by changing x changes the range of volume positioning, I didn't calculated
// x = 8 as the most right one, but I think it makes positioning of volume
// to middle when also the volume slider-bar is in the middle.
// ----------------------------------------------------------------------------
function GetAdjustedVolume(Volume : Integer) : Integer;
begin
  Result := Round(
    Volume / (17 - Volume * 0.0016)
  )
end;

// ----------------------------------------------------------------------------
// A recursive algorithm to resolve the current volume as it would be set by
// GetAdjustedVolume()
// NOTE: Needed only for device volume.
// ----------------------------------------------------------------------------
function ResolveAdjustedVolume(AdjustedVolume : Integer; Min, Max : Single) : Integer;
  var _var : Integer;
begin
    _var := GetAdjustedVolume( Round( Min + Max / 2 ) );
    // the range of match must be at least 10, or it might last very long until
    // program crashes. I guess that there is still a posibility of crash.
    if (AdjustedVolume > _var - 5) and (AdjustedVolume < _var + 5) then
      Result := Round( Min + Max / 2 )
    else
      if AdjustedVolume < _var then
        Result := ResolveAdjustedVolume(AdjustedVolume, Min, Max / 2 )
      else
        Result := ResolveAdjustedVolume(AdjustedVolume, Min + Max / 2, Max / 2 );
end;

// ----------------------------------------------------------------------------
// This function will return the current volume relatively by calculating
// parameter values
// ----------------------------------------------------------------------------
function  TPlayer.GetRelativeVolume (Max, SliderSize, Margin : Integer): Integer;
var _max : Integer;
begin
    _max := Max - SliderSize - 2*Margin;
    if (FDeviceVolume) and (FFileName <> '') then
        Result :=
          Round(
            ((_max)* ResolveAdjustedVolume(Volume*(-1), 0, 10000) ) / TP_MAX_VOLUME2
          ) * (-1)
    else
        Result := Round(
          _max - ((_max)* Volume) / TP_MAX_VOLUME1
        )
end;

// ----------------------------------------------------------------------------
// This function will set the current volume relatively by calculating
// parameter values (actually a windows object parameters)
// ----------------------------------------------------------------------------
// Max         - maximal sliding size (should be > [2*Margin + SliderSize])
// SliderSize  - size (width or height) of the slider control
// MouseOffset - offset of the mouse in the slider client window
// Margin      - minimizes the sliding size from both sides
// Value       - positive or negative value to update the slider position
// ----------------------------------------------------------------------------
// Returns the slider control position in [0..Max] range. You can assign this
// value to the slider control to update the Value position. For i.e.,
// TSlider.Top := TSliderFrm.Top + SetRelativeVolume( ... )
// where 'TSlider' is the sliding control that is in size of SliderSize and
// 'TSliderFrm' is the control that's sliding area is equal to Max
function TPlayer.SetRelativeVolume (Max, SliderSize, MouseOffset, Margin, Value : Integer) : Integer;
begin
  // code is compressed for optimization, so it's hard to follow :(, but economical :)
  Dec(Value, MouseOffset);
  Dec(Max, Margin + SliderSize);
  // validate and correct slider range
  if Value < Margin then Value := Margin
    else
  if Value > Max then Value := Max;
  // the new slider position
  Result := Value;
  // update volume
  Dec(Max, Margin);

  if (FDeviceVolume) and (FFileName <> '') then
    SetDeviceVolume(
      GetAdjustedVolume(
        Round(
          (Value * TP_MAX_VOLUME2) / Max
        ) * (-1)
      ) * (-1)
    )
  else
    SetWaveOutVolume(
      Round(
        ((Max - Value) * TP_MAX_VOLUME1) / Max
      )
    );
end;

// ----------------------------------------------------------------------------
// get position within currently loaded stream
// ----------------------------------------------------------------------------
function TPlayer.GetPosition: int64;
begin
  try
    SCheck( FMS.GetCurrentPosition( Result ) )
  except
    // send notify event about this failure, so that application will not
    // try to use this function for a while. This function is usualy
    // used in Timer procedure, so if here is an exeption raised, application
    // must direct such timers not to use this procedure for a while, or
    // a pure user will not be able to fight with all the error dialog-boxes,
    // reporting the same exception!
    // After sending the message the process will don't return immediately:
    SendMessage(FHandle, WM_PLAYER, 0, EP_ERROR_GETPOSITION);
    raise
  end;
end;

// ----------------------------------------------------------------------------
// update current position in the loaded file-stream
// ----------------------------------------------------------------------------
procedure TPlayer.SetPosition(Position: int64);
begin
  SCheck( FMS.SetPositions(@Position, AM_SEEKING_AbsolutePositioning , nil,
    AM_SEEKING_NoPositioning) );
end;

// ----------------------------------------------------------------------------
// Similary to GetRelativeVolume() returns the current position in a stream
// within the graph
// ----------------------------------------------------------------------------
function  TPlayer.GetRelativePosition(Max : Integer; Margin : Integer) : int64;
begin
    if Duration <> 0 then // avoid division by zero
      Result := ((Max - 2*Margin) * Position) div Duration
    else
      Result := 0;
end;

// ----------------------------------------------------------------------------
// update current position relative to parameter values
// ----------------------------------------------------------------------------
procedure TPlayer.SetRelativePosition (Max : Integer; Value : Integer; Margin : Integer);
begin
    if Value < Margin then Value := Margin
      else
    if Value > Max - Margin then Value := Max - Margin;
    Position := ((Value - Margin) * Duration) div (Max - 2*Margin);
end;

// ----------------------------------------------------------------------------
// Return the next notify event from DirectShow's interface 
// ----------------------------------------------------------------------------
function TPlayer.GetMediaEvent : Integer;
var
  _eventParam1, _eventParam2 : Integer;
begin
    if FME.GetEvent(Result, _eventParam1, _eventParam2, 0) <> E_Abort then
      FME.FreeEventParams(Result, _eventParam1, _eventParam2);
end;

// ----------------------------------------------------------------------------
// By calling this function the selected device (TPlayer.DeviceIndex) is loaded.
//
// When TPlayer.DeviceIndex is changed, it doesn't mean that respective device
// is immediately loaded in the Graph - it will be with the next file-stream
// loaded. But if Graph is playing the stream then by calling this procedure it
// will reload the current file-stream with the selected device and restart
// playing from the same position.
//
// NOTE: if FPlayer is not playing, but a file is loaded, then it will reload
//       the file with selected device.
// NOTE: if no file is loaded, nothing will happen.
// NOTE: if procedure fails and an exception is raised it will report
//       EP_ERROR_OPEN message to the event handler window (it is becouse this
//       procedure is analogical to TPlayer.Open() procedure). If procedure
//       is successful, it will not report any messages of completion.
// ----------------------------------------------------------------------------
procedure TPlayer.ChangeDevice;
  var _pos : int64;
begin
    if (FCurDevIndex <> FDeviceIndex) and (FFileName <> '') then
      begin
      { only if selected device is not the one that is currently loaded }
        try
          try
            { stop if playing or not, but not with TPlayer.Stop, so it won't
              send a message and pause it after that }
            SCheck( FMC.Stop ); WaitForState( fsStopped );
          except
            // notify about failure when stoping and don't return immediately
            SendMessage(FHandle, WM_PLAYER, 0, EP_ERROR_STOP);
            raise
          end;
          { if FRewind is True then if Player is stopped it is also rewinded
            to begining of a stream (so _pos would be zero).
            NOTE: if this fails, TPLayer notifies EP_ERROR_GETPOSITION }
          if not ((FState = fsStopped) and (FRewind)) then _pos := Position;
          try
            { reload the file with selected device }
            LoadFile( true );
          except
            // PLayer was stopped before call to LoadFile()
            if FState <> fsStopped then FState := fsStopped;
            // notify about Stop completion and don't return immediately
            SendMessage(FHandle, WM_PLAYER, 0, EP_STOP);
            raise
          end;
          { if was playing then continue from the same position }
          if not ((FState = fsStopped) and (FRewind)) then Position := _pos;
          if FState = fsPLaying then
            begin
            { run player if it was running before LoadFile() }
              SCheck( FMC.Run );
              WaitForState( fsPlaying );
            end
          else
            begin
              // kind of strange, but the following will enable to adjust
              // volume after IMediaControl was stopped:
              SCheck( FMC.Pause );
              WaitForState( fsPaused );
            end;
        except
          // notify about failure of Open and don't return immediately
          SendMessage(FHandle, WM_PLAYER, 0, EP_ERROR_OPEN);
          if Assigned( Filter ) then CleanUpGraph;
          raise
        end
      end;
end;

// ----------------------------------------------------------------------------
// search for available audio output devices and fill information in
// TPlayerDeviceList and TPlayerDeviceGUIDList
// NOTE: this procedure is not intended to be public
// ----------------------------------------------------------------------------
procedure EnumerateAudioRenderers;
var
  CreateDevEnum : ICreateDevEnum;
  Enum          : IEnumMoniker;
  Moniker       : IMoniker;
  PropBag       : IPropertyBag;
  DevClsid,
  DevName       : OleVariant;
begin
  // Create an enumerator
  SCheck( CoCreateInstance(CLSID_SystemDeviceEnum, nil, CLSCTX_INPROC,
    IID_ICreateDevEnum, CreateDevEnum) );
  // Use the meta-category that contains a list of all audio renderers.
  SCheck( CreateDevEnum.CreateClassEnumerator(CLSID_AudioRendererCategory,
    Enum, 0) );
  // Enumerate over every category. pceltFetched can be nil if celt is 1
  while (Enum.Next(1, Moniker, nil) = S_OK) do
  begin
    // Associate moniker with a file
    if SUCCEEDED(Moniker.BindToStorage(nil, nil, IPropertyBag, PropBag)) then
    begin
      // Read CLSID string from property bag
      If SUCCEEDED(PropBag.Read('CLSID', DevClsid, nil)) then
      begin
        TPlayerDeviceGUIDList.Add(DevClsid);

        // Read filter name. Use the guid if we can't get the name
        if not SUCCEEDED(PropBag.Read('FriendlyName', DevName, nil)) then
          DevName := DevClsid;

        TPlayerDeviceList.Add(DevName);
      end;
    end
    else
      Break;
    { The returned IEnumMoniker interface has an outstanding reference count.
      The caller must release the interface. }
    Moniker := nil
  end;
  Enum := nil;
end;

// ----------------------------------------------------------------------------

initialization

CoInitialize( nil );

TPlayerDeviceList     := TStringList.Create;
TPlayerDeviceGUIDList := TStringList.Create;

EnumerateAudioRenderers;

// ----------------------------------------------------------------------------

finalization

TPlayerDeviceGUIDList.Free;
TPlayerDeviceList.Free;

CoUninitialize;

end.
