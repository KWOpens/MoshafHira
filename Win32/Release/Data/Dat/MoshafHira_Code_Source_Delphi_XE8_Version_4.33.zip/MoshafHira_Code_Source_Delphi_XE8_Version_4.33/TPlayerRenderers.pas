unit TPlayerRenderers;

// ----------------------------------------------------------------------------

interface

uses
  windows,
  classes,
  activex,
  TPlayerFilters,
  TPlayerErrors;

// ----------------------------------------------------------------------------

const
  MAX_FILTER_NAME = 128;

// ----------------------------------------------------------------------------

// Get the interface for DirectShow's GraphBuilder
procedure AssignGraphBuilder(
  var Graph : IGraphBuilder);  // object reference
// ----------------------------------------------------------------------------
// Get the interface for GraphBuilder's MediaControl
procedure AssignMediaControl(
  var Graph : IGraphBuilder;   // object reference
  var FMC : IMediaControl);    // object reference
// ----------------------------------------------------------------------------
// Get the interface for GraphBuilder's MediaSeeking
procedure AssignMediaSeeking(
  var Graph : IGraphBuilder;   // object reference
  var FMS : IMediaSeeking);    // object reference
// ----------------------------------------------------------------------------
// Get the interface for GraphBuilder's BasicAudio
procedure AssignBasicAudio(
  var Graph : IGraphBuilder;   // object reference
  var FBA : IBasicAudio);      // object reference
// ----------------------------------------------------------------------------
// if choosen instantiate audio renderer, add it to the filter graph
procedure AddAudioRenderer(
  var Graph   : IGraphBuilder; // object reference
  var Filter  : IBaseFilter;   // filter to add
  DeviceIndex : Integer);      // audio out device index
// ----------------------------------------------------------------------------
// Graph is sent by reference only for optimization
function GetAudioRenderer(
  var Graph   : IGraphBuilder): IBaseFilter;
// ----------------------------------------------------------------------------
// Graph is sent by reference only for optimization
function GetFirstAudioRendererName(var Graph : IGraphBuilder) : string;
// ----------------------------------------------------------------------------
function IsFilterConnected(const Filter: IBaseFilter): Boolean;
// ----------------------------------------------------------------------------
// Checks if Filter is an audio renderer. If it's a renderer and not audio
// replace it by a null renderer
function CheckFilter(var Graph : IGraphBuilder; Filter: IBaseFilter): Boolean;

// ----------------------------------------------------------------------------

implementation

// ----------------------------------------------------------------------------

uses
  ComObj,
  Sysutils,
//  TPlayerDevices,
  TPlayerBase;

// ----------------------------------------------------------------------------
// Get the interface for DirectShow's GraphBuilder
// ----------------------------------------------------------------------------
procedure AssignGraphBuilder(
  var Graph : IGraphBuilder);  // object reference
begin
  SCheck( CoCreateInstance(CLSID_FilterGraph, nil, CLSCTX_INPROC_SERVER,
    IID_IGraphBuilder, Graph) );
end;

// ----------------------------------------------------------------------------
// Get the interface for DirectShow's MediaControl
// ----------------------------------------------------------------------------
procedure AssignMediaControl(
  var Graph : IGraphBuilder;   // object reference
  var FMC : IMediaControl);    // object reference
begin
    SCheck( Graph.QueryInterface(IID_IMediaControl, FMC) );
end;

// ----------------------------------------------------------------------------
// Get the interface for DirectShow's MediaSeeking
// ----------------------------------------------------------------------------
procedure AssignMediaSeeking(
  var Graph : IGraphBuilder;   // object reference
  var FMS : IMediaSeeking);    // object reference
begin
    SCheck( Graph.QueryInterface(IID_IMediaSeeking, FMS) );
end;

// ----------------------------------------------------------------------------
// Get the interface for DirectShow's BasicAudio
// ----------------------------------------------------------------------------
procedure AssignBasicAudio(
  var Graph : IGraphBuilder;   // object reference
  var FBA : IBasicAudio);      // object reference
begin
    SCheck( Graph.QueryInterface(IID_IBasicAudio,   FBA) );
end;

// ----------------------------------------------------------------------------
// if choosen instantiate audio renderer, add it to the filter graph
// NOTE: be sure to release Filter reference after a call to this procedure.
//       in case of an exception filter is released inside the procedure
// ----------------------------------------------------------------------------
procedure AddAudioRenderer(
  var Graph   : IGraphBuilder; // object reference
  var Filter  : IBaseFilter;   // filter to add
  DeviceIndex : Integer);      // audio device index (one from TPlayerDeviceList)
var
  wstr : array[0..MAX_FILTER_NAME] of WideChar;
begin
  if (DeviceIndex >= 0) and (DeviceIndex < TPlayerDeviceGUIDList.Count) then
  begin
    SCheck( CoCreateInstance(StringToGuid(TPlayerDeviceGUIDList[DeviceIndex]),
      nil, CLSCTX_INPROC_SERVER, IID_IBaseFilter, Filter) );
    try
      StringToWideChar(TPlayerDeviceList[DeviceIndex], @wstr, MAX_FILTER_NAME);
      SCheck( Graph.AddFilter(Filter, {'Audio Renderer'} @wstr) );
    except
      Filter := nil;
      raise Exception.Create( ERSTR_ADD_FILTER_FAILED );
    end;
  end
  else
    raise Exception.Create( ERSTR_NOT_VALID_AUDIO_DEVICE );
end;

// ----------------------------------------------------------------------------
// Graph is sent by reference only for optimization
// ----------------------------------------------------------------------------
function GetAudioRenderer(var Graph : IGraphBuilder): IBaseFilter;
var
  Enum      : IEnumFilters;
  Filter    : IBaseFilter;
begin
  // Get and check all filters in graph
  SCheck( Graph.EnumFilters(Enum) );
  while Enum.Next(1, Filter, nil) = S_OK do
    begin
      if CheckFilter(Graph, Filter) then
        Result := Filter;
      { If the Next() method succeeds, the IBaseFilter pointers all have
        outstanding reference counts. Be sure to release them when done. }
      Filter := nil;
    end;
  Enum := nil;
end;

// ----------------------------------------------------------------------------
// Graph is sent by reference only for optimization
// ----------------------------------------------------------------------------
function GetFirstAudioRendererName(var Graph : IGraphBuilder) : string;
var
  Enum   : IEnumFilters;
  Filter : IBaseFilter;
  fi     : TFilterInfo;
begin
  Result := #0;
  try
    // Get and check all filters in graph
    SCheck( Graph.EnumFilters( Enum ) );
    if Enum.Next(1, Filter, nil) = S_OK then
      begin
          Filter.QueryFilterInfo( fi );
          { If the Next() method succeeds, the IBaseFilter pointers all have
            outstanding reference counts. Be sure to release them when done. }
          Filter := nil;
          Result := fi.achName;
          { If the pGraph member is not NULL, the application should release
            the IFilterGraph interface when it is finished using it }
          if fi.pGraph <> nil then fi.pGraph := nil
      end;
  except end; // just ignore
  Enum := nil;
end;

// ----------------------------------------------------------------------------
// check if any of the filter pins are connected
// ----------------------------------------------------------------------------
function IsFilterConnected(const Filter: IBaseFilter): Boolean;
var
  EnumPins : IEnumPins;
  Pin, Pin2: IPin;
  hr       : HResult;
begin
  Result := False;
  SCheck( Filter.EnumPins( EnumPins ) );
  // pcFetched can be NULL if cPins is 1
  while (EnumPins.Next(1, Pin, nil) = S_OK) do
  begin
    hr := Pin.ConnectedTo( Pin2 );
    if (hr = S_OK) and Assigned( Pin2 ) then Result := True;
    { If the method succeeds, the IPin interface that it returns has
      an outstanding reference count. Be sure to release it when you are done. }
    Pin  := nil;
    Pin2 := nil;
  end;
  EnumPins := nil;
end;

// ----------------------------------------------------------------------------
//  Free an existing media type (ie free resources it holds)
// ----------------------------------------------------------------------------
procedure FreeMediaType(var mt: TAM_MEDIA_TYPE);
begin
  if (mt.cbFormat <> 0) then
  begin
    CoTaskMemFree(mt.pbFormat);
    // Strictly unnecessary but tidier
    mt.cbFormat := 0;
    mt.pbFormat := nil;
  end;
  mt.pUnk := nil;
end;

// ----------------------------------------------------------------------------
// Checks if Filter is an audio renderer. If it's a renderer and not audio
// replace it by a null renderer
// ----------------------------------------------------------------------------
function CheckFilter(var Graph : IGraphBuilder; Filter: IBaseFilter): Boolean;
var
  Enum: IEnumPins;
  Pin,
  Input,
  Output: IPin;
  InCount,
  OutCount: Integer;
  PinDirThis: TPIN_DIRECTION;
  MediaType: TAM_MEDIA_TYPE;
  NullFilter: IBaseFilter;
begin
  Result   := False;
  InCount  := 0;
  OutCount := 0;
  // count number of input/output pins
  SCheck(Filter.EnumPins( Enum ));
  // pcFetched can be NULL if cPins is 1
  while Enum.Next(1, Pin, nil) = S_OK do
  begin
    SCheck( Pin.QueryDirection( PinDirThis ) );
    if PinDirThis = PINDIR_INPUT then
    begin
      Inc( InCount );
      Input := Pin;
      { If the method succeeds, the IPin pointers all have outstanding
        reference counts. Be sure to release them when done. }
      Pin := nil;
    end
    else
      Inc( OutCount );
  end;

  // if there's 0 output pins and 1 input pin it's a renderer
  if (OutCount = 0) and (InCount = 1) then
  begin
    if Input.ConnectionMediaType( MediaType ) = S_OK then
    begin
      // check if it's an audio pin
      if CompareMem(@(MediaType.majorType), @MEDIATYPE_Audio, sizeof(TGUID)) then
        Result := True;
      FreeMediaType(MediaType);

      // if not audio replace for a null renderer
      if not Result then
      begin
        SCheck( CoCreateInstance(CLSID_NullRenderer, nil, CLSCTX_INPROC_SERVER,
          IID_IBaseFilter, NullFilter) );
        SCheck(Graph.AddFilter(NullFilter, {'Void Renderer'}nil));

        SCheck( Input.ConnectedTo( Output ) );
        SCheck( Graph.RemoveFilter( Filter ) );
        Filter := nil;

        // Now connect the upstream filter's out pin to Null's in pin
        SCheck( NullFilter.EnumPins( Enum ) );
        SCheck(Enum.Next(1, Input, nil));
        SCheck(Graph.Connect(Output, Input));

        NullFilter := nil;
        Output := nil
      end;
    end;
  end;
  Input := nil;
  Enum  := nil
end;

end.
