﻿unit MyFuncUtils;


interface

Uses
 Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants,
 System.Classes, Vcl.Graphics, Vcl.Controls, Vcl.Dialogs, Vcl.StdCtrls,
 ExcelXP, Db, Grids, Datasnap.DBClient, Vcl.Shell.ShellCtrls,
 Forms, Vcl.ExtCtrls, UConst;



const
  CR    = #13;     { carriage return character }
  LF    = #10;     { linefeed character }
  Space = #32;     { space character }
  Tab   = #9;      { Tab character }
  CRLF  = CR + LF;


type
  TFindOption = (foCaseSensitive, foWholeWord);
  TFindOptions = set of TFindOption;


  function ReadFile(FileName: string): string;
  function WriteFile(FileName: string; Data: string): boolean;
  function Purge(Msg,substr: string): string;
  function Replace(Msg,substr,repby: string): string;
  function StrCount(Msg, substr: string): integer;
  function Asc(Msg: string): integer;
  function IsIn(SubStr,StrIn: string):boolean;
  function AllowNumKeys(key: char): char;
  function Cut(var S: string; Index,count: integer): string;
  function Num(S: string): integer;
  //
  function droite(substr: string; s: string): string;
  function DroiteDroite(substr: string; s: string): string;
  function gauche(substr: string; s: string): string;
  function GaucheDuDernier(substr: string; s: string): string;
  function NbSousChaine(substr: string; s: string): integer;
  function NDroite(substr: string; s: string;n:integer): string;
  function GaucheNDroite(substr: string; s: string;n:integer): string;
  function StrReplace(Substr,replace,s:string):string;

  function JourEnArabe(j: word): string;
  function DateEnArabe():string;
  function MoisEnArabe(mois: word): string;
  function TailleFichier(Fichier: string): Int64;
  function StrMis(GetTickCountStart: LongWord): string;
  function fGoMoKo(mem: int64): string;

  function ExportToExcel(oDataSet : TClientDataSet; sFile : String): Boolean;  //Cas d'un TClientDataSet(CDS)
  //function ExportToExcel(oDataSet : TDataSet; sFile : String): Boolean;      //Cas d'une base MySQL
  function SomCol(j:integer; i:integer; StringGrid2:TStringGrid):Integer;
  function IsPrime(const Value: LongWord): Boolean;  register;
  function NombreFichiers(sTV:TShellTreeView; tPath:String; tExt:String):Integer;

  function SpaceStr(n: longint): string;
  function ThreeDigitStr(n: Integer): String;
  function TwoDigitStr(n: Integer): String;
  function VersionStr: String;
  function RightAlign(s: String; count: Integer): String;
  function RightStr(s: String; count: Integer): String;
  function FindString(substr, s: String; options: TFindOptions): Integer;
  function LeftStr(const S: string; N: Integer): string;
  function AddChar(C: Char; const S: string; N: Integer): string;
  function AddCharR(C: Char; const S: string; N: Integer): string;
  function MakeStr(C: Char; N: Integer): string;
  function MyDialog(const DlgCaption, DlgText: string;
            DlgButtons: array of string; DlgType: TMsgDlgType; Buttons: TMsgDlgButtons;
            BidiMode: TBiDiMode; DefaultButton: TMsgDlgBtn): TForm;

  procedure ReplaceChars(var S: String; FromCh, ToCh: Char);
  procedure RunDosCommand(CmdLine: String);
  procedure RunProgram( CmdLine: String);
  procedure CountChar(s: String; ch: Char; var N: Integer);
  procedure CountLines(fname: String; var Nlines: Longint);
  procedure MajEntetePageMoshaf(MaPage:Integer; NbreAyat, nOrdre, NameSora:String );

  function NumLigne(YY: integer):integer;

implementation

Uses UCoranMoshaf;

// Mise à jour des infos de la page à afficher
procedure MajEntetePageMoshaf(MaPage:Integer; NbreAyat, nOrdre, NameSora:String );
Var
  MyPage : Integer;
begin
  // Mise à jour des infos de la page à afficher
  //
  FormMoshaf.SoraCDS.First;
  while (Not FormMoshaf.SoraCDS.Eof) Do
     begin
       MyPage := StrToInt(FormMoshaf.SoraCDS.FieldByName('PageMushaf').AsString);
       //
       if MyPage >  MaPage then
          begin
            FormMoshaf.SoraCDS.Prior;
            NbreAyat := FormMoshaf.SoraCDS.FieldByName('AiaCount').AsString;
            nOrdre   := FormMoshaf.SoraCDS.FieldByName('OrdreMushaf').AsString;
            NameSora := FormMoshaf.SoraCDS.FieldByName('Name').AsString;
            //
            FormMoshaf.lbNbreAyatSora.Caption := NbreAyat;
            FormMoshaf.lbOrdreSora.Caption := nOrdre;
            FormMoshaf.lbNameSora.Caption := NameSora;
            //
            Exit;
          end;

        FormMoshaf.SoraCDS.Next;
     end;
end;



// Fonction qui renvoit dans la somme des nombres d'une colonne d'un StringGrid
// j: N°Colonne ----- i: N°Ligne
function SomCol(j:integer; i:integer; StringGrid2:TStringGrid):Integer;
Var
  Valeur : String;
  SomVal, k : Integer;
begin
  SomVal := 0;
  k := 0;
  Valeur := '';
  repeat
    k:=k+1;
    valeur:=StringGrid2.Cells[j,k];        //valeur représente la valeur contenu dans la cellule (Colonne j ; Ligne i)
    if valeur='' then valeur:='0';         //Si une cellule n'a pas de valeur alors valeur = 0
    SomVal := SomVal + StrToInt(valeur);
  until k=i ;
   result := SomVal;
end;



// lit le fichier "filename" et retourne son contenu
function ReadFile(FileName: string): string;
var Fi: textfile; buf: string;
begin
  try
  AssignFile(Fi,FileName);
  Reset(Fi);
  repeat
    readln(Fi,buf);
    result := result + buf;
  until eof(Fi);
  CloseFile(Fi);
  except
    result := '';
  end;
end;



// crée le fichier "filename" et écrit "data" dedans
function WriteFile(FileName, data: string): boolean;
var Fi: textfile;
begin
  if not FileExists(FileName) then
  begin
    result := false;
    exit;
  end;
  try
    AssignFile(Fi,FileName);
    Rewrite(Fi);
    write(fi,data);
    CloseFile(fi);
    result := true;
  except
    result := false;
  end;
end;



// efface toutes les instances de "substr" dans "msg"
function Purge(Msg,substr: string): string;
begin
  while pos(substr,msg)>0 do Delete(msg,pos(substr,msg),length(substr));
  result := msg;
end;



// remplace toutes les instances de "substr" par "repby" dans "msg"
function Replace(Msg,substr,repby: string): string;
begin
  while pos(substr,msg)>0 do
  begin
    Insert(repby,msg,pos(substr,msg));
    Delete(msg,pos(substr,msg),length(substr));
  end;
  result := msg;
end;



// compte le nombre d'instances de "substr" dans "msg"
function StrCount(Msg, substr: string): integer;
begin
  result := 0;
  while pos(substr,msg)>0 do
  begin
    result := result + 1;
    Delete(msg,1,pos(substr,msg)+length(substr));
  end;
end;



// retourne le code ASCII du premier caractère de "msg" (comme ASC() en qbasic)
function Asc(Msg: string): integer;
var i: integer;
begin
  if length(msg)=0 then
  begin
    result := 0;
    exit;
  end;
  result := ord(msg[1]);
end;



// retourne "true" si une instance de "Substr" est trouvée dans "strin"
function IsIn(SubStr,StrIn: string):boolean;
begin
  if pos(substr,strin)>0 then result := true
  else result := false;
end;



// à mettre dans les OnKeyPress de vos Edits qui ne doivent contenir que des nombres
// key := AllowNumKeys(key);
function AllowNumKeys(key: char): char;
begin
  if not (key in ['1','2','3','4','5','6','7','8','9','0',#8]) then result := #0
  else result := key;
end;



// copie "count" caractères de "S" à partir de "index" et les supprime
function Cut(var S: string; Index,count: integer): string;
begin
  result := copy(S,Index,Count);
  Delete(S,index,Count);
end;



// procédure VAL transformée en fonction, évite les erreurs générées par StrToInt
function Num(S: string): integer;
var code, value: integer;
begin
  Val(S,value,code);
  if code<>0 then result := -1
  else result := value;
end;

//********************************************************************************************************************
{Fonctions explode et implode
Ce sont 2 fonctions diponibles par défaut en PHP.
Implode permet de convertir une TstringList en string en séparant chaque élément par le séparateur choisi (par défaut le ';')
Explode réalise l' opération inverse (il faut spécifier aussi le séparateur)
}

function Explode(ch : string; sep: string = ';'):TStringList;
var
 p : integer;
begin
	p := pos(sep,ch);
	explode := TStringList.Create;
	while p > 0 do begin
	  explode.Add(copy(ch,1,p-1));
	  if p <= length(ch) then ch := copy(ch,p+ length(sep),length(ch));
	  p := pos(sep,ch);
	end;
	explode.Add(ch);
end;

function Implode(lst:TStringList; sep : string =';'):string;
var
  i : integer;
  s : string;
begin
	 i:= 0;
	 while i < lst.Count - 1 do begin
	   s := s + lst[i] + sep;
	   i := i + 1;
	 end;
	 if i < lst.Count then s := s + lst[i]; //Ne mets pas de séparateur sur le dernier élément
	 result := s;
end;

//*******************************************************************************************************

function StrReplace(Substr,replace,s:string):string;
{============================================================================}
{remplace toutes les sous-chaines Substr par replace                         }
{ ex : StrReplace ('toto', 'tata', 'le toto est ..') renvoie 'le tata est ..'}
{============================================================================}
var ChaineSource,ChaineCible:string;
    i,TailleChaineRemplacement:integer;
begin
  ChaineSource:=s;
  ChaineCible:='';
  TailleChaineRemplacement:=length(Substr);
  while pos(Substr,ChaineSource)>0 do  //tant que l'on trouve une sous-chaine
  begin
    i:=pos(Substr,ChaineSource)-1; // position de la sous-chaine à remplacer
    ChaineCible:=ChaineCible+copy(ChaineSource,1,i)+replace;
    delete(ChaineSource,1,i+TailleChaineRemplacement);//on retire de chaineTemp
  end;
  Result:=ChaineCible+ChaineSource;
end;

function droite(substr: string; s: string): string;
{============================================================================}
{Renvoie ce qui est à droite d'une sous chaine de caractères                 }
{ ex : Droite('aa', 'phidelsaacom') renvoie com                              }
{============================================================================}

begin
  if pos(substr,s)=0 then result:='' else
    result:=copy(s, pos(substr, s)+length(substr), length(s)-pos(substr, s)+length(substr));
end;

function droiteDroite(substr: string; s: string): string;
{============================================================================}
{ fonction qui renvoie la sous chaine de caractère situè à droite de la sous }
{ chaine substr située la plus à droite                                      }
{ ex: si substr = '\' et S= 'truc\tr\essai.exe droiteDroite renvoie essai.exe}
{============================================================================}
begin
  Repeat
    S:=droite(substr,s);
  until pos(substr,s)=0;
  result:=S;
end;

function gauche(substr: string; s: string): string;
{============================================================================}
{ fonction qui renvoie la sous chaine de caractère situè à gauche de la sous }
{ chaine substr                                                              }
{ ex: si substr = '\' et S= 'truc\tr\essai.exe' gauche renvoie truc           }
{============================================================================}
begin
  result:=copy(s, 1, pos(substr, s)-1);
end;

function GaucheDuDernier(substr: string; s: string): string;
{============================================================================}
{ fonction qui renvoie la sous chaine de caractère situèe à gauche de la     }
{dernière sous chaine substr                                                 }
{ ex: si substr = '\' et S= 'truc\tr\essai.exe' gauche renvoie truc\tr       }
{============================================================================}
var
 s1:string;
 i:integer;
begin
  s1:='';
  for i:=1 to NbSousChaine(substr, s)-1 do
  begin
    s1:=s1+gauche(substr,s)+substr;
    s:=droite(substr,s);
  end;
  s1:=s1+gauche(substr,s);
  result:=s1;
end;

function NbSousChaine(substr: string; s: string): integer;
{==================================================================================}
{ renvoie le nombre de fois que la sous chaine substr est présente dans la chaine S}
{==================================================================================}
begin
  result:=0;
  while pos(substr,s)<>0 do
  begin
    S:=droite(substr,s);
    inc(result);
  end;
end;

function NDroite(substr: string; s: string;n:integer): string;
{==============================================================================}
{ renvoie ce qui est à droite de la n ieme sous chaine substr de la chaine S   }
{==============================================================================}
var i:integer;
begin
  for i:=1 to n do
  begin
    S:=droite(substr,s);
  end;
  result:=S;
end;




function GaucheNDroite(substr: string; s: string;n:integer): string;
{==============================================================================}
{ renvoie ce qui est à gauche de la droite de la n ieme sous chaine substr     }
{ de la chaine S                                                               }
{ ex : GaucheNDroite('/','c:machin\truc\essai.exe',1) renvoie 'truc'           }
{ Permet d'extraire un à un les éléments d'une chaine séparés par un séparateur}
{==============================================================================}
var i:integer;
begin
  S:=S+substr;
  for i:=1 to n do
  begin
    S:=copy(s, pos(substr, s)+length(substr), length(s)-pos(substr, s)+length(substr));
  end;
  result:=copy(s, 1, pos(substr, s)-1);
end;



{==============================================================================}
{ Renvoie le libellé du mois en Arabe                                          }
{==============================================================================}
function  MoisEnArabe(mois: word): string;
 var
   MLA:string;
begin   //donner les mois en Arabe de janvier à décembre dans le même ordre
  case mois of
	  1:MLA :='جانفي'  ;               7 :MLA :='جويلية'  ;
	  2:MLA :='فيفري'  ;               8 :MLA :='اوت'     ;
	  3:MLA :='مارس'   ;               9 :MLA :='سبتمبر'  ;
	  4:MLA :='افريل'  ;               10:MLA :='اكتوبر'  ;
	  5:MLA :='ماي'    ;               11:MLA :='نوفمبر'  ;
	  6:MLA :='جوان'   ;               12:MLA :='ديسمبر'  ;
  end;//  case
 Result:= MLA ;
end;



{==============================================================================}
{ Renvoie le libellé du jour de la semaine                                     }
{==============================================================================}
function  JourEnArabe(j: word): string;
 var JLA:string;
     days: array[1..7] of string;
begin // donner les jours en Arabe
  days[1] := 'الأحد';    //dimanche
  days[2] := 'الإثنين';  // lundi
  days[3] := 'الثلاثاء'; // mardi
  days[4] := 'الأربعاء'; // mercredi
  days[5] := 'الخميس';   // jeudi
  days[6] := 'الجمعة';   // vendredi
  days[7] := 'السبت';    // samedi
  JLA:=days[DayOfWeek(date)] ;
  Result:= JLA ;
end;


{==============================================================================}
{ Renvoie la date du jour en cours en Arabe                                    }
{==============================================================================}
function DateEnArabe():string;
var
  annee,mois,jour :word;
begin
  DecodeDate(Date,annee,mois,jour);// decoder la date du jour
  DateEnArabe:='يوم  '+JourEnArabe(jour)+' '+inttostr(jour)+' '+MoisEnArabe(mois)+' '+inttostr(annee);
  // DateEnArabe reçoit la date jour en Arabe
end;


// Chronomètre :
function StrMis(GetTickCountStart: LongWord): string;
//       Pour mSec = 482596423, renvoie :
//       - 5 jour(s) 14 h 3 min 16 sec 423 ms
var mSec, Z, S, M, H, J: LongWord;
begin mSec := GetTickCount - GetTickCountStart;
  Z := mSec mod 1000;
  S := (mSec div 1000) mod 60;
  M := (mSec div 60000) mod 60;
  H := (mSec div 3600000) mod 24;
  J := (mSec div 86400000);
  result := intToStr(Z) + ' ms';
  if S > 0 then result := intToStr(S) + ' sec ' + Result;
  if M > 0 then result := intToStr(M) + ' min ' + Result;
  if H > 0 then result := intToStr(H) + ' h ' + Result;
  if J > 0 then result := intToStr(J) + ' jour(s) ' + Result;
end;




function TailleFichier(Fichier: string): Int64;
var
  hFile: THandle; HiSize: DWord;
begin
  Result := 0;
  hFile := CreateFile(pWideChar(Fichier), GENERIC_READ, FILE_SHARE_READ, nil, OPEN_EXISTING, 0, 0);
  if hFile <> INVALID_HANDLE_VALUE then
  begin
    Result := GetFileSize(hFile, @HiSize);
    Result := Result + Int64(HiSize) shl 32;
    FileClose(hFile);
  end;
end;


// Conversion Tailles de fichiers en chaînes avec unités (Ko, Mo, etc) variables
// Go: Giga-Octet *** Mo:Mega-Octet *** Ko:Kilo-Octet
function fGoMoKo(mem: int64): string;
var e: integer; s: string; r: real;
begin e := 0; r := mem;
  if r >= 0 then
  begin while r > 1024 do begin r := r / 1024; inc(e); end;
    case e of
      0: s := 'oct';
      1: s := 'Ko';
      2: s := 'Mo';
      3: s := 'Go';
      4: s := 'To';
    end;
    fGoMoKo := FormatFloat('#.###', r) + ' ' + s;
  end;
end; // fGoMoKo


{==============================================================================}
{                                                                              }
{                                                                              }
{ Use this function to export any dataset to Excel:                            }
{                                                                              }
{                                                                              }
{==============================================================================}

Function ExportToExcel(oDataSet : TClientDataSet; sFile : String): Boolean;
var
iCol,iRow : Integer;

oExcel : TExcelApplication;
oWorkbook : TExcelWorkbook;
oSheet : TExcelWorksheet;

begin
  iCol := 0;
  iRow := 0;
  result := True;

  oExcel := TExcelApplication.Create(oExcel);
  oWorkbook := TExcelWorkbook.Create(oExcel);
  oSheet := TExcelWorksheet.Create(oExcel);

  try
    oExcel.Visible[0] := False;
    oExcel.Connect;
  except
    result := False;
    MessageDlg('Excel may not be installed', mtError, [mbOk], 0);
    exit;
  end;

  oExcel.Visible[0] := True;
  oExcel.Caption := 'Beesoft Export Engine';
  oExcel.Workbooks.Add(Null,0);

  oWorkbook.ConnectTo(oExcel.Workbooks[1]);
  oSheet.ConnectTo(oWorkbook.Worksheets[1] as _Worksheet);

  // iRow := 1;

  for iCol:=1 to oDataSet.FieldCount do
    begin
      // oSheet.Cells.Item[iRow,iCol] := oDataSet.FieldDefs.Items[iCol].Name;
      // oSheet.Cells.Item[iRow,iCol] := oDataSet.Fields[iCol-1].FieldName;
    end;

  // iRow := 2;

  oDataSet.Open;
  while NOT oDataSet.Eof do
    begin
      Inc(iRow);

      for iCol:=1 to oDataSet.FieldCount do
        begin
          oSheet.Cells.Item[iRow,iCol] := oDataSet.Fields[iCol-1].AsString;
        end;

      oDataSet.Next;
    end;

  //Change the wprksheet name.
  oSheet.Name := 'List of Accounts';

  //Change the font properties of all columns.
  oSheet.Columns.Font.Color := clPurple;
  oSheet.Columns.Font.FontStyle := fsBold;
  oSheet.Columns.Font.Size := 10;

  //Change the font properties of a row.
  oSheet.Range['A1','A1'].EntireRow.Font.Color := clNavy;
  oSheet.Range['A1','A1'].EntireRow.Font.Size := 16;
  oSheet.Range['A1','A1'].EntireRow.Font.FontStyle := fsBold;
  oSheet.Range['A1','A1'].EntireRow.Font.Name := 'Arabic Transparent';

  //Change the font properties of a row.
  oSheet.Range['A2','A2'].EntireRow.Font.Color := clBlue;
  oSheet.Range['A2','A2'].EntireRow.Font.Size := 12;
  oSheet.Range['A2','A2'].EntireRow.Font.FontStyle := fsBold;
  oSheet.Range['A2','A2'].EntireRow.Font.Name := 'Arabic Transparent';
  oSheet.Range['A2','H2'].HorizontalAlignment := xlHAlignCenter;
  {
  //Change the font properties of a column.
  oSheet.Range['A1','C1'].EntireColumn.Font.Color := clBlue;

  //Change Cells color of a row.
  oSheet.Range['A1', 'A1'].EntireRow.Interior.Color := clNavy;

  //Change Cells color of a column.
  oSheet.Range['C1', 'C1'].EntireColumn.Interior.Color := clYellow;

  //Align a column.
  oSheet.Range['A1','A1'].HorizontalAlignment := xlHAlignLeft;

  //Set a column with manually.
  // oSheet.Columns.Range['A1','A1'].ColumnWidth := 16;
  }
  //Auto fit all columns.
  oSheet.Columns.AutoFit;


  DeleteFile(sFile);

  Sleep(2000);

  oSheet.SaveAs(sFile);
  oSheet.Disconnect;
  oSheet.Free;

  oWorkbook.Disconnect;
  oWorkbook.Free;

  oExcel.Quit;
  oExcel.Disconnect;
  oExcel.Free;
end;


//
// Fonction permettant de tester si un nombre decimal est premier
//
function IsPrime(const Value: LongWord): Boolean;  register;
    function ISqrt(I: LongWord): LongWord;  register;
    asm
      push  $00
      push  eax
      fild  qword ptr[esp]
      fsqrt
      wait
      fistp dword ptr[esp]
      wait
      pop    eax
      add    esp,$04
      or    eax,$01
    end;
asm
    push  ebx
    push  esi
    push  edi
    mov    ecx,eax        // ecx = Value
    xor    eax,eax        // Result:=false
    bt    ecx,0          // si Value paire, retour false
    jnc    @fin
    mov    eax,ecx
    call  ISqrt
    mov    esi,eax        // esi = racine de Value
    mov    ebx,3          // démarrage crible à i := 3
    @R:                  // crible
    xor    edx,edx        // nettoyage reste division
    mov    eax,ecx        // remise Value en eax
    div    ebx            // diviser par i
    mov    edi,eax        // placer le quotient en edi
    mov    eax,edx        // placer le reste en Result
    test  eax,eax        // si reste = 0 , Value divisible donc retour false
    jz    @fin
    add    ebx,2          // incrémenter i de 2
    cmp    edi,esi        // quotient >= à sqrt(Value) ?
    ja    @R            // non on réitère
    mov    eax,$01        // oui Result:=true
    @fin:
    pop    edi
    pop    esi
    pop    ebx
end;



{
--------------------------------------
Compter tous les fichiers d'un repertoire
--------------------------------------
Donc, il faut modifier comme suit :
if FindFirst(ShellTreeView1.Path + '\*.*', faAnyFile, Info)}

function NombreFichiers(sTV:TShellTreeView; tPath:String; tExt:String):Integer;
var
  Info: TSearchRec;
  Nombre: Integer;
begin
  nombre:= 0;
  sTV.Path := tPath;
  //
  if FindFirst(sTV.Path + tExt, faAnyFile, Info)= 0 then
    begin
      Nombre:= Nombre+1;
      while FindNext(Info)= 0 do
            Nombre:= Nombre+1;
      FindClose(Info);
    end;
    Result := nombre;
end;




// Retourne une chaine de caracteres de n espaces (#32)
function SpaceStr(n: longint): string;
var
  j: longint;
begin { SpaceStr }
  Result := '';
  for j := 1 to n do Result := Result + Chr(32);
end; { SpaceStr }


function ThreeDigitStr(n: Integer): String;
{ Makes a string of three digits representing the number 'n';
the number ought to lie in the interval [0, 999] }
var s: String;
begin { threedigitstr }
  Str(n, s);
  while Length(s) < 3
  do s := '0' + s;
  threedigitstr := s
end;  { threedigitstr }



function TwoDigitStr(n: Integer): String;
{ Makes a string of two digits representing the number 'n';
the number ought to lie in the interval [0, 99] }
var s: String;
begin { Twodigitstr }
  Str(n, s);
  if n < 10
  then TwoDigitStr := '0' + s
  else TwoDigitStr := s
end;  { Twodigitstr }




function VersionStr: String;
{ Returns a string that represents the date of creation of the
  executable file of the program that's being executed }
const
  Month: array[1..12] of string =
    ('January', 'February', 'March', 'April', 'May', 'June', 'July',
     'August', 'September', 'October', 'November', 'December');
var
  DateTime: TDateTime;
  Filehandle, Filedate: longint;
  yy, mm, dd: word;
begin { VersionStr }
  Filehandle := FileOpen( ParamStr( 0), fmShareDenyNone);
  Filedate := FileGetDate( Filehandle);
  FileClose( Filehandle);
  DateTime := FileDateToDateTime( FileDate);
  DecodeDate( DateTime, yy, mm, dd);
  Result := IntToStr( dd) + ' ' + Month[mm] + ' ' + IntToStr( yy);
end;  { VersionStr }




procedure ReplaceChars(var S: String; FromCh, ToCh: Char);
{ Replaces characters in string that are equal to FromCh with
characters ToCh }
var p: Integer;
begin { ReplaceChars }
  for p := 1 to Length(S)
  do if S[p] = FromCh
     then S[p] := ToCh;
end;  { ReplaceChars }



function RightAlign(s: String; count: Integer): String;
{ Returns a string with length Count, with s at the right and
padded with spaces to the left }
begin { RightAlign }
  if Length(s) > count
  then RightAlign := Copy(s, count, Length(s)-count)
  else RightAlign := SpaceStr(count - Length(s)) + s
end;  { RightAlign }



function RightStr(s: String; count: Integer): String;
begin
  RightStr := Copy(s, Length(s)-count+1, count)
end;  { RightStr }



function LeftStr(const S: string; N: Integer): string;
begin
  Result := AddCharR(' ', S, N);
end;


function AddChar(C: Char; const S: string; N: Integer): string;
begin
  if Length(S) < N then
    Result := MakeStr(C, N - Length(S)) + S
  else Result := S;
end;



function AddCharR(C: Char; const S: string; N: Integer): string;
begin
  if Length(S) < N then
    Result := S + MakeStr(C, N - Length(S))
  else Result := S;
end;



function MakeStr(C: Char; N: Integer): string;
begin
  if N < 1 then Result := ''
  else begin
{$IFNDEF WIN32}
    if N > 255 then N := 255;
{$ENDIF WIN32}
    SetLength(Result, N);
    FillChar(Result[1], Length(Result), C);
  end;
end;



procedure RunDosCommand(CmdLine: String);
{ Runs Dos command as if it were started from the command line,
explicitly calling command.com }
var Result: Integer;
begin { RunDosCommand }
  CmdLine := 'command.com' + ' /C ' + Cmdline + Chr(0);
  Result := WinExec(@CmdLine[1], sw_minimize);
  if Result < 32
  then ShowMessage('Execution of command line' + CRLF +
                   LeftStr(CmdLine, Length(CmdLine)-1) + CRLF +
                   'failed. Error code:' + IntToStr(result));
end;  { RunDosCommand }



(*
procedure RunProgram(CmdLine: String);
{ Runs program as if it were started from the command line }
var
  ExecResult: Integer;
  Filename: array[0..100] of Char;
  p, H: Integer;
begin { RunProgram }
  CmdLine := Cmdline + Chr(0);
  ExecResult := WinExec(@CmdLine[1], sw_restore);
  if ExecResult < 32
  then ShowMessage('Execution of command line' + CRLF +
                   LeftStr(CmdLine, Length(CmdLine)-1) + CRLF +
                   'failed. Error code:' + IntToStr(ExecResult));
  {p := Pos(' ', CmdLine);
  CmdLine := LeftStr(CmdLine, p-1) + Chr(0);}
  Application.ProcessMessages;
  H := GetModuleHandle(@CmdLine[1]);
end;  { RunProgram }
*)


procedure RunProgram( CmdLine: String);
{ Runs program as if it were started from the command line }
begin
  CmdLine := Cmdline + Chr(0);
  if WinExec( @CmdLine[1], sw_ShowNormal) < 32
  then MessageDlg( 'Failed to execute ' + CmdLine, mtError, [mbOK], 0);
end;  { RunProgram }





procedure CountChar(s: String; ch: Char; var N: Integer);
{ Counts the number of times a character occurs in a string }
var p: Integer;  { position in string }
begin { CountChar }
  N := 0;
  for p := 1 to Length(s)
  do if s[p] = ch
     then Inc(N)
end;  { CountChar }




procedure CountLines(fname: String; var Nlines: Longint);
{ Counts the number of lines in a text file; returns
  zero if file doesn't exist }
var
  infile: Text;
begin { CountLines }
  if not FileExists(fname)
  then Nlines := 0
  else begin
    AssignFile(infile, fname);
    Reset(infile);
    Nlines := 0;
    while not Eof(infile)
    do begin
      Readln(infile);
      Inc(Nlines);
    end;
    Close(infile);
  end;
end;  { CountLines }



function FindString(substr, s: String; options: TFindOptions): Integer;
{ Finds substring in a string; options e.g.: whole word; case-sensitive }
const
  WordChars = ['a'..'z', 'A'..'Z', #128..#168];
var
  p, l: Integer;
  Found: Boolean;
begin { FindString }
  if not (foCaseSensitive in options)
  then begin
    substr := UpperCase(substr);
    s := UpperCase(s);
  end;
  if not (foWholeWord in options)
  then FindString := Pos(substr, s)
  else begin
    repeat
      Found := False;
      l := length(substr);
      p := Pos(substr, s);
      if p <> 0
      then begin
        Found := True;
        if p > 1
        then if s[p-1] in WordChars
             then Found := False;
        if p+l <= Length(s)
        then if s[p+l] in WordChars
             then Found := False;
        if not Found
        then s[p] := Chr(Ord(s[p])+1); { this trick makes Pos find the next
                                        occurrence when called next time }
      end
    until Found or (p=0);
    FindString := p;
  end;
end;  { FindString }





//Affichage d'un message
function MyDialog(const DlgCaption, DlgText: string;
  DlgButtons: array of string; DlgType: TMsgDlgType; Buttons: TMsgDlgButtons;
  BidiMode: TBiDiMode; DefaultButton: TMsgDlgBtn): TForm;
Var
  I, CntBtns: Integer;
  F: TForm;
  Btn: TMsgDlgBtn;
begin
  // Check for strings
  CntBtns:= 0;
  for Btn in Buttons do
    begin
      Inc(CntBtns);
    end;
  //
  if Length(DlgButtons) <> CntBtns then
    raise Exception.Create('DlgButtons and Buttons params should have the same count');

  //Get the Form created by CreateMessageDialog function
  F:= CreateMessageDialog(DlgText, DlgType, Buttons, DefaultButton);

  // Set the Caption of th form
  F.Caption:= DlgCaption;

  // Change the buttons Captions
  for I := Low(DlgButtons) to High(DlgButtons) do
    TButton(F.Components[I+2]).Caption:= DlgButtons[I];

  // Check for bidimode
  if BidiMode = bdRightToLeft then
    begin
      TImage(F.Components[0]).Left:= (F.Width - (TImage(F.Components[0]).Left + TImage(F.Components[0]).Width));
      TLabel(F.Components[1]).Left:= (TImage(F.Components[0]).Left - (TLabel(F.Components[0]).Width + 10));
    end;

  // Return the form
  Result:= F;
end;


// Détermination de la Ligne du clic de la souris Point(X, Y)
function NumLigne(YY: integer):integer;
var
  j1, Lig1 : integer;
begin
  j1:=1;
  //
  While YY > LL[j1] do
    begin
      Inc(j1);
    end;
  if (j1 MOD 2) = 0 then
     Lig1 := j1 div 2
  else
     Lig1 := (j1-1) div 2;

   // Retourne le n° de la ligne sur la page du moshaf
   Result := Lig1;
end;

end.

