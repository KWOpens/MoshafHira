unit UZoomPage;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.StdCtrls, Vcl.ComCtrls, Vcl.ExtCtrls,
  Vcl.Imaging.pngimage, Math;

type
  TFormZoomPage = class(TForm)
    Label1: TLabel;
    Panel1: TPanel;
    Panel2: TPanel;
    Image1: TImage;
    Image2: TImage;
    Image3: TImage;
    TrackBar1: TTrackBar;
    ScrollBox1: TScrollBox;
    imgmain: TImage;
    procedure TrackBar1Change(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure FormActivate(Sender: TObject);
    procedure Image3Click(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private
    bmpmain: TBitmap;
  public
    { Public declarations }
end;

var
  FormZoomPage: TFormZoomPage;

const
  FULLSCALE = 100;


implementation

{$R *.dfm}

Uses UCoranMoshaf;

procedure TFormZoomPage.FormActivate(Sender: TObject);
Var
  rgn : hrgn;
begin
  with FormZoomPage do
  begin
    //rgn:=CreateRoundRectRgn(0,0,width,height,30,30);
    //SetWindowRgn(handle, rgn, true);
  End ;
  //
  imgmain.Left := 0;
  imgmain.Top := 0;
  imgmain.Picture.Assign(FormMoshaf.BMPWork);
  //
  FormZoomPage.width  := imgmain.width+60;
  FormZoomPage.height := imgmain.height+120;
  //
  bmpmain := TBitmap.Create;
  bmpmain.Assign(FormMoshaf.ImageMoshaf.Picture.Graphic);
  bmpmain.PixelFormat := pf32bit;
  //
  TrackBar1.Min := FULLSCALE div 10;   // %10
  TrackBar1.Max := FULLSCALE * 2;      // %200
  TrackBar1.PageSize := (TrackBar1.Max - TrackBar1.Min) div 19;
  TrackBar1.Frequency := TrackBar1.PageSize;
  TrackBar1.Position := FULLSCALE;
end;




procedure TFormZoomPage.FormCreate(Sender: TObject);
begin
  ClientWidth := 300;
  with HorzScrollBar do
    begin
      { Initialise la port�e avec le double de ClientWidth }
      { Cela signifie que la fiche poss�de une taille physique deux fois }
      { plus grande que celle de fen�tre physique. }
      { Remarquez que la port�e doit toujours �tre plus grande que ClientWidth }

      Range := 600;
      Position := Range - ClientWidth; { Commence avec une fiche enti�rement d�fil�e}
      Increment := 10;  { En cliquant sur la fl�che de d�filement, la fiche d�file de 10 pixels }
      Visible := True;  { Montre la barre de d�filement }
    end;
end;

procedure TFormZoomPage.FormDestroy(Sender: TObject);
begin
  bmpmain.Free;
end;



procedure TFormZoomPage.Image3Click(Sender: TObject);
begin
  Close;
end;



procedure TFormZoomPage.TrackBar1Change(Sender: TObject);
var
  Zoom: Integer;
begin
  Zoom := TrackBar1.Position;
  if not (Visible or (Zoom = FULLSCALE)) or (Zoom = 0) then
    Exit;
  //
  SetMapMode(imgmain.Canvas.Handle, MM_ISOTROPIC);
  SetWindowExtEx(imgmain.Canvas.Handle, FULLSCALE, FULLSCALE, nil);
  SetViewportExtEx(imgmain.Canvas.Handle, Zoom, Zoom, nil);
  //
  imgmain.Width  := Round(bmpmain.Width * Zoom / FULLSCALE);
  imgmain.Height := Round(bmpmain.Height * Zoom / FULLSCALE);
  if Assigned(imgmain.Picture.Graphic) then
    begin
      imgmain.Picture.Graphic.Width  := imgmain.Width;
      imgmain.Picture.Graphic.Height := imgmain.Height;
      //
      FormZoomPage.width  := imgmain.width;
      FormZoomPage.height := imgmain.height+65;
    end;
  imgmain.Canvas.Draw(0, 0, bmpmain);
  //
  Label1.Caption := IntToStr(Round(TrackBar1.Position / FULLSCALE * 100)) + '%';
end;

end.
