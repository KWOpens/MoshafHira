﻿unit UFahresN;

interface

uses
  Windows, Messages, SysUtils,Classes, Graphics, Controls, Forms,
  Dialogs, Grids, DBGrids, ExtCtrls, StdCtrls, jpeg, Data.DB;

type
  TFormFahresN = class(TForm)
    Panel1: TPanel;
    Panel2: TPanel;
    Label1: TLabel;
    Panel3: TPanel;
    Image1: TImage;
    DBGrid1: TDBGrid;
    Panel4: TPanel;
    Button1: TButton;
    RadioGroupChoixTri: TRadioGroup;
    Image2: TImage;
    Image3: TImage;
    Image4: TImage;
    procedure Button1Click(Sender: TObject);
    procedure RadioGroupChoixTriClick(Sender: TObject);
  private
    { Déclarations privées }
  public
    { Déclarations publiques }
  end;

var
  FormFahresN: TFormFahresN;


implementation

{$R *.dfm}

Uses UCoranMoshaf;


procedure TFormFahresN.Button1Click(Sender: TObject);
begin
  Close;
end;


procedure TFormFahresN.RadioGroupChoixTriClick(Sender: TObject);
begin
  if RadioGroupChoixTri.Items[RadioGroupChoixTri.ItemIndex] = ' المصحف' then
        FormMoshaf.SoraCDS.IndexFieldNames := 'SoraNo' ;
  if RadioGroupChoixTri.Items[RadioGroupChoixTri.ItemIndex] = 'النزول' then
        FormMoshaf.SoraCDS.IndexFieldNames := 'OrdreNouzoul' ;
  if RadioGroupChoixTri.Items[RadioGroupChoixTri.ItemIndex] = 'مكان النزول' then
        FormMoshaf.SoraCDS.IndexFieldNames := 'LieuNouzoul' ;
  if RadioGroupChoixTri.Items[RadioGroupChoixTri.ItemIndex] = 'عدد الآيات' then
        FormMoshaf.SoraCDS.IndexFieldNames := 'AiaCount' ;
  if RadioGroupChoixTri.Items[RadioGroupChoixTri.ItemIndex] = 'رقم الصفحة' then
        FormMoshaf.SoraCDS.IndexFieldNames := 'PageMushaf' ;
end;


end.
