object FormTexteCoran: TFormTexteCoran
  Left = 0
  Top = 0
  BiDiMode = bdRightToLeft
  Caption = 'FormTexteCoran'
  ClientHeight = 710
  ClientWidth = 444
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  ParentBiDiMode = False
  PixelsPerInch = 96
  TextHeight = 13
  object DBGrid3: TDBGrid
    Tag = 1
    Left = 0
    Top = 65
    Width = 444
    Height = 425
    Margins.Left = 2
    Margins.Top = 2
    Margins.Right = 2
    Margins.Bottom = 2
    Align = alClient
    DataSource = FormMoshaf.DataSource2
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'MS Sans Serif'
    Font.Style = []
    Options = [dgTitles, dgColumnResize, dgColLines, dgRowLines, dgTabs, dgConfirmDelete, dgCancelOnExit, dgTitleClick]
    ParentFont = False
    TabOrder = 0
    TitleFont.Charset = DEFAULT_CHARSET
    TitleFont.Color = clWindowText
    TitleFont.Height = -11
    TitleFont.Name = 'MS Sans Serif'
    TitleFont.Style = []
    Columns = <
      item
        Expanded = False
        FieldName = 'SORANO'
        Title.Caption = #1585#1602#1605' '#1575#1604#1587#1608#1585#1577
        Width = 80
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'AIANO'
        Title.Caption = #1585#1602#1605' '#1575#1604#1570#1610#1577
        Visible = True
      end>
  end
  object DBMemoTexteAya: TDBMemo
    Tag = 1
    Left = 0
    Top = 490
    Width = 444
    Height = 131
    Margins.Left = 2
    Margins.Top = 2
    Margins.Right = 2
    Margins.Bottom = 2
    Align = alBottom
    DataField = 'AIAMADINA'
    DataSource = FormMoshaf.DataSource2
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -24
    Font.Name = 'Traditional Arabic'
    Font.Style = [fsBold]
    ParentFont = False
    ReadOnly = True
    ScrollBars = ssBoth
    TabOrder = 1
    ExplicitTop = 494
  end
  object Panel1: TPanel
    Left = 0
    Top = 621
    Width = 444
    Height = 89
    Align = alBottom
    TabOrder = 2
  end
  object Panel2: TPanel
    Left = 0
    Top = 0
    Width = 444
    Height = 65
    Align = alTop
    TabOrder = 3
    object Label2: TLabel
      Left = 123
      Top = 4
      Width = 165
      Height = 49
      Margins.Left = 2
      Margins.Top = 2
      Margins.Right = 2
      Margins.Bottom = 2
      Caption = #1606#1589' '#1575#1604#1602#1585#1570#1606' '#1575#1604#1603#1585#1610#1605' '
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -32
      Font.Name = 'Traditional Arabic'
      Font.Style = [fsBold]
      ParentFont = False
    end
  end
end
