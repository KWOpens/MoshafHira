object FormDhikrJour: TFormDhikrJour
  Left = 0
  Top = 0
  BiDiMode = bdRightToLeft
  Caption = #1584#1603#1585' '#1575#1604#1610#1608#1605
  ClientHeight = 561
  ClientWidth = 584
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -13
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  ParentBiDiMode = False
  Position = poDesktopCenter
  OnActivate = FormActivate
  OnCreate = FormCreate
  PixelsPerInch = 96
  TextHeight = 16
  object Panel1: TPanel
    Left = 0
    Top = 0
    Width = 584
    Height = 561
    Align = alClient
    TabOrder = 0
    object ImageDhikrJour: TImage
      Left = 1
      Top = 1
      Width = 582
      Height = 559
      Align = alClient
      Stretch = True
      ExplicitLeft = 280
      ExplicitTop = 152
      ExplicitWidth = 105
      ExplicitHeight = 105
    end
  end
end
