object DataM: TDataM
  OldCreateOrder = False
  Height = 293
  Width = 535
  object FDTabAyaPos: TFDTable
    IndexFieldNames = 'AIANO'
    Connection = FDConnectionMySQL
    UpdateOptions.UpdateTableName = 'quranDB.ayapos'
    TableName = 'quranDB.ayapos'
    Left = 240
    Top = 40
    object FDTabAyaPosAIANO: TIntegerField
      FieldName = 'AIANO'
      Origin = 'AIANO'
      Required = True
    end
    object FDTabAyaPosSORANO: TIntegerField
      AutoGenerateValue = arDefault
      FieldName = 'SORANO'
      Origin = 'SORANO'
    end
    object FDTabAyaPosAIANOS: TIntegerField
      AutoGenerateValue = arDefault
      FieldName = 'AIANOS'
      Origin = 'AIANOS'
    end
    object FDTabAyaPosNOLINE: TIntegerField
      AutoGenerateValue = arDefault
      FieldName = 'NOLINE'
      Origin = 'NOLINE'
    end
    object FDTabAyaPosNOPAGE: TIntegerField
      AutoGenerateValue = arDefault
      FieldName = 'NOPAGE'
      Origin = 'NOPAGE'
    end
    object FDTabAyaPosPOSX: TIntegerField
      AutoGenerateValue = arDefault
      FieldName = 'POSX'
      Origin = 'POSX'
    end
    object FDTabAyaPosPOSY: TIntegerField
      AutoGenerateValue = arDefault
      FieldName = 'POSY'
      Origin = 'POSY'
    end
  end
  object FDQAyaPos: TFDQuery
    Connection = FDConnectionMySQL
    SQL.Strings = (
      'select * from ayapos')
    Left = 344
    Top = 40
    object FDQAyaPosAIANO: TIntegerField
      FieldName = 'AIANO'
      Origin = 'AIANO'
      Required = True
    end
    object FDQAyaPosSORANO: TIntegerField
      AutoGenerateValue = arDefault
      FieldName = 'SORANO'
      Origin = 'SORANO'
    end
    object FDQAyaPosAIANOS: TIntegerField
      AutoGenerateValue = arDefault
      FieldName = 'AIANOS'
      Origin = 'AIANOS'
    end
    object FDQAyaPosNOLINE: TIntegerField
      AutoGenerateValue = arDefault
      FieldName = 'NOLINE'
      Origin = 'NOLINE'
    end
    object FDQAyaPosNOPAGE: TIntegerField
      AutoGenerateValue = arDefault
      FieldName = 'NOPAGE'
      Origin = 'NOPAGE'
    end
    object FDQAyaPosPOSX: TIntegerField
      AutoGenerateValue = arDefault
      FieldName = 'POSX'
      Origin = 'POSX'
    end
    object FDQAyaPosPOSY: TIntegerField
      AutoGenerateValue = arDefault
      FieldName = 'POSY'
      Origin = 'POSY'
    end
  end
  object DSAyaPosCDS: TDataSource
    DataSet = DataAyaPosCDS
    Left = 240
    Top = 160
  end
  object DataAyaPosCDS: TClientDataSet
    Aggregates = <>
    Params = <>
    ProviderName = 'DSPAyaPosCDS'
    Left = 344
    Top = 160
    object DataAyaPosCDSAIANO: TIntegerField
      FieldName = 'AIANO'
      Origin = 'AIANO'
      Required = True
    end
    object DataAyaPosCDSSORANO: TIntegerField
      FieldName = 'SORANO'
      Origin = 'SORANO'
    end
    object DataAyaPosCDSAIANOS: TIntegerField
      FieldName = 'AIANOS'
      Origin = 'AIANOS'
    end
    object DataAyaPosCDSNOLINE: TIntegerField
      FieldName = 'NOLINE'
      Origin = 'NOLINE'
    end
    object DataAyaPosCDSNOPAGE: TIntegerField
      FieldName = 'NOPAGE'
      Origin = 'NOPAGE'
    end
    object DataAyaPosCDSPOSX: TIntegerField
      FieldName = 'POSX'
      Origin = 'POSX'
    end
    object DataAyaPosCDSPOSY: TIntegerField
      FieldName = 'POSY'
      Origin = 'POSY'
    end
  end
  object DSPAyaPosCDS: TDataSetProvider
    DataSet = FDTabAyaPos
    Left = 456
    Top = 160
  end
  object DSFDTabAyaPos: TDataSource
    DataSet = FDTabAyaPos
    Left = 240
    Top = 97
  end
  object DSFDQAyaPos: TDataSource
    DataSet = FDQAyaPos
    Left = 344
    Top = 96
  end
  object FDPhysMySQLDriverLink1: TFDPhysMySQLDriverLink
    DriverID = 'MySQL'
    VendorHome = 'C:\Program Files (x86)\MySQL\MySQL Server 5.7'
    VendorLib = 'libmysql.dll'
    Left = 72
    Top = 195
  end
  object FDConnectionMySQL: TFDConnection
    ConnectionName = 'MySQLconnection'
    Params.Strings = (
      'Server=localhost'
      'Database=quranDB'
      'User_Name=root'
      'CharacterSet=utf8'
      'Password=hadi'
      'DriverID=MySQL')
    LoginPrompt = False
    Left = 72
    Top = 27
  end
  object FDGUIxLoginDialog1: TFDGUIxLoginDialog
    Provider = 'Forms'
    Left = 72
    Top = 139
  end
  object FDGUIxWaitCursor1: TFDGUIxWaitCursor
    Provider = 'Forms'
    Left = 72
    Top = 83
  end
end
