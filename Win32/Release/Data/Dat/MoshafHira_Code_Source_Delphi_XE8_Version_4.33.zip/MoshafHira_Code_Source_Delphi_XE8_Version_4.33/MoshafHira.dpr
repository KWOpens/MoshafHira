﻿program MoshafHira;

{$R *.dres}

uses
  Vcl.Forms,
  UCoranMoshaf in 'UCoranMoshaf.pas' {FormMoshaf},
  UAbout in 'UAbout.pas' {FormAbout},
  URecherche in 'URecherche.pas' {FormRecherche},
  MyFuncUtils in 'MyFuncUtils.pas',
  Vcl.Themes,
  Vcl.Styles,
  UConfig in 'UConfig.pas' {FormConfig},
  UDhikrJour in 'UDhikrJour.pas' {FormDhikrJour},
  UConst in 'UConst.pas',
  UFahresN in 'UFahresN.pas' {FormFahresN},
  UGoPage in 'UGoPage.pas' {FormGoPage},
  TMPlayer in 'TMPlayer.pas' {FormPlayer},
  UDataM in 'UDataM.pas' {DataM: TDataModule};

{$R *.res}
    // program needs to take actions that require administrator privileges,
    // declared in a manifest file uac_manifest.manifest
{$R UAC.RES}


begin
  Application.Initialize;
  Application.Title :=   'المتصفح الإلكتروني  للقرآن الكريم - حراء';
  Application.HelpFile := 'HelpMoshafHira.chm';
  Application.MainFormOnTaskbar := True;
  Application.CreateForm(TFormMoshaf, FormMoshaf);
  Application.CreateForm(TFormAbout, FormAbout);
  Application.CreateForm(TFormRecherche, FormRecherche);
  Application.CreateForm(TFormConfig, FormConfig);
  Application.CreateForm(TFormDhikrJour, FormDhikrJour);
  Application.CreateForm(TFormFahresN, FormFahresN);
  Application.CreateForm(TFormGoPage, FormGoPage);
  Application.CreateForm(TFormPlayer, FormPlayer);
  Application.CreateForm(TDataM, DataM);
  Application.Run;
end.
