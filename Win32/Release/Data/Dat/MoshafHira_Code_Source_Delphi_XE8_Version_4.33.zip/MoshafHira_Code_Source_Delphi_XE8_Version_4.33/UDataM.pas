unit UDataM;

interface

uses
  System.SysUtils, System.Classes, Data.DB, FireDAC.Stan.Intf,
  FireDAC.Stan.Option, FireDAC.Stan.Param, FireDAC.Stan.Error, FireDAC.DatS,
  FireDAC.Phys.Intf, FireDAC.DApt.Intf, FireDAC.Stan.Async, FireDAC.DApt,
  FireDAC.Phys.MySQLDef, FireDAC.UI.Intf, FireDAC.Stan.Def, FireDAC.Stan.Pool,
  FireDAC.Phys, FireDAC.Phys.MySQL, FireDAC.VCLUI.Login, FireDAC.VCLUI.Wait,
  FireDAC.Comp.UI, FireDAC.Comp.Client, Datasnap.Provider, Datasnap.DBClient,
  FireDAC.Comp.DataSet;

type
  TDataM = class(TDataModule)
    FDTabAyaPos: TFDTable;
    FDQAyaPos: TFDQuery;
    DSAyaPosCDS: TDataSource;
    DataAyaPosCDS: TClientDataSet;
    DSPAyaPosCDS: TDataSetProvider;
    DSFDTabAyaPos: TDataSource;
    DSFDQAyaPos: TDataSource;
    FDPhysMySQLDriverLink1: TFDPhysMySQLDriverLink;
    FDConnectionMySQL: TFDConnection;
    FDGUIxLoginDialog1: TFDGUIxLoginDialog;
    FDGUIxWaitCursor1: TFDGUIxWaitCursor;
    FDTabAyaPosAIANO: TIntegerField;
    FDTabAyaPosSORANO: TIntegerField;
    FDTabAyaPosAIANOS: TIntegerField;
    FDTabAyaPosNOLINE: TIntegerField;
    FDTabAyaPosNOPAGE: TIntegerField;
    FDTabAyaPosPOSX: TIntegerField;
    FDTabAyaPosPOSY: TIntegerField;
    FDQAyaPosAIANO: TIntegerField;
    FDQAyaPosSORANO: TIntegerField;
    FDQAyaPosAIANOS: TIntegerField;
    FDQAyaPosNOLINE: TIntegerField;
    FDQAyaPosNOPAGE: TIntegerField;
    FDQAyaPosPOSX: TIntegerField;
    FDQAyaPosPOSY: TIntegerField;
    DataAyaPosCDSAIANO: TIntegerField;
    DataAyaPosCDSSORANO: TIntegerField;
    DataAyaPosCDSAIANOS: TIntegerField;
    DataAyaPosCDSNOLINE: TIntegerField;
    DataAyaPosCDSNOPAGE: TIntegerField;
    DataAyaPosCDSPOSX: TIntegerField;
    DataAyaPosCDSPOSY: TIntegerField;
  private
    { D�clarations priv�es }
  public
    { D�clarations publiques }
  end;

var
  DataM: TDataM;

implementation

{%CLASSGROUP 'Vcl.Controls.TControl'}

{$R *.dfm}

end.
