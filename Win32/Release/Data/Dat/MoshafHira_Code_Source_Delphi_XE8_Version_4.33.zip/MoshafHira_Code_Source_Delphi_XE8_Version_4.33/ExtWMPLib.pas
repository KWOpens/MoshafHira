unit ExtWMPLib;
 
interface
uses WMPLib_TLB, classes;
 
type
  TWindowsMediaPlayer = class(WMPLib_TLB.TWindowsMediaPlayer)
  private
    function GetAutoPlay: Boolean;
    procedure SetAutoPlay(const Value: Boolean);
  public
    function AddToPlayList(const bstrName: WideString; aPlayList: IWMPPlaylist = nil): Boolean; overload;
    function AddToPlayList(const Names: TStrings; aPlayList: IWMPPlaylist = nil): Boolean; overload;
    function LoadPlayList(const bstrName: WideString; const Create: WordBool = False): Boolean;
    function newPlaylist(const bstrName: WideString{; const bstrURL: WideString}): IWMPPlaylist;
    function newMedia(const bstrURL: WideString): IWMPMedia;
    property AutoPlay: Boolean read GetAutoPlay write SetAutoPlay;
  end;
implementation
 
{ TWindowsMediaPlayer }
 
function TWindowsMediaPlayer.AddToPlayList(const bstrName: WideString;
  aPlayList: IWMPPlaylist): Boolean;
var I: Integer;
begin
  Result := False;
  if aPlayList = nil then
    aPlayList := DefaultInterface.currentPlaylist;
  if Assigned(aPlayList) then
    {with DefaultInterface do }begin
      for I := 0 to aPlayList.count-1 do
        if bstrName = aPlayList.Item[I].sourceURL then Exit;
      aPlayList.appendItem(newMedia(bstrName));
      Result := True;
    end;
end;
 
function TWindowsMediaPlayer.AddToPlayList(const Names: TStrings;
  aPlayList: IWMPPlaylist): Boolean;
var I: Integer;
  //SL: TStringList;
begin
  Result := False;
  if not Assigned(Names) then Exit;
  TStringList(Names).Sorted := True;
  for I := 0 to Names.Count-1 do begin
    Result := AddToPlayList(Names[I]);
  end;
end;
 
function TWindowsMediaPlayer.GetAutoPlay: Boolean;
begin
  Result := DefaultInterface.settings.autoStart;
end;
 
function TWindowsMediaPlayer.LoadPlayList(
  const bstrName: WideString; const Create: WordBool = False): Boolean;
begin
  Result := False;
  with DefaultInterface.playlistCollection.getByName(bstrName) do
  begin
    if Count > 0 then begin
      DefaultInterface.currentPlaylist := Item(0);
      Result := True;
    end
    else
    if Create then begin
      DefaultInterface.currentPlaylist := newPlaylist(bstrName);
      Result := True;
    end;
  end;
end;
 
function TWindowsMediaPlayer.newMedia(
  const bstrURL: WideString): IWMPMedia;
begin
  Result := DefaultInterface.mediaCollection.add(bstrURL);
end;
 
function TWindowsMediaPlayer.newPlaylist(const bstrName{, bstrURL}: WideString): IWMPPlaylist;
begin
  Result := DefaultInterface.playlistCollection.newPlaylist(bstrName);
end;
 
procedure TWindowsMediaPlayer.SetAutoPlay(const Value: Boolean);
begin
  DefaultInterface.settings.autoStart := Value;
end;
 
end.