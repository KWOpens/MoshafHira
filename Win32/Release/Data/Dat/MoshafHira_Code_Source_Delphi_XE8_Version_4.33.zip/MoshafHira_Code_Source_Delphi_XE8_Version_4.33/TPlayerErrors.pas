unit TPlayerErrors;

// ----------------------------------------------------------------------------

interface

// ----------------------------------------------------------------------------

uses
  windows,
  sysutils,
  TPlayerFilters;

// ----------------------------------------------------------------------------

resourcestring
  // error strings
  ERSTR_NO_AUDIO_STREAM        = 'Specified file doesn''t have any audio stream.';
  ERSTR_DEVICE_NOT_CONNECTED   = 'Selected audio device not connected.';
  ERSTR_NOT_VALID_AUDIO_DEVICE = 'Not a valid audio device specified.';
  ERSTR_ADD_FILTER_FAILED      = 'Couldn''t add the specified audio filter.';
  ERR_NOFILE                   = 'The specified file can not be found.';
  ERR_UNKNOWN                  = 'Player encountered unrecognized error value.';

const
  VFW_S_DUPLICATE_NAME         = $0004022D;

// ----------------------------------------------------------------------------
// raises an appropriate exception if Value is not zero
function SCheck( Value: HRESULT ): HRESULT; { Check the result of a COM operation }
// ----------------------------------------------------------------------------
// raises an appropriate exception if Value is not zero
function SMCICheck( Value: Longint ): Longint;
// ----------------------------------------------------------------------------
// get error description specified by parameter
function GetMCIDeviceErrorMessage(Error : Longint) : string;
// ----------------------------------------------------------------------------
// a macro for checking a return value
{$DEFINE SUCCEEDED(Value) (HRESULT)(Value >= 0) }

// ----------------------------------------------------------------------------

implementation

// ----------------------------------------------------------------------------

uses
  MMSystem;

// ----------------------------------------------------------------------------
const
  quartz = 'quartz.dll';

// ----------------------------------------------------------------------------
// Check the result of a COM operation, raise exception if there was a failure 
// ----------------------------------------------------------------------------
function SCheck(Value: HRESULT) : HRESULT;
var
  S: array [0..300] of Char;
begin
  Result := Value;

  if (Value <> S_OK) and
     // not complited, but partial successful 
     (Value <> S_FALSE) and
     // the Filter Graph Manager modified the filter name to avoid duplication.
     (Value <> VFW_S_DUPLICATE_NAME)
       then
  begin
    Case DWord(Value) of
      DWord(REGDB_E_CLASSNOTREG)   : S:='A specified class is not registered in the registration database.';
      DWord(CLASS_E_NOAGGREGATION) : S:='This class cannot be created as part of an aggregate.';
      DWord(E_ABORT)               : S:='Operation aborted.';
      DWOrd(E_INVALIDARG)          : S:='One of the parameters is invalid.';
      DWord(E_POINTER)             : S:='This method tried to access an invalid pointer.';
      DWord(E_NOINTERFACE)         : S:='No interface.';
      DWord(E_OUTOFMEMORY)         : S:='Insufficient memory to complete the task.';
      Else
        if AMGetErrorText(Value, S, High( S )) = 0 then StrPCopy(@S, ERR_UNKNOWN);
    end;
    raise Exception.Create( S );
  end;
end;

// ----------------------------------------------------------------------------
// Check the result of a MCI operation, raise exception if there was a failure
// ----------------------------------------------------------------------------
function SMCICheck( Value: Longint ): Longint;
var
  S  : String;
begin
  Result := Value;

  if (Value <> 0) then
  begin
    case Error of
      MMSYSERR_INVALHANDLE  : S := 'Specified device handle is invalid.';
      MMSYSERR_NODRIVER     : S := 'No device driver is present.';
      MMSYSERR_NOMEM        : S := 'Unable to allocate or lock memory.';
      MMSYSERR_NOTSUPPORTED : S := 'Function is not supported.';
      MMSYSERR_BADDEVICEID  : S := 'Specified device identifier is out of range.';
    else
      S := ERR_UNKNOWN;
    end;
    raise Exception.Create( S );
  end;
end;

// ----------------------------------------------------------------------------
// get error description for the specified MCI error value
// ----------------------------------------------------------------------------
function GetMCIDeviceErrorMessage(Error : Longint) : string;
begin
  case Error of
    MMSYSERR_INVALHANDLE  : Result := 'Specified device handle is invalid.';
    MMSYSERR_NODRIVER     : Result := 'No device driver is present.';
    MMSYSERR_NOMEM        : Result := 'Unable to allocate or lock memory.';
    MMSYSERR_NOTSUPPORTED : Result := 'Function is not supported.';
    MMSYSERR_BADDEVICEID  : Result := 'Specified device identifier is out of range.';
  else
    Result := ERR_UNKNOWN;
  end;
end;

// ----------------------------------------------------------------------------

end.
