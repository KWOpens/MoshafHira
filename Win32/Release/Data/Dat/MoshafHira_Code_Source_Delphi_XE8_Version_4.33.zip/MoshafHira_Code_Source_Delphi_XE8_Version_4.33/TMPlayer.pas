﻿unit TMPlayer;

{$R-}

// ----------------------------------------------------------------------------

interface

// ----------------------------------------------------------------------------

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  Buttons, ExtCtrls, StdCtrls, TPlayerBase, ComCtrls, Vcl.Imaging.jpeg, XiPanel;

// ----------------------------------------------------------------------------

resourcestring
  ERR_NODEVICES = 'There are no currently present audio devices.';

// ----------------------------------------------------------------------------

type
  TFormPlayer = class(TForm)
    cmbDevices: TComboBox;
    Label1: TLabel;
    Timer1: TTimer;
    chkForceDevice: TCheckBox;
    chkWaveOutVolume: TCheckBox;
    XiPanel1: TXiPanel;
    btStop: TSpeedButton;
    btPlayPause: TSpeedButton;
    btOpen: TSpeedButton;
    sldPositionFrm: TLabel;
    sldPosition: TPanel;
    sldVolumeFrm: TPanel;
    sldVolume: TPanel;
    Image1: TImage;
    Label2: TLabel;
    procedure btOpenClick(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure btStopClick(Sender: TObject);
    procedure Timer1Timer(Sender: TObject);
    procedure sldVolume1MouseDown(Sender: TObject; Button: TMouseButton;
      Shift: TShiftState; X, Y: Integer);
    procedure sldVolume1MouseUp(Sender: TObject; Button: TMouseButton;
      Shift: TShiftState; X, Y: Integer);
    procedure FormDestroy(Sender: TObject);
    procedure sldVolume1MouseMove(Sender: TObject; Shift: TShiftState; X,
      Y: Integer);
    procedure sldPositionFrmMouseDown(Sender: TObject;
      Button: TMouseButton; Shift: TShiftState; X, Y: Integer);
    procedure sldPositionMouseDown(Sender: TObject; Button: TMouseButton;
      Shift: TShiftState; X, Y: Integer);
    procedure cmbDevicesChange(Sender: TObject);
    procedure btPlayPauseClick(Sender: TObject);
    procedure chkForceDeviceClick(Sender: TObject);
    procedure chkWaveOutVolumeClick(Sender: TObject);
    procedure FormActivate(Sender: TObject);
    procedure Image1Click(Sender: TObject);
  private
    { Private declarations }
    FPlayer        : TPlayer;
    FCanPosition   : Boolean;
    FCanVolume     : Boolean;
    FMouseCaptured : Boolean;
    FMouseOffset   : Integer;
    //
    procedure WMNCHitTest(var M: TWMNCHitTest); message wm_NCHitTest;
  public
    { Public declarations }
    procedure WMPlayer(var Message : TMessage); message WM_PLAYER;
  end;

// ----------------------------------------------------------------------------

var
  FormPlayer: TFormPlayer;

// ----------------------------------------------------------------------------

implementation

{$R *.DFM}

Uses UCoranMoshaf;


// pour pouvoir déplacer la form
procedure TFormPlayer.WMNCHitTest(var M: TWMNCHitTest);
begin
  inherited;                    { call the inherited message handler }
  if  M.Result = htClient then  { is the click in the client area?   }
    M.Result := htCaption;      { if so, make Windows think it's     }
                                { on the caption bar.                }
end;




// ----------------------------------------------------------------------------
// disable timer, free used resources
// ----------------------------------------------------------------------------
procedure TFormPlayer.FormDestroy(Sender: TObject);
begin
  Timer1.Enabled := false; // disable timer so it do not try to call destroyed
                           // parts of FPlayer while FPlayer is not completely
                           // destroyed.
  {if Assigned(FPlayer) then
  begin
    FPlayer.Free;          // must be freed so that FPlayer.Destroy() is invoked
    FPlayer := nil;
  end; }
  //
  Close;
end;



// ----------------------------------------------------------------------------
// Close Formlayer
// ----------------------------------------------------------------------------
procedure TFormPlayer.Image1Click(Sender: TObject);
begin
  FormDestroy(Sender);
end;



// ----------------------------------------------------------------------------
// set-up UI, create FPlayer
// ----------------------------------------------------------------------------
procedure TFormPlayer.FormCreate(Sender: TObject);
begin
  { add all found devices to the combo-box; terminate if there are no devices }
  if TPlayerDeviceList.Count <> 0 then
    begin
      cmbDevices.Items := TPlayerDeviceList;
      cmbDevices.ItemIndex := 0;
    end
  else
    begin
      Exception.Create( ERR_NODEVICES );
      Halt( 0 );
    end;
  { initiate TPlayer object }
  FPlayer             := TPlayer.Create( Handle );
  FPlayer.ForceDevice := false;
  FPlayer.AutoPlay    := true;
  { initiate Test application variables }
  sldPosition.Width   := 0;
  FCanVolume          := true;
end;



// Form Arrondie
procedure TFormPlayer.FormActivate(Sender: TObject);
Var
  rgn : hrgn;
begin
  with FormPlayer do
  begin
    rgn:=CreateRoundRectRgn(0,0,width,height,30,30);
    SetWindowRgn(handle, rgn, true);
  End ;
  //
  btOpenClick(Sender);
end;



// ----------------------------------------------------------------------------
// load audio file page mp3
// ----------------------------------------------------------------------------
procedure TFormPlayer.btOpenClick(Sender: TObject);
Var
  nMP3 : String;
begin
  nMP3 := FormMoshaf.nFileMP3;
  //
  try
    FPlayer.Open(nMP3);
    FCanVolume   := true;
    FCanPosition := true;
  except
    ShowMessage('لم يعثر على ملف الصوت');
  end;
end;




// ----------------------------------------------------------------------------
// play / pause
// ----------------------------------------------------------------------------
procedure TFormPlayer.btPlayPauseClick(Sender: TObject);
begin
    if FPlayer.State = fsPlaying then
      begin
         FPlayer.Pause;
         btPlayPause.Caption := 'شغل';
      end
    else
      begin
         FPlayer.Play;
         btPlayPause.Caption := 'راحة';
      end

end;

// ----------------------------------------------------------------------------
// stop
// ----------------------------------------------------------------------------
procedure TFormPlayer.btStopClick(Sender: TObject);
begin
    if FPlayer.state <> fsStopped then
      begin
        FPlayer.Stop;
        FPlayer.Rewind; // because FPlayer.Rewind is False
      end;
end;

// ----------------------------------------------------------------------------
// update UI, show current volume and position
// ----------------------------------------------------------------------------
procedure TFormPlayer.Timer1Timer(Sender: TObject);
begin
    { update position }
    if (FCanPosition) then
      sldPosition.Width := FPlayer.GetRelativePosition(
                              sldPositionFrm.Width,
                              sldPosition.Tag
                           );
    { update volume }
    if FCanVolume and not FMouseCaptured then
      sldVolume.Top := sldVolumeFrm.Top + FPlayer.GetRelativeVolume(
                                            sldVolumeFrm.Height,
                                            sldVolume.Height,
                                            sldVolume.Tag
                                          );
end;

// ----------------------------------------------------------------------------
// send all mouse events to the volume slider
// ----------------------------------------------------------------------------
procedure TFormPlayer.sldVolume1MouseDown(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
begin
  Mouse.Capture  := sldVolume.Handle;
  FMouseCaptured := true;
  FMouseOffset   := Y;
end;

// ----------------------------------------------------------------------------
// captured handle is now released automaticaly
// ----------------------------------------------------------------------------
procedure TFormPlayer.sldVolume1MouseUp(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
begin
  FMouseCaptured := false;
end;

// ----------------------------------------------------------------------------
// when moving volume slider up and down
// ----------------------------------------------------------------------------
procedure TFormPlayer.sldVolume1MouseMove(Sender: TObject; Shift: TShiftState; X,
  Y: Integer);
begin
  if not (FMouseCaptured and FCanVolume)then Exit;
  // do not allow to come in here (another MouseMove()) until finished
  FCanVolume := false;
  // verify that a new slider position do not jump out of the slider
  sldVolume.Top := sldVolumeFrm.Top +
    FPlayer.SetRelativeVolume(
      sldVolumeFrm.Height,                    // Maximal sliding height
      sldVolume.Height,                       // Slider handle
      FMouseOffset,                           // cursor position on the slider-bar
      sldVolume.Tag,                          // Tag holds a margin value
      (sldVolume.Top - sldVolumeFrm.Top) + Y  // Y can be positive or negative
    );
  // let to come in now another MouseMove()
  FCanVolume := true;
end;

// ----------------------------------------------------------------------------
// seek a new position (foreward) within a file-stream
// ----------------------------------------------------------------------------
procedure TFormPlayer.sldPositionFrmMouseDown(Sender: TObject;
  Button: TMouseButton; Shift: TShiftState; X, Y: Integer);
begin
    // do not allow to come in here until finished
    if not FCanPosition then Exit;
    FCanPosition := false;
    // set new position
    FPLayer.SetRelativePosition(sldPositionFrm.Width, X, sldPosition.Tag);
    // let to come in now
    FCanPosition := true;
end;

// ----------------------------------------------------------------------------
// seek a new position (backward) within a file-stream
// ----------------------------------------------------------------------------
procedure TFormPlayer.sldPositionMouseDown(Sender: TObject;
  Button: TMouseButton; Shift: TShiftState; X, Y: Integer);
begin
    // do not allow Timer1 to update the current position if media is running
    if not FCanPosition then Exit;
    FCanPosition := false;
    // set new position
    FPLayer.SetRelativePosition(sldPositionFrm.Width, sldPosition.Tag + X, sldPosition.Tag);
    // let Timer1 continue to update current position
    FCanPosition := true;
end;

// ----------------------------------------------------------------------------
// receive messages from FPlayer and update UI accordingly
// ----------------------------------------------------------------------------
procedure TFormPlayer.WMPlayer(var Message : TMessage);
begin
  case Message.LParam of

      EP_BEFORE_OPEN       : btOpen.Enabled := false;
      EP_OPEN              :
        begin
          btOpen.Enabled      := true;
          btPlayPause.Enabled := true;
        end;
      EP_CLOSE             :
        begin
          btPlayPause.Enabled := false;
          FCanPosition        := false;
          sldPosition.Width   := 0;
        end;
      EP_PLAY              :
        begin
          btStop.Enabled      := true;
          btPlayPause.Caption := '&راحة';
        end;
      EP_STOP              :
        begin
          btStop.Enabled      := false;
          btPlayPause.Caption := '&شغل';
          sldPosition.Width   := 0;
        end;
      EP_REWIND            : sldPosition.Width := 0;
      EP_DEVICECHANGE      :
        if cmbDevices.ItemIndex <> FPlayer.DeviceIndex then
          cmbDevices.ItemIndex := FPlayer.DeviceIndex;

      EP_MEDIAEVENT        :
        if FPlayer.MediaEvent = EC_COMPLETE then btStop.Click;

      EP_ERROR_OPEN        :
        begin
          btOpen.Enabled := true;
          FPlayer.Close;
        end;
      EP_ERROR_PLAY        : btStop.Enabled := false;
      EP_ERROR_STOP        : btStop.Enabled := true;
      EP_ERROR_REWIND      :
        if FPlayer.State = fsStopped then
          begin
            FCanPosition      := false;
            sldPosition.Width := 0;
          end;
      EP_ERROR_GETVOLUME   : FCanVolume   := false;
      EP_ERROR_GETPOSITION : FCanPosition := false;

  end;
end;



// ----------------------------------------------------------------------------
// reload file-stream with selected device immediately
// ----------------------------------------------------------------------------
procedure TFormPlayer.cmbDevicesChange(Sender: TObject);
begin
    FPlayer.DeviceIndex := cmbDevices.ItemIndex;
    // change selected device wheather is playing or not
    FPlayer.ChangeDevice;
end;

// ----------------------------------------------------------------------------
// use user selected audio device
// ----------------------------------------------------------------------------
procedure TFormPlayer.chkForceDeviceClick(Sender: TObject);
begin
    FPlayer.ForceDevice := chkForceDevice.Checked;
end;

// ----------------------------------------------------------------------------
// use volume control of standart WaveOut or the selected device  
// ----------------------------------------------------------------------------
procedure TFormPlayer.chkWaveOutVolumeClick(Sender: TObject);
begin
    FPlayer.DeviceVolume := not chkWaveOutVolume.Checked;
end;

end.
