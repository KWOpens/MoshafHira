﻿unit UDhikrJour;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.ExtCtrls;

type
  TFormDhikrJour = class(TForm)
    Panel1: TPanel;
    ImageDhikrJour: TImage;
    procedure FormActivate(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private
    { Déclarations privées }
  public
    { Déclarations publiques }
  end;

var
  FormDhikrJour: TFormDhikrJour;

implementation

{$R *.dfm}

Uses UCoranMoshaf;

// عرض صور الذكر
procedure TFormDhikrJour.FormActivate(Sender: TObject);
Const
   Max = 237;
Var
  RepPages, aPath, nPage : String;
  numDhikr : Integer;
begin
  aPath := ExtractFilePath(Application.ExeName);
  numDhikr := Random(FormMoshaf.nFilesDhikr);
  RepPages := aPath + 'Data\Dhikr' + '\' + IntToStr(numDhikr) + '.jpg';
  //
  try
    ImageDhikrJour.Picture.LoadFromFile(RepPages);
  except
    ShowMessage('الصورة غير متوفرة، أعد الإختيار');
  end;

end;


// تطعيم الحساب العشوائي
procedure TFormDhikrJour.FormCreate(Sender: TObject);
begin
  Randomize;
end;

end.
