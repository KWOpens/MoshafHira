object FormPlayer: TFormPlayer
  Left = 680
  Top = 291
  HorzScrollBar.Visible = False
  VertScrollBar.Visible = False
  BiDiMode = bdRightToLeft
  BorderIcons = []
  BorderStyle = bsNone
  Caption = #1602#1585#1575#1569#1577' '#1589#1608#1578#1610#1577
  ClientHeight = 159
  ClientWidth = 346
  Color = clMaroon
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  ParentBiDiMode = False
  Position = poDesigned
  OnActivate = FormActivate
  OnCreate = FormCreate
  OnDestroy = FormDestroy
  PixelsPerInch = 96
  TextHeight = 13
  object Label1: TLabel
    Left = 35
    Top = 195
    Width = 37
    Height = 13
    Caption = 'Device:'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clInfoBk
    Font.Height = -11
    Font.Name = 'MS Sans Serif'
    Font.Style = []
    ParentFont = False
    Visible = False
  end
  object Label2: TLabel
    Left = 110
    Top = 8
    Width = 130
    Height = 24
    Caption = #1578#1604#1575#1608#1577' '#1575#1604#1602#1585#1570#1606' '#1575#1604#1603#1585#1610#1605
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindow
    Font.Height = -19
    Font.Name = 'MS Sans Serif'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object cmbDevices: TComboBox
    Left = 91
    Top = 189
    Width = 219
    Height = 21
    Cursor = crHandPoint
    Style = csDropDownList
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -11
    Font.Name = 'MS Sans Serif'
    Font.Style = []
    ParentFont = False
    TabOrder = 0
    Visible = False
    OnChange = cmbDevicesChange
  end
  object chkForceDevice: TCheckBox
    Left = 61
    Top = 216
    Width = 249
    Height = 17
    Cursor = crHandPoint
    Hint = 'Uses selected device from Device list'
    Caption = 'Force use of selected device'
    Color = clCream
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindow
    Font.Height = -11
    Font.Name = 'MS Sans Serif'
    Font.Style = []
    ParentColor = False
    ParentFont = False
    ParentShowHint = False
    ShowHint = True
    TabOrder = 1
    Visible = False
    OnClick = chkForceDeviceClick
  end
  object chkWaveOutVolume: TCheckBox
    Left = 61
    Top = 232
    Width = 249
    Height = 17
    Cursor = crHandPoint
    Hint = 'Clear enough :)'
    Caption = 'Use only standart WaveOut volume control'
    Color = clBtnFace
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindow
    Font.Height = -11
    Font.Name = 'MS Sans Serif'
    Font.Style = []
    ParentColor = False
    ParentFont = False
    ParentShowHint = False
    ShowHint = True
    TabOrder = 2
    Visible = False
    OnClick = chkWaveOutVolumeClick
  end
  object XiPanel1: TXiPanel
    Left = -2
    Top = 40
    Width = 353
    Height = 369
    ColorFace = clWhite
    ColorGrad = 10805759
    ColorLight = 36821
    ColorDark = 27035
    ColorScheme = csDesert
    FillDirection = fdVertical
    TabOrder = 3
    UseDockManager = True
    object btStop: TSpeedButton
      Left = 208
      Top = 85
      Width = 41
      Height = 25
      Caption = '&'#1608#1602#1601
      OnClick = btStopClick
    end
    object btPlayPause: TSpeedButton
      Left = 93
      Top = 84
      Width = 40
      Height = 25
      Caption = '&'#1588#1594#1604
      OnClick = btPlayPauseClick
    end
    object btOpen: TSpeedButton
      Left = 37
      Top = 276
      Width = 41
      Height = 25
      Caption = '&'#1601#1578#1581
      Visible = False
      OnClick = btOpenClick
    end
    object sldPositionFrm: TLabel
      Left = 30
      Top = 46
      Width = 260
      Height = 22
      Cursor = crHandPoint
      AutoSize = False
      Color = clGray
      ParentColor = False
      Transparent = False
      OnMouseDown = sldPositionFrmMouseDown
    end
    object Image1: TImage
      Left = 9
      Top = 7
      Width = 24
      Height = 24
      Picture.Data = {
        0A544A504547496D61676506050000FFD8FFE000104A46494600010101006000
        600000FFE1005A4578696600004D4D002A000000080005030100050000000100
        00004A0303000100000001000000005110000100000001010000005111000400
        00000100000EC4511200040000000100000EC400000000000186A00000B18FFF
        DB00430002010102010102020202020202020305030303030306040403050706
        07070706070708090B0908080A0807070A0D0A0A0B0C0C0C0C07090E0F0D0C0E
        0B0C0C0CFFDB004301020202030303060303060C0807080C0C0C0C0C0C0C0C0C
        0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C
        0C0C0C0C0C0C0C0C0CFFC00011080018001803012200021101031101FFC4001F
        0000010501010101010100000000000000000102030405060708090A0BFFC400
        B5100002010303020403050504040000017D0102030004110512213141061351
        6107227114328191A1082342B1C11552D1F02433627282090A161718191A2526
        2728292A3435363738393A434445464748494A535455565758595A6364656667
        68696A737475767778797A838485868788898A92939495969798999AA2A3A4A5
        A6A7A8A9AAB2B3B4B5B6B7B8B9BAC2C3C4C5C6C7C8C9CAD2D3D4D5D6D7D8D9DA
        E1E2E3E4E5E6E7E8E9EAF1F2F3F4F5F6F7F8F9FAFFC4001F0100030101010101
        010101010000000000000102030405060708090A0BFFC400B511000201020404
        0304070504040001027700010203110405213106124151076171132232810814
        4291A1B1C109233352F0156272D10A162434E125F11718191A262728292A3536
        3738393A434445464748494A535455565758595A636465666768696A73747576
        7778797A82838485868788898A92939495969798999AA2A3A4A5A6A7A8A9AAB2
        B3B4B5B6B7B8B9BAC2C3C4C5C6C7C8C9CAD2D3D4D5D6D7D8D9DAE2E3E4E5E6E7
        E8E9EAF2F3F4F5F6F7F8F9FAFFDA000C03010002110311003F00FABBE1778175
        0FDA6BC6834CB7BBD057C517DA6B6AE6E75B5DF26B530019A146C12CEC492C49
        F917240207193368B0DBEB8DA2CDE1911F8912E8583691F6256BBFB49E910503
        927A82382BF3671CD783E85FB416BDE25B9F0AE9FE0BB3D41BC517AD02E851D8
        0DDA8C975B4143176523AB13955504B1DB9AFD2EFF0084A2F974F3A50BAF85BA
        87ED9B63E08F38DBEE7F208DC39ECA18861C7CBCB67884D7E5995E1696614DB5
        78B8BD5F495FA2BFDAEC8FEC9E2CC762F21AF4E3351946A2F7609DA54ECEDCF3
        6AF6A3AA5293F81AD2F7D3E59F8ABF0FB5AFD987C49676FA9FF61D8F8A1F4D3A
        D5B1D1E456B8D15C676C72B28CAB82010E3E57F980C81C95F35788BF692D7B4F
        BCF13AF8D20D426F1346F3C7AE1BE4F27518EE954875954F191D028C285C6DF9
        71457153C747DA4D5072846FB36EFF003F33EEB09C275674612CC2942BCECBDE
        514E2EFAFBB7BB51EDAEBBF53CDBE07FED5BE33FF827FF00C46F1049A4D8F87F
        4DF1D49A41F0C5D0F10DA86BCF0CCAA46E9A05620AC8A41050E524F90B02179E
        1E2F8FDA869DE395F16DB78BEF22F1A477E7565D7CDE86BFFB613933B393F313
        920A9F94A92A46DE28A2B8EB4AA26A8293E58376F2D77F53F4DC9F2BC05683CC
        E7421ED7114E0AA3B5EEB957BBAB7EEEBB6DDCEBBF688FDAABC4DFF0509F8D1A
        6EA927877408BC75AA69307877ECBE1A4679BC4D74A0A2DC48B925A46242A281
        FBB4014B3003051457BB9760638DE7AF5DBE66FA5BFC8FCBF8E389AB7094B0D9
        564F4A0A9285D29733B7BCD593E65A765D3D0FFFD9}
      Transparent = True
      OnClick = Image1Click
    end
    object sldPosition: TPanel
      Left = 31
      Top = 47
      Width = 258
      Height = 21
      Cursor = crHandPoint
      Color = clBtnHighlight
      ParentBackground = False
      TabOrder = 0
      OnMouseDown = sldPositionFrmMouseDown
    end
    object sldVolumeFrm: TPanel
      Left = 311
      Top = 7
      Width = 16
      Height = 102
      BevelOuter = bvLowered
      Color = clGray
      ParentBackground = False
      TabOrder = 1
    end
    object sldVolume: TPanel
      Left = 307
      Top = 43
      Width = 23
      Height = 9
      Cursor = crHandPoint
      TabOrder = 2
      OnMouseDown = sldVolume1MouseDown
      OnMouseMove = sldVolume1MouseMove
      OnMouseUp = sldVolume1MouseUp
    end
  end
  object Timer1: TTimer
    Interval = 5
    OnTimer = Timer1Timer
    Left = 105
    Top = 283
  end
end
