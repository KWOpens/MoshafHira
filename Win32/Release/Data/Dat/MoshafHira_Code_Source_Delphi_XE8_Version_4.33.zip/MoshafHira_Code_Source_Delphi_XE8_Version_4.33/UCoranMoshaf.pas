﻿unit UCoranMoshaf;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes,
  System.Types, System.UITypes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.ExtCtrls, Vcl.Imaging.pngimage,
  Vcl.StdCtrls, Vcl.ComCtrls, Vcl.Samples.Spin, Data.DB, Vcl.Grids, Vcl.DBGrids, 
  ButtonComps, Datasnap.DBClient, Vcl.Shell.ShellCtrls, Vcl.Menus,
  System.ImageList, Vcl.ImgList, Vcl.Imaging.jpeg, System.TypInfo,
  Vcl.MPlayer, System.IOUtils, ShellAPI, System.Win.Registry;


type
  TFormMoshaf = class(TForm)
    PanelButtons: TPanel;
    PanelAllPageMoshaf: TPanel;
    PanelPageMoshaf: TPanel;
    PanelTetePageMoshaf: TPanel;
    ImageMoshaf: TImage;
    ImageEntete: TImage;
    lbNameSora: TLabel;
    lbOrdreSora: TLabel;
    lbNbreAyatSora: TLabel;
    PanelPiedPageMoshaf: TPanel;
    PanelPosMouse: TPanel;
    edPosX: TEdit;
    edPosY: TEdit;
    PanelTasafoh: TPanel;
    ImageTasafoh: TImage;
    PanelPages: TPanel;
    BtnAnnass: TButton;
    BtnPrecedent: TButton;
    BtnSuivant: TButton;
    BtnFatiha: TButton;
    eNumPage: TEdit;
    BtnAffichePage: TButton;
    ImageCadreNavig: TImage;
    LabelNumPage: TLabel;
    PanelChoixMoshaf: TPanel;
    PanelFahress: TPanel;
    ImageFahress: TImage;
    PanelFahres: TPanel;
    ImageFahres: TImage;
    PanelDateTime: TPanel;
    edDateAr: TEdit;
    eDateHedjri: TEdit;
    lbl_Time: TLabel;
    DataSource1: TDataSource;
    DataSource2: TDataSource;
    DataSource3: TDataSource;
    DataSource4: TDataSource;
    DataSource5: TDataSource;
    DataSource6: TDataSource;
    DataSource7: TDataSource;
    PanelFete: TPanel;
    ImageFete: TImage;
    TimerFete: TTimer;
    PopupMenu1: TPopupMenu;
    N2: TMenuItem;
    N3: TMenuItem;
    N5: TMenuItem;
    N8: TMenuItem;
    N9: TMenuItem;
    N6: TMenuItem;
    ImageList1: TImageList;
    TrayIcon1: TTrayIcon;
    BalloonHint1: TBalloonHint;
    PopupMenu2: TPopupMenu;
    N13: TMenuItem;
    N15: TMenuItem;
    N16: TMenuItem;
    ImageWaDhakir: TImage;
    DataSource8: TDataSource;
    PanelDbgrid: TPanel;
    BtnDeleteAyaPos: TButton;
    BtnSaveAyaPos: TButton;
    Label4: TLabel;
    Label5: TLabel;
    eNumAya: TEdit;
    DBGridAyaCDS: TDBGrid;
    BtnTestKey: TButton;
    edtSearch: TEdit;
    BtnSearch: TButton;
    DataSource9: TDataSource;
    N4: TMenuItem;
    Label6: TLabel;
    Label7: TLabel;
    LabNbreMot: TLabel;
    Label8: TLabel;
    LabelChoixMoshaf: TLabel;
    DBGridSoraname: TDBGrid;
    N7: TMenuItem;
    BtnVidage: TButton;
    MemoTemp: TMemo;
    Button1: TButton;
    BtnInsert: TButton;
    Button2: TButton;
    Button3: TButton;
    BtnPolyOne: TButton;
    BtnInvertColor: TButton;
    N10: TMenuItem;
    eNumLine: TSpinEdit;
    eNumSora: TSpinEdit;
    Button4: TButton;
    ImageDhikrDuJour: TImage;
    N1: TMenuItem;
    N11: TMenuItem;
    Label9: TLabel;
    Label1: TLabel;
    PanelAudio: TPanel;
    ImageSound: TImage;
    PanelTitreNumPage: TPanel;
    ImagePiedPageCoran: TImage;
    lbNumPage: TLabel;
    ShellTreeViewDhikr: TShellTreeView;
    Button5: TButton;
    CheckBoxWarsh: TCheckBox;
    CheckBoxHafs: TCheckBox;
    procedure BtnSuivantClick(Sender: TObject);
    procedure BtnPrecedentClick(Sender: TObject);
    procedure BtnFatihaClick(Sender: TObject);
    procedure BtnAnnassClick(Sender: TObject);
    procedure BtnAffichePageClick(Sender: TObject);
    procedure FormActivate(Sender: TObject);
    procedure ImageDhikrDuJourClick(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure N2Click(Sender: TObject);
    procedure N3Click(Sender: TObject);
    procedure N5Click(Sender: TObject);
    procedure N8Click(Sender: TObject);
    procedure N9Click(Sender: TObject);
    procedure N6Click(Sender: TObject);
    procedure FormCloseQuery(Sender: TObject; var CanClose: Boolean);
    procedure TrayIcon1DblClick(Sender: TObject);
    procedure FormResize(Sender: TObject);
    procedure FormKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
    procedure FormDestroy(Sender: TObject);
    procedure BtnDeleteAyaPosClick(Sender: TObject);
    procedure BtnSaveAyaPosClick(Sender: TObject);
    procedure edtSearchEnter(Sender: TObject);
    procedure BtnSearchClick(Sender: TObject);
    procedure DSqMotsTZCDS;
    procedure DSourceSoraCDS;
    procedure TestDataSourceCellClick(Column: TColumn);
    procedure DBGridSoranameSoraCDS;
    procedure DBGridSoranameSearchMots;
    procedure DBGridAyaCDSTitleClick(Column: TColumn);
    procedure N10Click(Sender: TObject);
    procedure DrawTransparentRectangle(Canvas: TCanvas; Rect: TRect;
      Color: TColor; Transparency: Integer);
    procedure BtnVidageClick(Sender: TObject);
    procedure ImageMoshafMouseMove(Sender: TObject; Shift: TShiftState; X,
      Y: Integer);
    procedure ImageMoshafMouseDown(Sender: TObject; Button: TMouseButton;
      Shift: TShiftState; X, Y: Integer);
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
    procedure HighLightAya(Canvas: TCanvas; p1,p2: TPoint;
      Color: TColor; Transparency: Integer);
    procedure InvertBitmapColors(const Bmp: TBitmap);
    procedure BtnInvertColorClick(Sender: TObject);
    procedure N11Click(Sender: TObject);
    procedure ImageWaDhakirClick(Sender: TObject);
    procedure ImageLectureClick(Sender: TObject);
    procedure ImageSoundClick(Sender: TObject);
    procedure isAdmin();
    procedure Button5Click(Sender: TObject);
    procedure CheckBoxWarshClick(Sender: TObject);
    procedure CheckBoxHafsClick(Sender: TObject);
  private
    { Déclarations privées }
  public
    { Public declarations }
    QuranCDS     : TClientDataSet;   // Coran
    qMotsTZCDS   : TClientDataSet;   // Coran Mot par Mot
    HarfTZCDS    : TClientDataSet;   // Coran Harf par Harf
    DicMotTZCDS  : TClientDataSet;   // Dictionnaire des mots du Coran sans répétition
    SoraCDS      : TClientDataSet;   // Sorate
    SoraHarf2CDS : TClientDataSet;   // Nombre de chaque lettre par Sora (A00, A01,A02,...,A28)
    SoraHarfCDS  : TClientDataSet;   // Nombre de chaque lettre par Sora (NUM, SORANO, HARF, nBREOCC)
    AllahNamesCDS: TClientDataSet;   // Elhosna Allah Names
    AyaPosCDS    : TClientDataSet;   // Position (X,Y) de la Aya sur la Page du Coran
    //
    TypeMoshaf, SaveTypeMoshaf, TypeAudio, nSora, nAya, nomSora, NbreAyatSora, nFileMP3 : String;
    NonFin : Boolean;
    nCol, iFontSize, TypeLecture : Integer;
    GTC: LongWord;
    nPage, nFilesBanner, nFilesCanal, nFilesDhikr, nAudioPlay : Integer;
    //
    PNG: TPNGImage;      // For load / save of PNG file
    JPEG: TJPEGImage;    // For load / save of JPEG file
    BMPBackup: TBitmap;  // Backup of previous edit step. Used by Undo
    BMPWork: TBitmap;    // For edit of any image and load / save of BMP file
  end;

var
  FormMoshaf: TFormMoshaf;

const
  LvFileName = 'makenaya.dat';
  ColorTabMax=10;
  ColorTab: array[0..ColorTabMax-1] of TColor=
      (ClBlack, ClMaroon, ClRed, ClWebDarkOrange, ClYellow,
       ClGreen, ClBlue, ClPurple, ClGray, ClWhite);

implementation

{$R UAC.RES, UAC.RC }
{$R hiraressources.RES, hiraressources.RC}
{$R *.dfm}

uses UAbout, HejriUtils, Midaslib, MyFuncUtils, UConfig, UDhikrJour, UConst, UDataM,
     URecherche, UFahresN, UGoPage, UTexteCoran, UZoomPage, UPrincipe, TMPlayer;

procedure TFormMoshaf.isAdmin();
var
  reg: TRegistry;
  openResult: Boolean;
begin
  reg := TRegistry.Create(KEY_READ);
  reg.RootKey := HKEY_LOCAL_MACHINE;
  reg.Access := KEY_WRITE;
  openResult := reg.OpenKey('Software\MyCompanyName\MyApplication\',True);
  //
  if not openResult = True then
    begin
      MessageDlg('Unable to write to registry. Your application does NOT have Administrator level privileges.',
                TMsgDlgType.mtError, mbOKCancel, 0);
    end
  else
    begin
      MessageDlg('Write to registry permitted. Your application has Administrator level privileges.',
                TMsgDlgType.mtInformation, mbOKCancel, 0);
    end;
  //
  reg.CloseKey();
  reg.Free;
end;



function RepMoshaf(Chemin:string; Moshaf:string; Page:string):String;
begin
  Result := Chemin + 'Data\Pages\' + Moshaf + '\' + Page;
end;


function RepAudio(Chemin:string; RepAudio:string; PageAudio:string):String;
begin
  if RepAudio = 'hafs' then
     Result := Chemin + 'Data\Audio\Coran\' + RepAudio + '\Hafs_Par_Page\' + PageAudio
  else
    if RepAudio = 'warsh' then
        Result := Chemin + 'Data\Audio\Coran\' + RepAudio + '\Warsh_Par_Page\' + PageAudio
end;


// Chargement des données à la création de la Form
procedure TFormMoshaf.FormCreate(Sender: TObject);
var
  sPath : String;
  Year, Month, Day: Word;
Begin
  // isAdmin();
  //on affiche une première fois l'heure ... quand l'application démarre
  lbl_Time.Caption := TimeToStr(Now);
  edDateAr.Text:=DateEnArabe;
  DateToHejri(Now, Year, Month, Day);
  eDateHedjri.Text := IntToStr(Day) + '  ' + HejriMonthsAr[Month] + '  ' + IntToStr(Year);
  //
  Randomize;
  //
  Application.HelpFile := ExtractFilePath(Application.ExeName) + 'HelpMoshafHira.chm';    //Fichier sans index "Aide.chm"
  //
  PNG:=TPNGImage.Create();
  JPEG:=TJPEGImage.Create();
  BMPBackup:=TBitmap.Create;
  BMPBackup.PixelFormat := pf24bit;
  BMPWork:=TBitmap.Create;
  BMPWork.PixelFormat := pf32bit;
  BMPWork.Width:=ImageMoshaf.Width;
  BMPWork.Height:=ImageMoshaf.Height;


  //++++++++++++++++++++++++++++++++ AyaPosCDS.CDS  : CREATION  ClientDataSet +++++++++++++++++++
  AyaPosCDS := TClientDataSet.Create(Self);  // create the ClientDataSet.
  //
  With AyaPosCDS.FieldDefs do
    begin
        // create A Virtual table by adding columns
        Add('AIANO', ftInteger, 0, True);                 // N° de la Aya dans Coran
        Add('SORANO', ftInteger, 0, True);                // N° de la Sora du Coran
        Add('AIANOS', ftInteger, 0, True);                // N° de la Aya dans la SORA
        Add('NOLINE', ftInteger, 0, True);                // N° de la Ligne de la Fin Aya
        Add('NOPAGE', ftInteger, 0, True);                // N° de la page du Coran
        Add('POSX', ftInteger, 0, True);                  // Position X horizontale de la fin Aya sur la page du Coran
        Add('POSY', ftInteger, 0, True);                  // Position Y Verticale de la fin Aya sur la page du Coran
    end;
    //
    AyaPosCDS.CreateDataSet;                              // Apply All Above or Save in Memory of "DataSet" the New Table "Quran".
    DataSource8.DataSet := AyaPosCDS;
    //
    // Chargement des données
    // Label2.Caption := ' عرض نص القرآن الكريم آية آية';
    //
    sPath := ExtractFilePath(Application.ExeName);
    sPath := sPath + 'Data\Dat\';
    //
    { Verify whether the specified directory not exists }
    if not TDirectory.Exists(sPath) then
      begin
        MessageDlg('Le Répertoire n''existe pas! ...' + sPath, mtInformation, [mbOK], 0);
        if not ForceDirectories(sPath) then
         MessageDlg('Erreur de création du répertoire! ...', mtInformation, [mbOK], 0);;
      end;
    //
    sPath := sPath + 'AyaPos.cds';
    //
    //if not FileExists(sPath) then
    //  begin
    //    AyaPosCDS.SaveToFile(sPath);
    //  end
    //else
      //begin
        try
          AyaPosCDS.LoadFromFile(sPath);
        except
          raise;
        end;
      //end;
  //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


  //++++++++++++++++++++++++++++++++ QuranCDS.CDS  : CREATION  ClientDataSet +++++++++++++++++++
  QuranCDS := TClientDataSet.Create(Self);  // create the ClientDataSet.
  //
  With QuranCDS.FieldDefs do
    begin
        // create A Virtual table by adding columns
        Add('LINENO', ftInteger, 0, True);                // and First one Must be the index table => "LINENO".
        Add('SORANO', ftInteger, 0, True);                // Adding Second column to the table => "SORANO".
        Add('AIANO', ftInteger, 0, True);                 // Adding Third column to the table => "AIANO".
        Add('NBKALIMA', ftInteger, 0, True);              // Adding Fifth column to the table => "NBKALIMA".
        Add('NBHARF', ftInteger, 0, True);                // Adding Sixth column to the table => "NBHARF".
        Add('NBKALIMATZ', ftInteger, 0, True);            // Adding Fifth column to the table => "NBKALIMA".
        Add('NBHARFTZ', ftInteger, 0, True);              // Adding Sixth column to the table => "NBHARF".
        Add('AIATANZIL', ftWideMemo);                     // Adding Fourth column to the table => "AIA".
        Add('AIAMADINA', ftWideMemo);                     // Adding Fourth column to the table => "AIA".
        //
        Add('NOPAGE', ftInteger, 0, True);                // N° de la page du Coran
        Add('POSX', ftInteger, 0, True);                  // Position X horizontale de la fin Aya sur la page du Coran
        Add('POSY', ftInteger, 0, True);                  // Position Y Verticale de la fin Aya sur la page du Coran
    end;
    //
    QuranCDS.CreateDataSet;                               // Apply All Above or Save in Memory of "DataSet" the New Table "Quran".
    DataSource2.DataSet := QuranCDS;
    //
    // Chargement des données
    // Label2.Caption := ' عرض نص القرآن الكريم آية آية';
    //
    sPath := ExtractFilePath(Application.ExeName);
    sPath := sPath + 'Data\Dat\Quran.cds';
    //
    if not FileExists(sPath) then
      begin
        QuranCDS.SaveToFile(sPath);
      end
    else
      begin
        try
          QuranCDS.LoadFromFile(sPath);
        except
          raise;
        end;
      end;
    //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++



    //++++++++++++++++++++++++++++++++ SoraCDS.CDS  : CREATION  ClientDataSet +++++++++++++++++++
    SoraCDS := TClientDataSet.Create(Self);  // create the ClientDataSet.
    //
    With SoraCDS.FieldDefs do
    begin
      // create A Virtual table by adding columns
      Add('SoraNo', ftInteger, 0, True);              // Adding Second column to the table => "SORANO".
      Add('Name', ftWideString, 25, True);            // Adding Second column to the table => "SORANO".
      Add('PageMushaf', ftInteger, 0, True);          // Adding Third column to the table => "AIANO".
      Add('LieuNouzoul', ftString, 1, True);          // Adding Fourth column to the table => "AIA".
      Add('OrdreNouzoul', ftInteger, 0, True);        // Adding Fifth column to the table => "NBKALIMA".
      Add('OrdreMushaf', ftInteger, 0, True);         // Adding Sixth column to the table => "NBHARF".
      Add('AiaCount', ftInteger, 0, True);            // Adding Fourth column to the table => "AIA".
      Add('KalimaCount', ftInteger, 0, True);         // Adding Fifth column to the table => "NBKALIMA".
      Add('HarfCount', ftInteger, 0, True);           // Adding Sixth column to the table => "NBHARF".
    end;
    //
    SoraCDS.CreateDataSet;                            // Apply All Above or Save in Memory of "DataSet" the New Table "Sora"
    DataSource1.DataSet := SoraCDS;
    //
    // Chargement des données
    // 'عرض سور القرآن الكريم';
    //
    sPath := ExtractFilePath(Application.ExeName);
    sPath := sPath + 'Data\Dat\Sora.cds';
    //
    if not FileExists(sPath) then
      begin
        SoraCDS.SaveToFile(sPath);
      end
    else
      begin
        try
          SoraCDS.LoadFromFile(sPath);
        except
          raise;
        end;
      end;
    //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++



	
   //++++++++++++++++++++++++++++++++ qMotsTZCDS.CDS : CREATION  ClientDataSet +++++++++++++++
    qMotsTZCDS := TClientDataSet.Create(Self);  // Create the ClientDataSet.
    //
    With qMotsTZCDS.FieldDefs do
    begin
      Add('NUM', ftInteger, 0, True);
      Add('LINENO', ftInteger, 0, True);
      Add('SORANO', ftInteger, 0, True);
      Add('AIANO', ftInteger, 0, True);
      Add('MOT', ftWideString, 20, True);
      Add('NBHARF', ftInteger, 0, True);
    end;
    //
    qMotsTZCDS.CreateDataSet;
    DataSource9.DataSet := qMotsTZCDS;
    //
    // Chargement des données
    // 'قاموس كل  كلمات القرآن الكريم';
    //
    sPath := ExtractFilePath(Application.ExeName);
    sPath := sPath + 'Data\Dat\MotsTZ.cds';
    //
    if not FileExists(sPath) then
      begin
        qMotsTZCDS.SaveToFile(sPath);
      end
    else
      begin
        try
          qMotsTZCDS.LoadFromFile(sPath);
        except
          raise;
        end;
      end;
    //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	


    //++++++++++++++++++++++++++++++++ DicMotTZCDS.CDS : CREATION  ClientDataSet +++++++++++++++
    DicMotTZCDS := TClientDataSet.Create(Self);  // Create the ClientDataSet.
    //
    With DicMotTZCDS.FieldDefs do
    begin
      Add('NUM', ftInteger, 0, True);
      Add('MOT', ftWideString, 20, True);
      Add('NBHARF', ftInteger, 0, True);
      Add('NBOCC', ftInteger, 0, True);
      Add('Val_H28', ftInteger, 0, True);
      Add('Val_H14', ftInteger, 0, True);
      Add('Val_H21', ftInteger, 0, True);
      Add('Val_H10', ftInteger, 0, True);
      Add('Val_H9', ftInteger, 0, True);
      Add('Val_H10_9', ftInteger, 0, True);
    end;
    //
    DicMotTZCDS.CreateDataSet;
    DataSource3.DataSet := DicMotTZCDS;
    //
    // Chargement des données
    // 'قاموس كلمات القرآن الكريم بدون تكرار';
    //
    sPath := ExtractFilePath(Application.ExeName);
    sPath := sPath + 'Data\Dat\DicMotTZ.cds';
    //
    if not FileExists(sPath) then
      begin
        DicMotTZCDS.SaveToFile(sPath);
      end
    else
      begin
        try
          DicMotTZCDS.LoadFromFile(sPath);
        except
          raise;
        end;
      end;
    //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++



    //++++++++++++++++++++++++++++++++ SoraHarfCDS.CDS : CREATION  ClientDataSet +++++++++++++++
    SoraHarfCDS := TClientDataSet.Create(Self);  // Create the ClientDataSet.
    //
    With SoraHarfCDS.FieldDefs do
    begin
      Add('NUM', ftInteger, 0, True);
      Add('SORANO', ftInteger, 0, True);
      Add('HARF', ftWideString, 1, True);
      Add('NBREOCC', ftInteger, 0, True);
    end;
    //
    SoraHarfCDS.CreateDataSet;
    DataSource6.DataSet := SoraHarfCDS;
    //
    // Chargement des données
    // 'قاموس كلمات القرآن الكريم بدون تكرار';
    //
    sPath := ExtractFilePath(Application.ExeName);
    sPath := sPath + 'Data\Dat\SoraHarf.cds';
    //
    if not FileExists(sPath) then
      begin
        SoraHarfCDS.SaveToFile(sPath);
      end
    else
      begin
        try
          SoraHarfCDS.LoadFromFile(sPath);
        except
          raise;
        end;
      end;
    //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++



    //++++++++++++++++++++++++++++++++ SoraHarf2CDS.CDS : CREATION  ClientDataSet +++++++++++++++
    SoraHarf2CDS := TClientDataSet.Create(Self);  // Create the ClientDataSet.
    //
    With SoraHarf2CDS.FieldDefs do
    begin
      Add('A00', ftInteger, 0, True);
      Add('A01', ftInteger, 0, True);
      Add('A02', ftInteger, 0, True);
      Add('A03', ftInteger, 0, True);
      Add('A04', ftInteger, 0, True);
      Add('A05', ftInteger, 0, True);
      Add('A06', ftInteger, 0, True);
      Add('A07', ftInteger, 0, True);
      Add('A08', ftInteger, 0, True);
      Add('A09', ftInteger, 0, True);
      Add('A10', ftInteger, 0, True);
      Add('A11', ftInteger, 0, True);
      Add('A12', ftInteger, 0, True);
      Add('A13', ftInteger, 0, True);
      Add('A14', ftInteger, 0, True);
      Add('A15', ftInteger, 0, True);
      Add('A16', ftInteger, 0, True);
      Add('A17', ftInteger, 0, True);
      Add('A18', ftInteger, 0, True);
      Add('A19', ftInteger, 0, True);
      Add('A20', ftInteger, 0, True);
      Add('A21', ftInteger, 0, True);
      Add('A22', ftInteger, 0, True);
      Add('A23', ftInteger, 0, True);
      Add('A24', ftInteger, 0, True);
      Add('A25', ftInteger, 0, True);
      Add('A26', ftInteger, 0, True);
      Add('A27', ftInteger, 0, True);
      Add('A28', ftInteger, 0, True);
    end;
    //
    SoraHarf2CDS.CreateDataSet;
    DataSource4.DataSet := SoraHarf2CDS;
    //
    // Chargement des données
    // 'قاموس كلمات القرآن الكريم بدون تكرار';
    //
    sPath := ExtractFilePath(Application.ExeName);
    sPath := sPath + 'Data\Dat\SoraHarf2.cds';
    //
    if not FileExists(sPath) then
      begin
        SoraHarf2CDS.SaveToFile(sPath);
      end
    else
      begin
        try
          SoraHarf2CDS.LoadFromFile(sPath);
        except
          raise;
        end;
      end;
    //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++




    //++++++++++++++++++++++++++++++++ DicMotTZCDS.CDS : CREATION  ClientDataSet +++++++++++++++
    HarfTZCDS := TClientDataSet.Create(Self);  // Create the ClientDataSet.
    //
    With HarfTZCDS.FieldDefs do
    begin
      Add('NUM'    , ftInteger, 0, True);
      Add('NumHarf', ftInteger, 0, True);
      Add('cHarf'  , ftInteger, 0, True);
      Add('SORANO' , ftInteger, 0, True);
      Add('AIANO'  , ftInteger, 0, True);
      Add('MOTNO'  , ftInteger, 0, True);
      Add('LINENO' , ftInteger, 0, True);
      Add('HARF'   , ftWideString , 0, True);
      Add('PHQ', ftInteger, 0, True);
      Add('PHS', ftInteger, 0, True);
      Add('PHA', ftInteger, 0, True);
      Add('PHM', ftInteger, 0, True);
      Add('H10', ftInteger, 0, True);
      Add('H21', ftInteger, 0, True);
      Add('H14', ftInteger, 0, True);
    end;
    //

    HarfTZCDS.CreateDataSet;
    DataSource5.DataSet := HarfTZCDS;
    //
    // Chargement des données
    // 'قاموس كلمات القرآن الكريم بدون تكرار';
    //
    sPath := ExtractFilePath(Application.ExeName);
    sPath := sPath + 'Data\Dat\HarfTZ.cds';
    //
    if not FileExists(sPath) then
      begin
        HarfTZCDS.SaveToFile(sPath);
      end
    else
      begin
        try
          HarfTZCDS.LoadFromFile(sPath);
        except
          raise;
        end;
      end;
    //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++




    //++++++++++++++++++++++++++++++++ AllahNames.CDS : CREATION  ClientDataSet +++++++++++++++
    AllahNamesCDS := TClientDataSet.Create(Self);  // Create the ClientDataSet.
    //
    With AllahNamesCDS.FieldDefs do
    begin
      Add('NUM', ftInteger, 0, True);
      Add('Names', ftWideString, 30, True);
      Add('NBHARF', ftInteger, 0, True);
      Add('Val_H14', ftInteger, 0, True);
      Add('Val_H21', ftInteger, 0, True);
      Add('Val_H10', ftInteger, 0, True);
      Add('Val_H10_9', ftInteger, 0, True);
    end;
    //
    AllahNamesCDS.CreateDataSet;
    DataSource7.DataSet := AllahNamesCDS;
    //
    // Chargement des données
    // 'قاموس كلمات القرآن الكريم بدون تكرار';
    //
    sPath := ExtractFilePath(Application.ExeName);
    sPath := sPath + 'Data\Dat\AllahNames.cds';
    //
    if not FileExists(sPath) then
      begin
        AllahNamesCDS.SaveToFile(sPath);
      end
    else
      begin
        try
          AllahNamesCDS.LoadFromFile(sPath);
        except
          raise;
        end;
      end;
   //
   //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
End;

// ----------  Fin Création des TClientDataSet  -----------------------------------------------



// Form Destroy
procedure TFormMoshaf.FormDestroy(Sender: TObject);
begin
  FreeAndNil(BMPWork);
  FreeAndNil(BMPBackup);
  FreeAndNil(JPEG);
  FreeAndNil(PNG);
end;




// Définition des touches de raccourcis
procedure TFormMoshaf.FormKeyDown(Sender: TObject; var Key: Word;
  Shift: TShiftState);
Var
  aPath : String;
begin
  aPath := ExtractFilePath(Application.ExeName);
  aPath := aPath + '\HelpMoshafHira.chm';
  //
  case key of
      VK_F3     : FormFahresN.ShowModal;             // إظهار الفهرس
      VK_ESCAPE : Close;                             // خروج
      //
      VK_RIGHT  : BtnPrecedentClick(Sender);
      VK_LEFT   : BtnSuivantClick(Sender);
      VK_RETURN : BtnAffichePageClick(Sender);
      VK_F4     : BtnFatihaClick(Sender);
      VK_F5     : BtnAnnassClick(Sender);
      VK_F6     : BtnAffichePageClick(Sender);
  end;

 if Key = VK_F11 then
    begin
      // On cache la fiche
        Hide();
      // On affiche l'icône dans le SysTray
        TrayIcon1.Visible := True;
      // On affiche la bulle info
        TrayIcon1.ShowBalloonHint;
      //
        Key := 0;
    end;

 if Key = VK_F1 then
    begin
      if Not FileExists(aPath) Then
         ShowMessage('ملف المساعدة غير متوفر')
      Else
        begin
          Try
            ShellExecute(Handle, 'open', PChar(aPath), nil, nil, SW_SHOW);
          Except
            ShowMessage('خطأ في عرض المساعدة');
          End;
        end;
      //
      Key := 0;

    end;
end;




// Iconisation de la Fiche principale
procedure TFormMoshaf.FormResize(Sender: TObject);
begin
// On vérifie si la fenêtre a été minimisée
 if WindowState = wsMinimized  then
   begin
     // On cache la fiche
        Hide();
     // On affiche l'icône dans le SysTray
        TrayIcon1.Visible := True;
     // On affiche la bulle info
        TrayIcon1.ShowBalloonHint;
   end;
end;




// Recherche de la page contenant un Mot
procedure TFormMoshaf.BtnSearchClick(Sender: TObject);
Var
  cMot  : String;
begin
  cMot := '';
  //
  if (edtSearch.Text = '') Then
    Begin
      Showmessage('أدخل كلمة للبحث!');
      edtSearch.SetFocus;
    End;
  //
  Application.ProcessMessages;
  //
  DSqMotsTZCDS;                         // Procédure de recherche du mot
end;




// Procédure de recherche d'un mot dans le dictionnaire des mots du CORAN
procedure TFormMoshaf.DSqMotsTZCDS;
begin
  DBGridSoraname.Columns.Clear;
  DBGridSoraname.DataSource := DataSource9;

  qMotsTZCDS.Close;
  qMotsTZCDS.Open;
  qMotsTZCDS.IndexFieldNames := 'MOT';
  qMotsTZCDS.SetRangeStart;
  qMotsTZCDS.FieldByName('MOT').Value := edtSearch.Text;
  qMotsTZCDS.SetRangeEnd;
  qMotsTZCDS.FieldByName('MOT').Value := edtSearch.Text;
  qMotsTZCDS.ApplyRange;

  DBGridSoraname.Fields[0].Visible:=False;               //Num
  DBGridSoraname.Fields[4].Visible:=False;               //NbreHarf

  DBGridSoraname.Columns[0].Title.Caption := 'ترتيب';
  DBGridSoraname.Columns[1].Title.Caption := 'السورة';
  DBGridSoraname.Columns[2].Title.Caption := 'الآية';
  DBGridSoraname.Columns[3].Title.Caption := 'الكلمة';

  DBGridSoraname.Columns[0].Title.Font.size := 10;
  DBGridSoraname.Columns[1].Title.Font.size := 10;
  DBGridSoraname.Columns[2].Title.Font.size := 10;
  DBGridSoraname.Columns[3].Title.Font.size := 10;

  DBGridSoraname.Columns[0].Width := 37;
  DBGridSoraname.Columns[1].Width := 37;
  DBGridSoraname.Columns[2].Width := 35;
  DBGridSoraname.Columns[3].Width := 55;

  LabNbreMot.Caption := IntToStr(qMotsTZCDS.RecordCount);
end;




// Tri de DBgrid1 par le titre de la colonne Aya
procedure TFormMoshaf.DBGridAyaCDSTitleClick(Column: TColumn);
{$J+}
 const
    PreviousColumnIndex : integer = 0;
{$J-}

begin
  if DBGridAyaCDS.DataSource.DataSet is TCustomClientDataSet then
      with TCustomClientDataSet(DBGridAyaCDS.DataSource.DataSet) do
        begin
          try
            DBGridAyaCDS.Columns[PreviousColumnIndex].title.Font.Style :=
                          DBGridAyaCDS.Columns[PreviousColumnIndex].title.Font.Style - [fsBold];
          except
          end;
          //
          Column.title.Font.Style :=  Column.title.Font.Style + [fsBold];
          PreviousColumnIndex := Column.Index;
          // Index selon la colonne choisie
          If Column.Title.Caption = 'AIA' Then
               IndexFieldNames := 'AIANO';
        end;
end;



procedure TFormMoshaf.DBGridSoranameSearchMots;
Var
  RepPages, aPath, sPage, sAudio, nFormat : String;
  NumPage: Integer;
begin
  eNumPage.Text:=DBGridSoraname.Fields[3].AsString;            // N° page Moshaf
  lbOrdreSora.Caption := DBGridSoraname.Fields[0].AsString;    // N° Sora
  lbNbreAyatSora.Caption := DBGridSoraname.Fields[2].AsString; // Nombre Ayate dans Sora
  lbNumPage.Caption := eNumPage.Text;                          // N° page Moshaf
  lbNameSora.Caption := DBGridSoraname.Fields[1].AsString;     // Nom Sora
  //
  aPath   := ExtractFilePath(Application.ExeName);
  NumPage := StrToInt(eNumPage.Text);
  //
  nFormat  := Format('%.*d', [3, NumPage]);
  nPage    := StrToInt(nFormat);
  sPage    := nFormat + '.jpg';
  sAudio   := nFormat + '.mp3';
  //
  SaveTypeMoshaf := TypeMoshaf;
  RepPages := RepMoshaf(aPath, TypeMoshaf, sPage);
  nFileMP3 := RepAudio(aPath, TypeAudio, sAudio);
  TypeMoshaf := SaveTypeMoshaf;

    //eDateHedjri.Text := 'TMos : ' + TypeMoshaf;
    //edDateAr.Text    := 'TAud : ' + TypeAudio;
  //
  Try
   ImageMoshaf.Picture.LoadFromFile(RepPages);
  Except
   ShowMessage('الصفحة غير موجودة');
  End;
end;




// Supprime l'enregistrement en cours de la base "AyaPosCDS"
procedure TFormMoshaf.BtnDeleteAyaPosClick(Sender: TObject);
Var
  s:String;
begin
  s:= '*Infos-AyaPos*';
  //
 { if(MessageDlg('Are you sure you want to delete the selected "AyaPosCDS"?'+#13#10+
    'The following "AyaPosCDS" will be deleted:'+#13#10#13#10+
    s, mtConfirmation, [mbYes, mbNo], 0)=mrYes)then
          AyaPosCDS.Delete;    }
end;



// Vidage: Supprime tous les enregistrements de la base "AyaPosCDS"
procedure TFormMoshaf.BtnVidageClick(Sender: TObject);
Var
  s:String;
begin
  s:= '*Base AyaPosCDS*';
  //
  if(MessageDlg('Attention: Supprime tous les enregistrements de la base "AyaPosCDS"?'+#13#10+
    'The following "AyaPosCDS" will be deleted:'+#13#10#13#10+
    s, mtConfirmation, [mbYes, mbNo], 0)=mrYes)then
          AyaPosCDS.EmptyDataSet;
end;




//Sauvegarde du fichier des Coordonnées X et Y des Ayate sur la PAge du Coran
procedure TFormMoshaf.Button1Click(Sender: TObject);
begin
  MemoTemp.Lines.SaveToFile('PagePointsXY.txt');
end;


// Charger  fichier des coordonnées X et Y
procedure TFormMoshaf.Button2Click(Sender: TObject);
begin
  MemoTemp.Lines.LoadFromFile('PagePointsXY.txt');
end;



// Vider le Memo des coordonnées X et Y
procedure TFormMoshaf.Button3Click(Sender: TObject);
begin
  MemoTemp.Clear;
end;




// Comptage du nombre des Ayate par Sora
procedure TFormMoshaf.Button5Click(Sender: TObject);
Var
  nSora, numSora, i, j, k : Integer;
begin
  DataM.FDTabAyaPos.Open;
  DataM.FDTabAyaPos.First;
  //
  //DataM.FDTabAyateHafs.Open;
  //DataM.FDTabAyateHafs.First;
  //
  { // Comptage du nombre des Ayate par Sora
    //
    numSora := DataM.FDTabAyaPos.FieldByName('SORANO').AsInteger;
    i := 0;
    j := 0;
    k := 0;
    //
    While  Not (DataM.FDTabAyaPos.Eof) Do
      Begin
         nSora := DataM.FDTabAyaPos.FieldByName('SORANO').AsInteger;
         //
         If numSora <> nSora Then
               Begin
                 MemoTemp.Lines.Add('N° Sora : ' + IntToStr(numSora) + ' ---> ' + 'Nbre ayate : ' + IntToStr(i));
                 MemoTemp.Lines.Add('');
                 //
                 k := k+1;              // Nombre des Sorate
                 i := 0;                // remise à zéro du nombre des ayate de la sora
                 numSora := nSora       // N° de la sora suivante
               End;
         DataM.FDTabAyaPos.Next;
         //
         i := i + 1;                     // Nombre des ayate  par sora
         j := j + 1;                     // Nombre total  des ayate de toutes les sorate
      End;
      //
      MemoTemp.Lines.Add('N° Sora : ' + IntToStr(numSora) + ' ---> ' + 'Nbre ayate : ' + IntToStr(i));
      //
      MemoTemp.Lines.Add('-----------------------------------------');
      MemoTemp.Lines.Add('Nombre Total des Ayate : ' + IntToStr(j));
      MemoTemp.Lines.Add('-----------------------------------------');
    }

    // Récupération du n° SORA de la base "FDTabAyateHafs" vers la base "ayapos"  dans MySQL
    //
    {While  Not (DataM.FDTabAyateHafs.Eof) Do
        Begin
          DataM.FDTabAyaPos.Edit;
          DataM.FDTabAyaPos.FieldByName('SORANO').AsInteger := DataM.FDTabAyateHafs.FieldByName('SORANO').AsInteger;
          DataM.FDTabAyaPos.Post;
          DataM.FDTabAyaPos.Next;
          DataM.FDTabAyateHafs.Next;
        End;
     ShowMessage('Récupération terminée du N° Sora Perdu ...');  }
end;




// Mode lecture de nuit
procedure TFormMoshaf.BtnInvertColorClick(Sender: TObject);
begin
  BMPWork.Assign(ImageMoshaf.Picture.Graphic);
  InvertBitmapColors(BmpWork);
  ImageMoshaf.Picture.Assign(BMPWork);
end;




//Inverser les couleurs d'une image
{ Cette procédure utilise la propriété ScanLine[] qui permet
 d'avoir une vitesse presque trente foix supérieure que l'acces
 simple à la propriété Pixels[] utilisant les méthodes API GetPixel()
 et SetPixel() }
procedure TFormMoshaf.InvertBitmapColors(const Bmp: TBitmap);
type
  TLine = array[Word] of TRGBTriple;
  PLine = ^TLine;
var
  X, Y: Integer;
  OldPixelFmt: TPixelFormat;
  Line: PLine;
begin
  OldPixelFmt := Bmp.PixelFormat;
  { Mise du bitmap en 24 bits par pixel :
  pas de changement de l'octet alpha s'il existait. }
  Bmp.PixelFormat := pf24bit;
  for Y := 0 to Bmp.Height -1 do
    begin
      Line := Bmp.ScanLine[Y];
      for X := 0 to Bmp.Width -1 do
        begin
          { Inversion des couleurs. }
          Line[X].rgbtRed   := not Line[X].rgbtRed;
          Line[X].rgbtGreen := not Line[X].rgbtGreen;
          Line[X].rgbtBlue  := not Line[X].rgbtBlue;
        end;
      end;
  { Restauration du mode de pixel d'origine. }
  Bmp.PixelFormat := OldPixelFmt;
end;





// Affichage des coordonnées X et Y de la souris sur l'ImageMoshaf
procedure TFormMoshaf.ImageMoshafMouseMove(Sender: TObject; Shift: TShiftState;
  X, Y: Integer);
var
  Pos: TPoint;
begin
  // Récupérer la position d'un pixel de l'écran
  Pos := FormMoshaf.ImageMoshaf.ScreenToClient(Mouse.CursorPos);
  edPosX.Text := IntToStr(Pos.X);
  edPosY.Text := IntToStr(Pos.Y);
end;




// Sauvegarde de la base "AyaPosCDS"
procedure TFormMoshaf.BtnSaveAyaPosClick(Sender: TObject);
Var
  sPath : String;
begin
  {sPath := ExtractFilePath(Application.ExeName);
  sPath := sPath + 'Data\Dat\AyaPos.cds';
  //AyaPosCDS.SaveToFile(sPath);
  //
  // Chargé AyaposCDS dans la Base de données "ayapos"    et   vice-versa
  //
  DataM.FDTabAyaPos.Open;
  AyaPosCDS.Open;
  AyaPosCDS.EmptyDataSet;
  //
  while NOT DataM.FDTabAyaPos.Eof  do
    begin
      AyaPosCDS.Append;
      AyaPosCDS.FieldByName('AIANO').AsInteger  := DataM.FDTabAyaPos.FieldByName('AIANO').AsInteger  ;
      AyaPosCDS.FieldByName('SORANO').AsInteger := DataM.FDTabAyaPos.FieldByName('SORANO').AsInteger ;
      AyaPosCDS.FieldByName('AIANOS').AsInteger := DataM.FDTabAyaPos.FieldByName('AIANOS').AsInteger ;
      AyaPosCDS.FieldByName('NOLINE').AsInteger := DataM.FDTabAyaPos.FieldByName('NOLINE').AsInteger ;
      AyaPosCDS.FieldByName('NOPAGE').AsInteger := DataM.FDTabAyaPos.FieldByName('NOPAGE').AsInteger ;
      AyaPosCDS.FieldByName('POSX').AsInteger   := DataM.FDTabAyaPos.FieldByName('POSX').AsInteger   ;
      AyaPosCDS.FieldByName('POSY').AsInteger   := DataM.FDTabAyaPos.FieldByName('POSY').AsInteger   ;
      AyaPosCDS.Post;
      AyaPosCDS.Next;
      DataM.FDTabAyaPos.Next;
    end;
    //
    AyaPosCDS.SaveToFile(sPath);
    ShowMessage('Chargement et sauveharde terminés des nouvelles ayapos ...'); }
end;




// High Light All Lines of Aya
procedure TFormMoshaf.ImageMoshafMouseDown(Sender: TObject;
  Button: TMouseButton; Shift: TShiftState; X, Y: Integer);
Var
  r1, r2 :TRect;
  ThisCanvas :  TCanvas;
  ThisColor, C : TColor;
  BmpWork : TBitmap;
  P1 : array [1..15] of TPoint ;
  P2 : array [1..15] of TPoint ;
  i, j, k: Integer;
  nPagec, nPagep, Lig, Ligp, nLig : Integer;       // Ligne Courante : Lig --- Ligne précédente : Ligp
  pcx, pcy, ppx, ppy : Integer;                           // Point Courant    : (pcx, pcy)
  nSora, nAya : Integer;                           // Point précédent  : (ppx, ppy)
  aPath, sSora, sAya : String;
begin
  aPath := ExtractFilePath(Application.ExeName);
  i:=random(20);                                          // i prend une  valeur aléatoire <= 20
  C:=ColorTab[I mod ColorTabMax];  	                      // cycle through all colors
  BMPWork:=TBitmap.Create;
  //                                                     // Hauteur de la ligne sur la page :
  P1[1] := Point(0, 0);     P2[1] := Point(430, 44);     // 44 pixels
  P1[2] := Point(0, 45);    P2[2] := Point(430, 91);     // 46
  P1[3] := Point(0, 92);    P2[3] := Point(430, 146);    // 54
  P1[4] := Point(0, 147);   P2[4] := Point(430, 194);    // 47
  P1[5] := Point(0, 195);   P2[5] := Point(430, 242);    // 47
  P1[6] := Point(0, 243);   P2[6] := Point(430, 298);    // 55
  P1[7] := Point(0, 299);   P2[7] := Point(430, 339);    // 60
  P1[8] := Point(0, 340);   P2[8] := Point(430, 390);    // 50
  P1[9] := Point(0, 391);   P2[9] := Point(430, 437);    // 46
  P1[10]:= Point(0, 438);   P2[10]:= Point(430, 487);    // 49
  P1[11]:= Point(0, 488);   P2[11]:= Point(430, 541);    // 53
  P1[12]:= Point(0, 542);   P2[12]:= Point(430, 590);    // 48
  P1[13]:= Point(0, 591);   P2[13]:= Point(430, 642);    // 51
  P1[14]:= Point(0, 643);   P2[14]:= Point(430, 692);    // 49
  P1[15]:= Point(0, 693);   P2[15]:= Point(430, 728);    // 35
  //
  // Détermination de la Ligne du clic de la souris Point(X, Y)
  Lig := NumLigne(Y);
  //
  // Détermination de la Ligne Fin de la Aya sélectionnée
  // Si la ligne du clic n'existe pas dans la base "AyaPos" alors
  // prendre la première ligne suivante dans la base
  // Exemple:
  // si ligne clic = 4 n'existe pas dans la base
  // alors ligne Fin Aya = Première Ligne > 4 dans la base
  // Si la Première Ligne =9 alors faire Lig = 9
  //
  try
    // Recherche Coordonnées (x,y) symbole(icone) debut et fin AYA
    AyaPosCDS.IndexFieldNames := 'NOPAGE; NOLINE; AIANO';
    nPagec := StrToInt(lbNumPage.Caption);                            // N° page courante
    //
    AyaPosCDS.FindNearest([nPagec, Lig]);                             // Trouver dans la base la ligne la plus proche de la ligne du clic de la souris
    Lig := DBGridAyaCDS.Fields[3].Value;
    pcx := DBGridAyaCDS.Fields[5].Value;
            //if (X < pcx) then                                       // Cas où une partie de la Aya est sur la ligne superieure
            //   begin
                 //AyaPosCDS.Next;
                 //pcx := DBGridAyaCDS.Fields[5].Value;
                 //Lig := DBGridAyaCDS.Fields[3].Value;
             //  end;
    pcx := pcx-15;
    pcy := P1[Lig].Y;
    //
    AyaPosCDS.Prior;
    nPagep := DBGridAyaCDS.Fields[4].Value;                     // N° page Prior
    Ligp := DBGridAyaCDS.Fields[3].Value;                       // FinAyaPrécédente(pcx, pcy)  <=> DébutAyaCourante
    ppx  := DBGridAyaCDS.Fields[5].Value;
    ppx := ppx-15;
    ppy := P2[Ligp].Y;                                          // ppy  := DBGridAyaCDS.Fields[6].Value;
    //
    nLig := Lig - Ligp;
    //
    if (nPagec <> nPagep) then
       begin
         AyaPosCDS.FindKey([nPagec, Lig]);
            pcx := DBGridAyaCDS.Fields[5].Value;
            pcx := pcx-15;
            pcy := P1[Lig].Y;
         r2 := Rect(P1[1].X, P1[1].Y, P2[1].X, P2[1].Y);
         r1 := Rect(pcx, pcy, P2[Lig].X, P2[Lig].Y);
         //
       end
    else
       begin
         r2 := Rect(P1[Ligp].X, P1[Ligp].Y, ppx, ppy);                                      // Rectangle de la ligne précédente
         r1 := Rect(pcx, pcy, P2[Lig].X, P2[Lig].Y);                                        // Rectangle de la ligne courante (sous le clic de la souris)
       end;
                // Récupération des infos de la Aya en cours pour la lecture Audio
                        nAya  := AyaPosCDS.FieldByName('AIANOS').AsInteger;                     // N° de la Aya dans tout le CORAN
                        nSora := AyaPosCDS.FieldByName('SORANO').AsInteger;                     // N° de la SORA
                      sAya    := Format('%.*d', [3, nAya+1]);
                      sSora   := Format('%.*d', [3, nSora]);
                     nFileMP3 := sSora + sAya + '.mp3';
                      //
                      if (TypeAudio = 'warsh') And (TypeMoshaf = 'warsh') then
                          nFileMP3 := aPath + 'Data\Audio\Coran\' + '\warsh\Warsh_Par_Aya\' + nFileMP3;
                      if (TypeAudio = 'hafs') And (TypeMoshaf = 'hafs') then
                          nFileMP3 := aPath + 'Data\Audio\Coran\' + '\hafs\Hafs_Par_Aya\' + nFileMP3;
                      //
                // Fin Récupération
    //
    With BMPWork do
      begin
        try
          Assign(ImageMoshaf.Picture.Graphic);                          // Affecter 'ImageMoshaf' à la Bitmap  'BMPWork'
          Width :=ImageMoshaf.Width;                                    // Définir la largeur de la Bitmap
          Height:=ImageMoshaf.Height;                                   // Définir la hauteur de la Bitmap
          //
          ThisCanvas := BMPWork.Canvas;
          ThisColor := C;
          j := 80;
          //
          if (nLig = 1) then                                                      // Si la Aya se trouve sur deux lignes
               begin
                      //ShowMessage('Test_01');
                 DrawTransparentRectangle(ThisCanvas, r2, ThisColor, j);        // La deuxième ligne de la Aya
                 DrawTransparentRectangle(ThisCanvas, r1, ThisColor, j);        // La première ligne de la Aya
               end;

            if (nLig > 1) then                                                  // Si la Aya se trouve sur plus de deux lignes
               begin
                        //ShowMessage('Test_02');
                 DrawTransparentRectangle(ThisCanvas, r2, ThisColor, j);        // La deuxième ligne de la Aya
                 DrawTransparentRectangle(ThisCanvas, r1, ThisColor, j);        // La première ligne de la Aya
                 //
                 for k := Ligp+1 to Lig-1 do
                   begin
                     HighLightAya(ThisCanvas, P1[k], P2[k], C, j);
                   end;
               end;

          if  (nPagec <> nPagep) then                                           // Si la Aya se trouve sur deux premières lignes
               begin
                 //ShowMessage('Test_03');
                 DrawTransparentRectangle(ThisCanvas, r2, ThisColor, j);
                 DrawTransparentRectangle(ThisCanvas, r1, ThisColor, j);
                 //
                 for k := 2 to Lig-1 do
                   begin
                     HighLightAya(ThisCanvas, P1[k], P2[k], C, j);
                   end;
               end;
        Except
          ShowMessage('Erreur d''affichage de l''image ...');
        end;
      end;
    //
    ImageMoshaf.Picture.Assign(BMPWork);  		                                  // Affecter la Bitmap à TImage
  finally
    BMPWork.Free;
  end;
end;




// Procedure Transparent Rectangle
procedure TFormMoshaf.DrawTransparentRectangle(Canvas: TCanvas; Rect: TRect;
  Color: TColor; Transparency: Integer);
var
  X: Integer;
  Y: Integer;
  C: TColor;
  R, G, B: Integer;
  RR, RG, RB: Integer;
begin
  RR := GetRValue(Color);
  RG := GetGValue(Color);
  RB := GetBValue(Color);

  for Y := Rect.Top to Rect.Bottom - 1 do
    for X := Rect.Left to Rect.Right - 1 do
    begin
      C := Canvas.Pixels[X, Y];
      R := Round(
        0.01 * (Transparency * GetRValue(C) + (100 - Transparency) * RR)
      );

      G := Round(
        0.01 * (Transparency * GetGValue(C) + (100 - Transparency) * RG)
      );

      B := Round(
        0.01 * (Transparency * GetBValue(C) + (100 - Transparency) * RB)
      );

      Canvas.Pixels[X, Y] := RGB(R, G, B);
    end;
end;




// Procedure High_Light_One_Line_Of_Aya
procedure TFormMoshaf.HighLightAya(Canvas: TCanvas; p1,p2: TPoint;
              Color: TColor; Transparency: Integer);
var
  RectLig : TRect;
  Xa, Ya: Integer;
  C: TColor;
  R, G, B: Integer;
  RR, RG, RB: Integer;
begin
  RectLig := Rect(p1.X, p1.Y, p2.X, p2.Y);
  //
  RR := GetRValue(Color);
  RG := GetGValue(Color);
  RB := GetBValue(Color);

  for Ya := RectLig.Top to RectLig.Bottom - 1 do
    for Xa := RectLig.Left to RectLig.Right - 1 do
    begin
      C := Canvas.Pixels[Xa, Ya];
      R := Round(
        0.01 * (Transparency * GetRValue(C) + (100 - Transparency) * RR)
      );

      G := Round(
        0.01 * (Transparency * GetGValue(C) + (100 - Transparency) * RG)
      );

      B := Round(
        0.01 * (Transparency * GetBValue(C) + (100 - Transparency) * RB)
      );

      Canvas.Pixels[Xa, Ya] := RGB(R, G, B);
    end;
end;




// Recherche d'un texte
procedure TFormMoshaf.edtSearchEnter(Sender: TObject);
begin
  edtSearch.Text := '';
end;



//  قراءة صوتية متواصلة
procedure TFormMoshaf.ImageWaDhakirClick(Sender: TObject);
Var
  aPath : String;
begin
  aPath := ExtractFilePath(Application.ExeName);
  aPath := aPath + '\AudioPlayerCoran.exe';
  //
  if Not FileExists(aPath) Then
     ShowMessage('برنامج القراءة الصوتية غير متوفر')
  Else
    Try
      ShellExecute(Handle, 'open', PChar(aPath), nil, nil, SW_SHOW);
    Except
      ShowMessage('خطأ في تشغيل البرنامج');
    End;
end;




// قراءة صوتية    (Popmenu1)
procedure TFormMoshaf.N11Click(Sender: TObject);
begin
  ImageSoundClick(Sender);
end;



// قراءة صوتية
procedure TFormMoshaf.ImageSoundClick(Sender: TObject);
begin
  if nPage > 0 then
     begin
        SaveTypeMoshaf := TypeMoshaf;
        //
        FormPlayer.Left := FormMoshaf.Width + 50;
        FormPlayer.Top  := FormMoshaf.Top + 200;
        //
        FormPlayer.Show;
        //
        TypeMoshaf := SaveTypeMoshaf;
     end
  else
     ShowMessage('أفتح المصحف');
end;



// قراءة صوتية
procedure TFormMoshaf.ImageLectureClick(Sender: TObject);
begin
  FormPlayer.Show;
end;



// عرض نافذة الذكر
procedure TFormMoshaf.ImageDhikrDuJourClick(Sender: TObject);
begin
  FormDhikrJour.ShowModal;
end;



// Affichage Page Suivante
procedure TFormMoshaf.BtnSuivantClick(Sender: TObject);
Var
  RepPages, aPath, sPage, sAudio, NbreAyat, nOrdre, NameSora, nFormat : String;
  NumPage, MaPage : Integer;
begin
  PanelPiedPageMoshaf.Visible := true;
  aPath := ExtractFilePath(Application.ExeName);
  NumPage := StrToInt(eNumPage.Text) + 1;
  //
  if NumPage > 604 Then NumPage := 1;
  //
  eNumPage.Text := IntToStr(NumPage);
  lbNumPage.Caption := eNumPage.Text;
  //
  nFormat  := Format('%.*d', [3, NumPage]);
  nPage    := StrToInt(nFormat);
  sPage    := nFormat + '.jpg';
  sAudio   := nFormat + '.mp3';
  //
  SaveTypeMoshaf := TypeMoshaf;
  RepPages := RepMoshaf(aPath, TypeMoshaf, sPage);
  nFileMP3 := RepAudio(aPath, TypeAudio, sAudio);
  TypeMoshaf := SaveTypeMoshaf;

    //eDateHedjri.Text := 'TMos : ' + TypeMoshaf;
    //edDateAr.Text    := 'TAud : ' + TypeAudio;

  //
  Try
   ImageMoshaf.Picture.LoadFromFile(RepPages);
  Except
   ShowMessage('الصفحة غير موجودة');
  End;
  //
  // Mise à jour des infos de la page à afficher
  MaPage := StrToInt(eNumPage.Text);
  MajEntetePageMoshaf(MaPage, NbreAyat, nOrdre, NameSora);
  //
  eNumPage.SetFocus;
end;





// Affichage Page Precedente
procedure TFormMoshaf.BtnPrecedentClick(Sender: TObject);
Var
  RepPages, aPath, sPage, sAudio, NbreAyat, nOrdre, NameSora, nFormat : String;
  NumPage, MaPage : Integer;
begin
  PanelPiedPageMoshaf.Visible := true;
  aPath := ExtractFilePath(Application.ExeName);
  NumPage := StrToInt(eNumPage.Text);

  if NumPage > 1 Then
        NumPage := StrToInt(eNumPage.Text) - 1 ;

  eNumPage.Text := IntToStr(NumPage);
  lbNumPage.Caption := eNumPage.Text;
  //
  nFormat  := Format('%.*d', [3, NumPage]);
  nPage    := StrToInt(nFormat);
  sPage    := nFormat + '.jpg';
  sAudio   := nFormat + '.mp3';
  //
  TypeMoshaf := SaveTypeMoshaf;
  RepPages := RepMoshaf(aPath, TypeMoshaf, sPage);
  nFileMP3 := RepAudio(aPath, TypeAudio, sAudio);

    //eDateHedjri.Text := 'TMos : ' + TypeMoshaf;
    //edDateAr.Text    := 'TAud : ' + TypeAudio;

  //
  Try
   ImageMoshaf.Picture.LoadFromFile(RepPages);
  Except
   ShowMessage('الصفحة غير موجودة');
  End;
  //
  // Mise à jour des infos de la page à afficher
  MaPage := StrToInt(eNumPage.Text);
  MajEntetePageMoshaf(MaPage, NbreAyat, nOrdre, NameSora);
  //
  eNumPage.SetFocus;
end;




// Affichage Page choisi par son n°
procedure TFormMoshaf.BtnAffichePageClick(Sender: TObject);
Var
  RepPages, aPath, sPage, sAudio, NbreAyat, nOrdre, NameSora, nFormat : String;
  NumPage, MaPage : Integer;
begin
  PanelPiedPageMoshaf.Visible := true;
  aPath := ExtractFilePath(Application.ExeName);
  NumPage := StrToInt(eNumPage.Text);
  lbNumPage.Caption := eNumPage.Text;
  //
  nFormat  := Format('%.*d', [3, NumPage]);
  nPage    := StrToInt(nFormat);
  sPage    := nFormat + '.jpg';
  sAudio   := nFormat + '.mp3';
  //
  SaveTypeMoshaf := TypeMoshaf;
  RepPages := RepMoshaf(aPath, TypeMoshaf, sPage);
  nFileMP3 := RepAudio(aPath, TypeAudio, sAudio);
  TypeMoshaf := SaveTypeMoshaf;

    //eDateHedjri.Text := 'TMos : ' + TypeMoshaf;
    //edDateAr.Text    := 'TAud : ' + TypeAudio;

  //
  Try
   ImageMoshaf.Picture.LoadFromFile(RepPages);
  Except
   ShowMessage('الصفحة غير موجودة');
  End;
  //
  // Mise à jour des infos de la page à afficher
  MaPage := StrToInt(eNumPage.Text);
  MajEntetePageMoshaf(MaPage, NbreAyat, nOrdre, NameSora);
  //
  eNumPage.SetFocus;
end;




// Affichage Page Fatiha
procedure TFormMoshaf.BtnFatihaClick(Sender: TObject);
Var
  RepPages, aPath, NbreAyat, sPage, sAudio, nOrdre, NameSora : String;
  MaPage : Integer;
begin
  PanelPiedPageMoshaf.Visible := true;
  aPath := ExtractFilePath(Application.ExeName);
  //
  sPage := '001.jpg';
  sAudio   := '001.mp3';
  nPage := 1;
  //
  SaveTypeMoshaf := TypeMoshaf;
  RepPages := RepMoshaf(aPath, TypeMoshaf, sPage);
  nFileMP3 := RepAudio(aPath, TypeAudio, sAudio);
  TypeMoshaf := SaveTypeMoshaf;

    //eDateHedjri.Text := 'TMos : ' + TypeMoshaf;
    //edDateAr.Text    := 'TAud : ' + TypeAudio;

  //
  lbNumPage.Caption := '1';
  eNumPage.Text := '1';
  //
  Try
   ImageMoshaf.Picture.LoadFromFile(RepPages);
  Except
   ShowMessage('الصفحة غير موجودة');
  End;
  //
  // Mise à jour des infos de la page à afficher
  MaPage := StrToInt(eNumPage.Text);
  MajEntetePageMoshaf(MaPage,NbreAyat, nOrdre, NameSora);
  //
  eNumPage.SetFocus;
end;



// Affichage Page Annass
procedure TFormMoshaf.BtnAnnassClick(Sender: TObject);
Var
  RepPages, aPath, sPage, sAudio, NbreAyat, nOrdre, NameSora : String;
  MaPage : Integer;
begin
  PanelPiedPageMoshaf.Visible := true;
  aPath := ExtractFilePath(Application.ExeName);
  //
  sPage  := '604.jpg';
  sAudio := '604.mp3';
  //
  SaveTypeMoshaf := TypeMoshaf;
  RepPages := RepMoshaf(aPath, TypeMoshaf, sPage);
  nFileMP3 := RepAudio(aPath, TypeAudio, sAudio);
  TypeMoshaf := SaveTypeMoshaf;

    //eDateHedjri.Text := 'TMos : ' + TypeMoshaf;
    //edDateAr.Text    := 'TAud : ' + TypeAudio;

  //
  eNumPage.Text := '604';
  lbNumPage.Caption := '604';
  lbOrdreSora.Caption := '114';
  lbNbreAyatSora.Caption := '6';
  lbNameSora.Caption := 'الناس';
  //
  Try
   ImageMoshaf.Picture.LoadFromFile(RepPages);
  Except
   ShowMessage('الصفحة غير موجودة');
  End;
  //
  // Mise à jour des infos de la page à afficher
  MaPage := StrToInt(eNumPage.Text);
  MajEntetePageMoshaf(MaPage, NbreAyat, nOrdre, NameSora);
  //
  eNumPage.SetFocus;
end;




// Procédure clique sur le DBGridSoraname
procedure TFormMoshaf.DBGridSoranameSoraCDS;
Var
  RepPages, aPath, sPage, sAudio, nFormat : String;
  NumPage: Integer;
begin
  PanelPiedPageMoshaf.Visible := true;
  eNumPage.Text:=DBGridSoraname.Fields[2].AsString;            // N° page Moshaf
  lbOrdreSora.Caption := DBGridSoraname.Fields[0].AsString;    // N° Sora
  lbNbreAyatSora.Caption := DBGridSoraname.Fields[6].AsString; // Nombre Ayate dans Sora
  lbNumPage.Caption := eNumPage.Text;                          // N° page Moshaf
  lbNameSora.Caption := DBGridSoraname.Fields[1].AsString;     // Nom Sora
  //
  aPath := ExtractFilePath(Application.ExeName);
  NumPage := StrToInt(eNumPage.Text);
  //
  nFormat := Format('%.*d', [3, NumPage]);
  nPage := StrToInt(nFormat);
  sPage := nFormat + '.jpg';
  saudio := nFormat + '.mp3';
  //
  SaveTypeMoshaf := TypeMoshaf;
  RepPages := RepMoshaf(aPath, TypeMoshaf, sPage);
  nFileMP3 := RepAudio(aPath, TypeAudio, sAudio);
  TypeMoshaf := SaveTypeMoshaf;

    //eDateHedjri.Text := 'TMos : ' + TypeMoshaf;
    //edDateAr.Text    := 'TAud : ' + TypeAudio;

  //
  Try
   ImageMoshaf.Picture.LoadFromFile(RepPages);
  Except
   ShowMessage('الصفحة غير موجودة');
  End;
  //
  eNumPage.SetFocus;
end;




// Procédure clique sur le DBGridSoraname
procedure TFormMoshaf.TestDataSourceCellClick(Column: TColumn);
begin
 try
    if DBGridSoraname.DataSource <> DataSource1 then
      DBGridSoraname.DataSource := DataSource1;
  finally
     DBGridSoranameSoraCDS
  end;
end;




// Chargement des options de démarrage
procedure TFormMoshaf.FormActivate(Sender: TObject);
var
  Year, Month, Day: Word;
  RepPages, aPath : String;
begin
  TypeMoshaf := 'warsh';
  TypeAudio  := 'warsh';
  nAudioPlay := 0;
  PanelPiedPageMoshaf.Visible := False;
  // Choix de la langue arabe
  LoadKeyboardLayout('00000401', KLF_ACTIVATE);
  Application.BiDiKeyboard := '00000401';
  //
  eNumPage.SetFocus;
  //
  DBGridAyaCDS.BringToFront;
  //
  {
    ان الله ومليكته يصلون علي النبي يايها الذين امنوا صلوا عليه وسلموا تسليما
    (سورة الأحزاب 33 الآية 56 )

    اللهم صل و سلم على نبينا محمد
  }
  //
  // Affichage de l'image de Fête  ou de Salat Ala Annabi
  aPath := ExtractFilePath(Application.ExeName);
  //
  //Corriger la date hijri
  Now;      // Date du Jour
  DateToHejri(Now, Year, Month, Day);
  Day := Day - FormConfig.Jour.Value;
  eDateHedjri.Text := IntToStr(Day) + '  ' + HejriMonthsAr[Month] + '  ' + IntToStr(Year);
  //
  if (Day = 1) And (HejriMonthsAr[Month] = 'شوال') then                     // Aid El-Fitre
     RepPages := aPath + 'Data\Fete' + '\' + 'Fete_01.jpg'
  else
     if (Day = 1) And (HejriMonthsAr[Month] = 'رمضان') then                 // Ramadhane
         RepPages := aPath + 'Data\Fete' + '\' + 'Fete_02.jpg'
     else
        if (Day = 10) And (HejriMonthsAr[Month] = 'ذي الحجة') then          // Aid Al-Adha
           RepPages := aPath + 'Data\Fete' + '\' + 'Fete_03.jpg'
        else
           RepPages := aPath + 'Data\Dhikr' + '\' + '86.jpg';
  //
  try
    nFilesBanner := NombreFichiers(ShellTreeViewDhikr, aPath + 'Data\Banner', '\*.jpg');
    nFilesCanal  := NombreFichiers(ShellTreeViewDhikr, aPath + 'Data\Canal', '\*.jpg');
    nFilesDhikr  := NombreFichiers(ShellTreeViewDhikr, aPath + 'Data\Dhikr', '\*.jpg');
  except
    ShowMessage('مكان ملفات  القرآن الكريم مجهول');
  end;

  //
  try
    DSourceSoraCDS;
    AyaPosCDS.Last;
    eNumSora.Text := IntToStr(AyaPosCDS.FieldByName('SORANO').AsInteger);
    eNumAya.Text  := IntToStr(AyaPosCDS.FieldByName('AIANOS').AsInteger + 1);
    eNumLine.Text := IntToStr(AyaPosCDS.FieldByName('NOLINE').AsInteger);
  except
    ShowMessage('مكان ملفات نصوص القرآن الكريم مجهول');
  end;

end;






// Chargement du DataSource des Sorate
procedure TFormMoshaf.DSourceSoraCDS;
begin
  DBGridSoraname.Columns.Clear;
  DBGridSoraname.DataSource := DataSource1;

  DBGridSoraname.Columns[3].Visible := False;
  DBGridSoraname.Columns[4].Visible := False;
  DBGridSoraname.Columns[5].Visible := False;
  DBGridSoraname.Columns[7].Visible := False;
  DBGridSoraname.Columns[8].Visible := False;
  DBGridSoraname.Columns[9].Visible := False;
  DBGridSoraname.Columns[10].Visible := False;
  DBGridSoraname.Columns[11].Visible := False;
  DBGridSoraname.Columns[12].Visible := False;

  //DBGridSoraname.Columns[0].FieldName := 'SORANO';
  DBGridSoraname.Columns[0].Width := 36;
  DBGridSoraname.Columns[0].Title.Caption := 'ترتيب';
  DBGridSoraname.Columns[0].Title.Font.Color := clMaroon;
  DBGridSoraname.Columns[0].Title.Font.size := 12;
  DBGridSoraname.Columns[0].Title.Font.style := [];

  //DBGridSoraname.Columns[1].FieldName := 'NAME';
  DBGridSoraname.Columns[1].Width := 47;
  DBGridSoraname.Columns[1].Title.Caption := 'السورة';
  DBGridSoraname.Columns[1].Title.Font.Color := clMaroon;
  DBGridSoraname.Columns[1].Title.Font.size := 12;
  DBGridSoraname.Columns[1].Title.Font.style := [];

  //DBGridSoraname.Columns[2].FieldName := 'PageMushaf';
  DBGridSoraname.Columns[2].Width := 45;
  DBGridSoraname.Columns[2].Title.Caption := 'الصفحة';
  DBGridSoraname.Columns[2].Title.Font.Color := clMaroon;
  DBGridSoraname.Columns[2].Title.Font.size := 12;
  DBGridSoraname.Columns[2].Title.Font.style := [];

  //DBGridSoraname.Columns[6].FieldName := 'AiaCount';
  DBGridSoraname.Columns[6].Width := 44;
  DBGridSoraname.Columns[6].Title.Caption := 'الآيات';
  DBGridSoraname.Columns[6].Title.Font.Color := clMaroon;
  DBGridSoraname.Columns[6].Title.Font.size := 12;
  DBGridSoraname.Columns[6].Title.Font.style := [];

  DBGridSoraname.Refresh;
end;




// Affichage des Textes du Coran
procedure TFormMoshaf.N10Click(Sender: TObject);
begin
  BtnInvertColorClick(Sender);
end;





procedure TFormMoshaf.N2Click(Sender: TObject);
begin
  FormConfig.Show;
end;




procedure TFormMoshaf.N3Click(Sender: TObject);
begin
  FormRecherche.ShowModal;
end;




procedure TFormMoshaf.N6Click(Sender: TObject);
begin
  FormAbout.ShowModal;
end;



procedure TFormMoshaf.N8Click(Sender: TObject);
begin
  FormFahresN.ShowModal;
end;



procedure TFormMoshaf.N9Click(Sender: TObject);
begin
  FormGoPage.ShowModal;
end;




// Choix du type de Moshaf  WARSH
procedure TFormMoshaf.CheckBoxWarshClick(Sender: TObject);
begin
  if CheckBoxWarsh.Checked then
        begin
          TypeMoshaf := 'warsh' ;
          TypeAudio  := 'warsh' ;
          CheckBoxHafs.Checked := False;
        end;
end;



// Choix du type de Moshaf  HAFS
procedure TFormMoshaf.CheckBoxHafsClick(Sender: TObject);
begin
  if CheckBoxHafs.Checked then
        begin
          TypeMoshaf := 'hafs' ;
          TypeAudio  := 'hafs' ;
          CheckBoxWarsh.Checked := False;
        end;
end;



procedure TFormMoshaf.TrayIcon1DblClick(Sender: TObject);
begin
  // On retire l'icône du SysTray
   TrayIcon1.Visible := False;
  // On restaure la fenêtre sinon elle reste dans la barre des tâches
   WindowState := wsNormal;
  // On affiche la fiche
   Show();
  // On place l'application au premier plan
   Application.BringToFront;
end;



// الخروج من البرنامج
procedure TFormMoshaf.N5Click(Sender: TObject);    // PopupMenu1
begin
  Close;
end;



// الخروج من البرنامج
procedure TFormMoshaf.FormCloseQuery(Sender: TObject; var CanClose: Boolean);
Var
  sPath, Titre, Mess : String;
begin
 Titre := 'متصفح القرآن الكريم';
 Mess  := 'مرحبا بك في برنامج المتصفح الإلمتروني للقرآن الكريم  حراء. هل تريد الخروج الآن؟';
 sPath := ExtractFilePath(Application.ExeName);
 sPath := sPath + 'Data\Dat\AyaPos.cds';
 //
 if MyDialog('متصفح القرآن الكريم', 'مرحبا بك في برنامج المتصفح الإلمتروني للقرآن الكريم  حراء. هل تريد الخروج الآن؟', ['نعم', 'لا'],
                mtWarning, [mbYes, mbNo], bdLeftToRight, mbYes).ShowModal = mrNo then
     begin
       CanClose := False;
     end
  else
     begin
       try
        // Choix de la langue Française
        LoadKeyboardLayout('0000040c', KLF_ACTIVATE);
        Application.BiDiKeyboard := '0000040c';
        //
        try
          AyaPosCDS.SaveToFile(sPath);
        except
          ShowMessage('الملف' + ' ' + sPath + '  '+ 'غير موجود');
        end;
        //
       finally
          Application.Terminate;
       end;
     end;
end;


end.
